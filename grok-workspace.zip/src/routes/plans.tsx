import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { Check, Minus } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { OwnerShell, PageSkeleton } from "@/components/owner-shell";
import { listPlans } from "@/lib/api/billing";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatETB } from "@/lib/format";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import type { PlanDTO } from "@/lib/types";

export const Route = createFileRoute("/plans")({ component: PlansPage });

function PlansPage() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const language = usePOSStore((s) => s.language);
  const [plans, setPlans] = useState<PlanDTO[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    void listPlans()
      .then(setPlans)
      .catch((e: unknown) => setLoadError(e instanceof Error ? e.message : "Failed to load plans"));
  }, [user]);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!bootstrap?.profile.emailVerified) return <Navigate to="/verify" />;
  if (!bootstrap.restaurant) return <Navigate to="/onboarding" />;

  const currentId = bootstrap.entitlements?.planId;
  const locked = bootstrap.entitlements?.billingLocked;
  const days = bootstrap.entitlements?.trialDaysLeft ?? 0;

  return (
    <OwnerShell
      title={t(language, "plansTitle")}
      subtitle={
        locked
          ? t(language, "trialExpired")
          : days > 0 && bootstrap.entitlements?.subscriptionStatus === "trialing"
            ? `${days} ${t(language, "trialBanner")}`
            : bootstrap.entitlements?.planName
      }
    >
      {locked ? (
        <div className="mb-6 rounded-2xl bg-warning/15 px-4 py-3 text-sm text-fg">
          {t(language, "trialExpired")}
        </div>
      ) : null}
      {loadError ? <p className="mb-4 text-sm text-danger">{loadError}</p> : null}
      <div className="grid gap-4 md:grid-cols-2">
        {plans.map((plan) => {
          const current = plan.id === currentId && !locked;
          const isTrial = plan.slug === "trial";
          return (
            <article
              key={plan.id}
              className="flex flex-col rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold tracking-tight">{plan.name}</h2>
                  <p className="mt-1 text-sm text-muted">{plan.description}</p>
                </div>
                {current ? (
                  <Badge tone="success">{t(language, "currentPlan")}</Badge>
                ) : null}
              </div>
              <p className="mt-4 text-3xl font-semibold tracking-tight tabular-nums">
                {plan.priceEtb === 0 ? "0" : formatETB(plan.priceEtb, language)}
                {plan.interval === "month" ? (
                  <span className="text-sm font-normal text-muted">{t(language, "month")}</span>
                ) : null}
              </p>
              <ul className="mt-5 flex-1 space-y-2">
                {plan.features.map((f) => {
                  const limitText =
                    f.limit === -1
                      ? t(language, "unlimited")
                      : f.limit != null
                        ? String(f.limit)
                        : null;
                  return (
                    <li key={f.key} className="flex items-start gap-2 text-sm">
                      {f.enabled ? (
                        <Check className="mt-0.5 size-4 shrink-0 text-success" />
                      ) : (
                        <Minus className="mt-0.5 size-4 shrink-0 text-subtle" />
                      )}
                      <span className={f.enabled ? "text-fg" : "text-muted"}>
                        {f.name}
                        {limitText ? ` · ${limitText}` : ""}
                      </span>
                    </li>
                  );
                })}
              </ul>
              {isTrial || current ? (
                <Button variant="outline" className="mt-6" disabled>
                  {t(language, "currentPlan")}
                </Button>
              ) : (
                <Button
                  className="mt-6"
                  onClick={() => navigate({ to: "/checkout/$planId", params: { planId: plan.id } })}
                >
                  {t(language, "choosePlan")}
                </Button>
              )}
            </article>
          );
        })}
      </div>
      {bootstrap.restaurant.status === "active" && !locked ? (
        <p className="mt-6 text-center text-sm">
          <Link to="/pin" className="text-muted underline-offset-4 hover:text-fg hover:underline">
            {t(language, "backToFloor")}
          </Link>
        </p>
      ) : null}
    </OwnerShell>
  );
}
