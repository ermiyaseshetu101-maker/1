import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { OwnerShell, PageSkeleton } from "@/components/owner-shell";
import {
  expireRestaurantTrial,
  platformOverview,
  setPlanFeature,
  setPlanPrice,
  setRestaurantStatus,
} from "@/lib/api/platform";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatETB } from "@/lib/format";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export const Route = createFileRoute("/platform")({ component: PlatformPage });

type Overview = Awaited<ReturnType<typeof platformOverview>>;

function PlatformPage() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const language = usePOSStore((s) => s.language);
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    try {
      setData(await platformOverview());
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Forbidden");
    }
  }

  useEffect(() => {
    if (!user) return;
    void load();
  }, [user]);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (bootstrap && bootstrap.profile.platformRole !== "super_admin") {
    return <Navigate to="/" />;
  }

  return (
    <OwnerShell title={t(language, "platform")} subtitle="simplePOS">
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      {data ? (
        <div className="space-y-8">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat label={t(language, "restaurants")} value={String(data.stats.restaurants)} />
            <Stat label="Owners" value={String(data.stats.owners)} />
            <Stat label="Active" value={String(data.stats.active)} />
            <Stat label="Pending" value={String(data.stats.pending)} />
          </div>

          <section className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <h2 className="mb-3 text-sm font-semibold">{t(language, "restaurants")}</h2>
            <ul className="divide-y divide-border">
              {data.restaurants.length === 0 ? (
                <li className="py-6 text-sm text-muted">No restaurants yet.</li>
              ) : (
                data.restaurants.map((r) => (
                  <li key={r.id} className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center">
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{r.name}</p>
                      <p className="text-xs text-muted">
                        {r.slug} · {r.planId.replace("plan_", "")} · {r.trialDaysLeft}{" "}
                        {t(language, "daysLeft")}
                      </p>
                    </div>
                    <Badge
                      tone={
                        r.status === "active" ? "success" : r.status === "pending" ? "warning" : "danger"
                      }
                    >
                      {r.status}
                    </Badge>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          void setRestaurantStatus({ data: { restaurantId: r.id, status: "active" } }).then(load)
                        }
                      >
                        {t(language, "approve")}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          void setRestaurantStatus({ data: { restaurantId: r.id, status: "suspended" } }).then(load)
                        }
                      >
                        {t(language, "suspend")}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          void setRestaurantStatus({ data: { restaurantId: r.id, status: "rejected" } }).then(load)
                        }
                      >
                        {t(language, "reject")}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          void expireRestaurantTrial({ data: { restaurantId: r.id } }).then(() => {
                            toast.message("Trial ended for this restaurant");
                            void load();
                          })
                        }
                      >
                        {t(language, "expireTrial")}
                      </Button>
                    </div>
                  </li>
                ))
              )}
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-sm font-semibold">{t(language, "planFeatures")}</h2>
            {data.plans.map((plan) => (
              <article key={plan.id} className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <h3 className="font-semibold">{plan.name}</h3>
                  <label className="ml-auto flex items-center gap-2 text-sm">
                    ETB
                    <input
                      type="number"
                      min={0}
                      defaultValue={plan.priceEtb}
                      className="h-9 w-24 rounded-lg bg-elevated px-2 text-sm tabular-nums outline-none"
                      onBlur={(e) => {
                        const value = Number(e.target.value);
                        if (Number.isFinite(value) && value !== plan.priceEtb) {
                          void setPlanPrice({ data: { planId: plan.id, priceEtb: value } }).then(load);
                        }
                      }}
                    />
                  </label>
                  <span className="text-sm text-muted">{formatETB(plan.priceEtb, language)}</span>
                </div>
                <ul className="grid gap-2 sm:grid-cols-2">
                  {plan.features.map((f) => (
                    <li key={f.featureId} className="flex items-center gap-2 rounded-xl bg-elevated px-3 py-2">
                      <input
                        type="checkbox"
                        checked={f.enabled}
                        onChange={(e) =>
                          void setPlanFeature({
                            data: {
                              planId: plan.id,
                              featureId: f.featureId,
                              enabled: e.target.checked,
                              limit: f.limit,
                            },
                          }).then(load)
                        }
                      />
                      <span className="min-w-0 flex-1 text-sm">{f.name}</span>
                      {f.kind === "limit" ? (
                        <input
                          type="number"
                          className="h-8 w-16 rounded-md bg-surface px-1 text-xs tabular-nums outline-none"
                          defaultValue={f.limit ?? 0}
                          onBlur={(e) => {
                            const value = Number(e.target.value);
                            if (!Number.isFinite(value) || value === f.limit) return;
                            void setPlanFeature({
                              data: {
                                planId: plan.id,
                                featureId: f.featureId,
                                enabled: f.enabled,
                                limit: value,
                              },
                            }).then(load);
                          }}
                        />
                      ) : null}
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </section>
        </div>
      ) : null}
    </OwnerShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-2 text-2xl font-semibold tabular-nums">{value}</p>
    </div>
  );
}
