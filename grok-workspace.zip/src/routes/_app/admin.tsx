import { createFileRoute } from "@tanstack/react-router";
import { AdminScreen } from "@/components/admin/admin-screen";

export const Route = createFileRoute("/_app/admin")({
  component: AdminScreen,
});
