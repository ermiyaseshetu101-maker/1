import { createFileRoute } from "@tanstack/react-router";
import { PosScreen } from "@/components/pos/pos-screen";

export const Route = createFileRoute("/_app/pos")({
  component: PosScreen,
});
