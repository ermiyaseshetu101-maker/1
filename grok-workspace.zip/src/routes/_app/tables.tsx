import { createFileRoute } from "@tanstack/react-router";
import { FloorPlan } from "@/components/tables/floor-plan";

export const Route = createFileRoute("/_app/tables")({
  component: FloorPlan,
});
