import { createFileRoute } from "@tanstack/react-router";
import { KdsScreen } from "@/components/kds/kds-screen";
import { UpgradeCard } from "@/components/owner-shell";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import { hasFeature } from "@/lib/types";

export const Route = createFileRoute("/_app/kds")({
  component: KdsRoute,
});

function KdsRoute() {
  const { bootstrap } = useTenant();
  const language = usePOSStore((s) => s.language);
  if (!hasFeature(bootstrap?.entitlements, "kds")) {
    return <UpgradeCard message={t(language, "featureLocked")} />;
  }
  return <KdsScreen />;
}
