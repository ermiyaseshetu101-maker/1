import { createFileRoute } from "@tanstack/react-router";
import { KdsScreen } from "@/components/kds/kds-screen";

export const Route = createFileRoute("/_app/kds")({
  component: KdsScreen,
});
