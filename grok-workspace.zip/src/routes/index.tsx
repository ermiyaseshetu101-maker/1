import { createFileRoute, Navigate } from "@tanstack/react-router";
import { PinLogin } from "@/components/pin-login";
import { usePOSStore } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const session = usePOSStore((s) => s.session);
  if (session) return <Navigate to="/pos" />;
  return <PinLogin />;
}
