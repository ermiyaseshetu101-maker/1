import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageSkeleton } from "@/components/owner-shell";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export const Route = createFileRoute("/")({ component: Home });

export function signedInDestination(args: {
  emailVerified: boolean;
  hasRestaurant: boolean;
  status?: string;
  billingLocked?: boolean;
  hasStaffSession: boolean;
  role?: string;
}): string {
  if (!args.emailVerified) return "/verify";
  if (!args.hasRestaurant) return "/onboarding";
  if (args.status === "pending" || args.status === "suspended" || args.status === "rejected") {
    return "/pending";
  }
  if (args.billingLocked) return "/plans";
  if (!args.hasStaffSession) return "/pin";
  if (args.role === "waiter") return "/tables";
  if (args.role === "kitchen") return "/kds";
  if (args.role === "admin" || args.role === "manager") return "/admin";
  return "/pos";
}

function Home() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const session = usePOSStore((s) => s.session);
  const language = usePOSStore((s) => s.language);
  const setLanguage = usePOSStore((s) => s.setLanguage);
  const theme = usePOSStore((s) => s.theme);
  const setTheme = usePOSStore((s) => s.setTheme);

  if (isPending || (user && loading)) return <PageSkeleton />;

  if (user && bootstrap) {
    return (
      <Navigate
        to={signedInDestination({
          emailVerified: bootstrap.profile.emailVerified,
          hasRestaurant: Boolean(bootstrap.restaurant),
          status: bootstrap.restaurant?.status,
          billingLocked: bootstrap.entitlements?.billingLocked,
          hasStaffSession: Boolean(session),
          role: session?.role,
        })}
      />
    );
  }

  if (user && !bootstrap) return <PageSkeleton />;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-4">
        <div className="flex size-9 items-center justify-center rounded-lg bg-fg text-bg">
          <span className="text-xs font-semibold">sP</span>
        </div>
        <p className="flex-1 text-sm font-semibold">{t(language, "appName")}</p>
        <button
          type="button"
          className="text-xs font-medium text-muted"
          onClick={() => setLanguage(language === "en" ? "am" : "en")}
        >
          {language === "en" ? "አማርኛ" : "English"}
        </button>
        <button
          type="button"
          className="text-xs font-medium text-muted"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          {t(language, theme === "dark" ? "light" : "dark")}
        </button>
        <Button size="sm" variant="ghost" asChild>
          <Link to="/login">{t(language, "ownerLogin")}</Link>
        </Button>
      </header>

      <section className="mx-auto max-w-5xl px-4 py-16 md:py-24">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">
          {t(language, "daysTrial")}
        </p>
        <h1 className="mt-3 max-w-xl text-4xl font-semibold tracking-tight md:text-5xl">
          {t(language, "appName")}
        </h1>
        <p className="mt-4 max-w-lg text-base text-muted">{t(language, "landingLead")}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button size="lg" asChild>
            <Link to="/register">{t(language, "ownerRegister")}</Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/login">{t(language, "ownerLogin")}</Link>
          </Button>
        </div>
        <p className="mt-6 max-w-md text-sm text-muted">{t(language, "staffPinHint")}</p>
      </section>

      <section className="mx-auto grid max-w-5xl gap-3 px-4 pb-20 sm:grid-cols-3">
        {[
          { title: "Starter", price: "ETB 1,500", body: "Front of house, kitchen display, discounts." },
          { title: "Professional", price: "ETB 3,500", body: "Reports, customers, receipt branding." },
          { title: "Business", price: "ETB 7,500", body: "Unlimited staff, tables, inventory." },
        ].map((card) => (
          <article key={card.title} className="rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]">
            <p className="text-sm font-medium text-muted">{card.title}</p>
            <p className="mt-2 text-xl font-semibold tracking-tight">{card.price}</p>
            <p className="mt-2 text-sm text-muted">{card.body}</p>
          </article>
        ))}
      </section>
    </div>
  );
}
