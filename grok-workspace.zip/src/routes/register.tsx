import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Field, fieldClass, PageSkeleton } from "@/components/owner-shell";
import { AuthPage } from "@/routes/login";
import { markEmailUnverified } from "@/lib/api/bootstrap";
import { authClient, authEnabled, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";

export const Route = createFileRoute("/register")({ component: Register });

const PENDING_KEY = "simplepos.pending-restaurant";

export function savePendingRestaurant(name: string, ownerName: string, language: "en" | "am") {
  try {
    sessionStorage.setItem(PENDING_KEY, JSON.stringify({ name, ownerName, language }));
  } catch {
    /* ignore */
  }
}

export function readPendingRestaurant(): { name: string; ownerName: string; language: "en" | "am" } | null {
  try {
    const raw = sessionStorage.getItem(PENDING_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as { name: string; ownerName: string; language: "en" | "am" };
  } catch {
    return null;
  }
}

function Register() {
  const { user, isPending } = useCurrentUserState();
  const language = usePOSStore((s) => s.language);
  const [restaurantName, setRestaurantName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isPending) return <PageSkeleton />;
  if (user) return <Navigate to="/" />;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }
    setBusy(true);
    setError(null);
    const { error: err } = await authClient.signUp.email({
      email,
      password,
      name: ownerName,
    });
    if (err) {
      setBusy(false);
      setError(err.message ?? "Could not create account");
      return;
    }
    savePendingRestaurant(restaurantName, ownerName, language);
    try {
      await markEmailUnverified({ data: { displayName: ownerName } });
    } catch {
      /* profile row may land on first bootstrap */
    }
    setBusy(false);
    window.location.assign("/verify");
  }

  return (
    <AuthPage>
      <h1 className="text-2xl font-semibold tracking-tight">{t(language, "ownerRegister")}</h1>
      <p className="mt-1 text-sm text-muted">{t(language, "daysTrial")}</p>

      {authEnabled ? (
        <div className="mt-6 space-y-2">
          {GROK_PROVIDERS.map((p) => (
            <Button
              key={p.providerId}
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => {
                savePendingRestaurant(restaurantName || "My restaurant", ownerName || "Owner", language);
                void signIn(p.providerId, { callbackURL: "/" });
              }}
            >
              {p.label === "X" ? t(language, "continueX") : t(language, "continueGoogle")}
            </Button>
          ))}
        </div>
      ) : null}

      <p className="mt-6 mb-3 text-center text-xs tracking-wide text-muted uppercase">
        {t(language, "orEmail")}
      </p>
      <form className="space-y-3" onSubmit={(e) => void onSubmit(e)}>
        <Field label={t(language, "restaurantName")}>
          <input
            className={fieldClass}
            required
            minLength={2}
            value={restaurantName}
            onChange={(e) => setRestaurantName(e.target.value)}
          />
        </Field>
        <Field label={t(language, "ownerName")}>
          <input
            className={fieldClass}
            required
            minLength={2}
            autoComplete="name"
            value={ownerName}
            onChange={(e) => setOwnerName(e.target.value)}
          />
        </Field>
        <Field label={t(language, "email")}>
          <input
            className={fieldClass}
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label={t(language, "password")}>
          <input
            className={fieldClass}
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        <Field label={t(language, "confirmPassword")}>
          <input
            className={fieldClass}
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
        </Field>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {t(language, "createAccount")}
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-muted">
        {t(language, "haveAccount")}{" "}
        <Link to="/login" className="text-fg underline-offset-4 hover:underline">
          {t(language, "ownerLogin")}
        </Link>
      </p>
    </AuthPage>
  );
}
