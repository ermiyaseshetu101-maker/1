import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { OwnerShell, PageSkeleton } from "@/components/owner-shell";
import { confirmSandboxPayment, listPlans, startCheckout } from "@/lib/api/billing";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatETB } from "@/lib/format";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import type { BillingProvider, PlanDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/checkout/$planId")({ component: CheckoutPage });

const PROVIDERS: { id: BillingProvider; label: string; hint: string }[] = [
  { id: "chapa", label: "Chapa", hint: "Cards and Ethiopian banks" },
  { id: "telebirr", label: "Telebirr", hint: "Mobile money" },
  { id: "stripe", label: "Stripe", hint: "International cards" },
  { id: "card", label: "Card", hint: "Direct card processor" },
];

function CheckoutPage() {
  const { planId } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading, refresh } = useTenant();
  const language = usePOSStore((s) => s.language);
  const navigate = useNavigate();
  const [plan, setPlan] = useState<PlanDTO | null>(null);
  const [provider, setProvider] = useState<BillingProvider>("chapa");
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    void listPlans().then((plans) => setPlan(plans.find((p) => p.id === planId) ?? null));
  }, [user, planId]);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!bootstrap?.restaurant) return <Navigate to="/onboarding" />;

  async function beginPay() {
    setBusy(true);
    setError(null);
    try {
      const res = await startCheckout({ data: { planId, provider } });
      setPaymentId(res.paymentId);
      setHint(res.checkoutHint);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Checkout failed");
    } finally {
      setBusy(false);
    }
  }

  async function confirm() {
    if (!paymentId) return;
    setBusy(true);
    setError(null);
    try {
      await confirmSandboxPayment({ data: { paymentId } });
      await refresh();
      void navigate({ to: "/pin" });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Payment failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <OwnerShell title={t(language, "checkout")} subtitle={plan?.name}>
      <div className="mx-auto max-w-lg rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]">
        <p className="text-sm text-muted">{plan?.description}</p>
        <p className="mt-3 text-3xl font-semibold tabular-nums">
          {plan ? formatETB(plan.priceEtb, language) : "—"}
          <span className="text-sm font-normal text-muted">{t(language, "month")}</span>
        </p>

        <p className="mt-6 mb-2 text-xs font-medium tracking-wide text-muted uppercase">
          {t(language, "payWith")}
        </p>
        <div className="grid grid-cols-2 gap-2">
          {PROVIDERS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                setProvider(p.id);
                setPaymentId(null);
                setHint(null);
              }}
              className={cn(
                "rounded-2xl px-3 py-3 text-left shadow-[var(--shadow-border)]",
                provider === p.id ? "bg-fg text-bg" : "bg-elevated text-fg",
              )}
            >
              <p className="text-sm font-semibold">{p.label}</p>
              <p className={cn("text-xs", provider === p.id ? "opacity-80" : "text-muted")}>{p.hint}</p>
            </button>
          ))}
        </div>

        {hint ? <p className="mt-4 text-sm text-muted">{hint}</p> : null}
        {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}

        <div className="mt-6 flex flex-col gap-2">
          {!paymentId ? (
            <Button disabled={busy || !plan} onClick={() => void beginPay()}>
              {t(language, "payWith")} {PROVIDERS.find((p) => p.id === provider)?.label}
            </Button>
          ) : (
            <Button disabled={busy} onClick={() => void confirm()}>
              {t(language, "sandboxPay")}
            </Button>
          )}
          <Button variant="ghost" asChild>
            <Link to="/plans">{t(language, "cancel")}</Link>
          </Button>
        </div>
      </div>
    </OwnerShell>
  );
}
