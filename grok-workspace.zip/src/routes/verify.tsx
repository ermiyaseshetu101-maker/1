import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { OwnerShell, PageSkeleton } from "@/components/owner-shell";
import { createRestaurant, verifyEmail } from "@/lib/api/bootstrap";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import { readPendingRestaurant } from "@/routes/register";

export const Route = createFileRoute("/verify")({ component: Verify });

function Verify() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading, refresh } = useTenant();
  const language = usePOSStore((s) => s.language);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (bootstrap?.profile.emailVerified) {
    if (!bootstrap.restaurant) return <Navigate to="/onboarding" />;
    return <Navigate to="/pin" />;
  }

  async function onVerify() {
    setBusy(true);
    setError(null);
    try {
      await verifyEmail();
      const pending = readPendingRestaurant();
      const next = await refresh();
      if (next && !next.restaurant && pending?.name) {
        await createRestaurant({
          data: {
            name: pending.name,
            ownerName: pending.ownerName,
            language: pending.language,
          },
        });
        await refresh();
      }
      void navigate({ to: "/" });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Verification failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <OwnerShell title={t(language, "verifyTitle")}>
      <div className="mx-auto max-w-md rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]">
        <h1 className="text-xl font-semibold tracking-tight">{t(language, "verifyTitle")}</h1>
        <p className="mt-2 text-sm text-muted">{t(language, "verifyBody")}</p>
        {user.primaryEmail ? (
          <p className="mt-3 rounded-xl bg-elevated px-3 py-2 text-sm">{user.primaryEmail}</p>
        ) : null}
        {error ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
        <Button className="mt-6 w-full" disabled={busy} onClick={() => void onVerify()}>
          {t(language, "verifyNow")}
        </Button>
      </div>
    </OwnerShell>
  );
}
