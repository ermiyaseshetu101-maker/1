import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Field, fieldClass, PageSkeleton } from "@/components/owner-shell";
import { authClient, authEnabled, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const language = usePOSStore((s) => s.language);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isPending) return <PageSkeleton />;
  if (user) return <Navigate to="/" />;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error: err } = await authClient.signIn.email({ email, password });
    setBusy(false);
    if (err) {
      setError(err.message ?? "Could not sign in");
      return;
    }
    window.location.assign("/");
  }

  return (
    <AuthPage>
      <h1 className="text-2xl font-semibold tracking-tight">{t(language, "ownerLogin")}</h1>
      <p className="mt-1 text-sm text-muted">{t(language, "staffPinHint")}</p>

      {authEnabled ? (
        <div className="mt-6 space-y-2">
          {GROK_PROVIDERS.map((p) => (
            <Button
              key={p.providerId}
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => signIn(p.providerId, { callbackURL: "/" })}
            >
              {p.providerId.includes("x") || p.label === "X"
                ? t(language, "continueX")
                : t(language, "continueGoogle")}
            </Button>
          ))}
        </div>
      ) : null}

      <p className="mt-6 mb-3 text-center text-xs tracking-wide text-muted uppercase">
        {t(language, "orEmail")}
      </p>
      <form className="space-y-3" onSubmit={(e) => void onSubmit(e)}>
        <Field label={t(language, "email")}>
          <input
            className={fieldClass}
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label={t(language, "password")}>
          <input
            className={fieldClass}
            type="password"
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {t(language, "ownerLogin")}
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-muted">
        {t(language, "noAccount")}{" "}
        <Link to="/register" className="text-fg underline-offset-4 hover:underline">
          {t(language, "ownerRegister")}
        </Link>
      </p>
    </AuthPage>
  );
}

export function AuthPage({ children }: { children: ReactNode }) {
  const language = usePOSStore((s) => s.language);
  const setLanguage = usePOSStore((s) => s.setLanguage);
  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <div className="flex items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-fg text-bg text-xs font-semibold">
            sP
          </span>
          <span className="text-sm font-semibold">{t(language, "appName")}</span>
        </Link>
        <button
          type="button"
          className="text-xs font-medium text-muted"
          onClick={() => setLanguage(language === "en" ? "am" : "en")}
        >
          {language === "en" ? "አማርኛ" : "English"}
        </button>
      </div>
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 pb-10">
        <div className="rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]">{children}</div>
      </div>
    </div>
  );
}
