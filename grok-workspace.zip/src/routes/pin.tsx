import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { PinLogin } from "@/components/pin-login";
import { PageSkeleton } from "@/components/owner-shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export const Route = createFileRoute("/pin")({ component: PinPage });

function PinPage() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const session = usePOSStore((s) => s.session);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!bootstrap?.profile.emailVerified) return <Navigate to="/verify" />;
  if (!bootstrap.restaurant) return <Navigate to="/onboarding" />;
  if (bootstrap.restaurant.status === "pending") return <Navigate to="/pending" />;
  if (bootstrap.restaurant.status === "suspended" || bootstrap.restaurant.status === "rejected") {
    return <Navigate to="/pending" />;
  }
  if (bootstrap.entitlements?.billingLocked) return <Navigate to="/plans" />;
  if (session) {
    const dest =
      session.role === "waiter"
        ? "/tables"
        : session.role === "kitchen"
          ? "/kds"
          : session.role === "admin" || session.role === "manager"
            ? "/admin"
            : "/pos";
    return <Navigate to={dest} />;
  }
  return (
    <div className="relative">
      <PinLogin />
      <div className="absolute top-3 left-4 flex gap-3 text-xs">
        <Link to="/plans" className="text-muted hover:text-fg">
          Plans
        </Link>
        {bootstrap.profile.platformRole === "super_admin" ? (
          <Link to="/platform" className="text-muted hover:text-fg">
            Platform
          </Link>
        ) : null}
      </div>
    </div>
  );
}
