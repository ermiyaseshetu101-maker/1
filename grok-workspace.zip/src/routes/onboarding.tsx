import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Field, fieldClass, OwnerShell, PageSkeleton } from "@/components/owner-shell";
import { createRestaurant } from "@/lib/api/bootstrap";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import { readPendingRestaurant } from "@/routes/register";

export const Route = createFileRoute("/onboarding")({ component: Onboarding });

function Onboarding() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading, refresh } = useTenant();
  const language = usePOSStore((s) => s.language);
  const pending = typeof window !== "undefined" ? readPendingRestaurant() : null;
  const [name, setName] = useState(pending?.name ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!bootstrap?.profile.emailVerified) return <Navigate to="/verify" />;
  if (bootstrap.restaurant) return <Navigate to="/pin" />;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await createRestaurant({
        data: {
          name,
          language,
          ownerName: pending?.ownerName ?? user?.displayName ?? undefined,
        },
      });
      await refresh();
      void navigate({ to: "/pin" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create restaurant");
    } finally {
      setBusy(false);
    }
  }

  return (
    <OwnerShell title={t(language, "onboardingTitle")} subtitle={t(language, "daysTrial")}>
      <form
        onSubmit={(e) => void onSubmit(e)}
        className="mx-auto max-w-md space-y-4 rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]"
      >
        <h1 className="text-xl font-semibold tracking-tight">{t(language, "onboardingTitle")}</h1>
        <Field label={t(language, "restaurantName")}>
          <input
            className={fieldClass}
            required
            minLength={2}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {t(language, "startTrial")}
        </Button>
      </form>
    </OwnerShell>
  );
}
