import { createFileRoute, Navigate, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { PageSkeleton } from "@/components/owner-shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export const Route = createFileRoute("/_app")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const session = usePOSStore((s) => s.session);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!bootstrap?.profile.emailVerified) return <Navigate to="/verify" />;
  if (!bootstrap.restaurant) return <Navigate to="/onboarding" />;
  if (
    bootstrap.restaurant.status === "pending" ||
    bootstrap.restaurant.status === "suspended" ||
    bootstrap.restaurant.status === "rejected"
  ) {
    return <Navigate to="/pending" />;
  }
  if (bootstrap.entitlements?.billingLocked) return <Navigate to="/plans" />;
  if (!session) return <Navigate to="/pin" />;

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
