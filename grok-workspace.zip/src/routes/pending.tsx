import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageSkeleton, StatusScreen } from "@/components/owner-shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export const Route = createFileRoute("/pending")({ component: Pending });

function Pending() {
  const { user, isPending } = useCurrentUserState();
  const { bootstrap, loading } = useTenant();
  const language = usePOSStore((s) => s.language);

  if (isPending || loading) return <PageSkeleton />;
  if (!user) return <RedirectToSignIn />;
  const status = bootstrap?.restaurant?.status;
  if (status === "active" && !bootstrap?.entitlements?.billingLocked) {
    return <Navigate to="/pin" />;
  }
  if (bootstrap?.entitlements?.billingLocked) return <Navigate to="/plans" />;

  const suspended = status === "suspended" || status === "rejected";
  return (
    <StatusScreen
      title={t(language, suspended ? "suspendedTitle" : "pendingTitle")}
      body={
        suspended
          ? t(language, "suspendedTitle")
          : t(language, "pendingBody")
      }
      action={
        <Button asChild variant="outline">
          <Link to="/plans">{t(language, "plansTitle")}</Link>
        </Button>
      }
    />
  );
}
