import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { getBootstrap } from "@/lib/api/bootstrap";
import { getCatalog } from "@/lib/api/catalog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { usePOSStore } from "@/lib/store";
import type { Bootstrap } from "@/lib/types";

type TenantState = {
  bootstrap: Bootstrap | null;
  loading: boolean;
  refresh: () => Promise<Bootstrap | null>;
};

const TenantContext = createContext<TenantState>({
  bootstrap: null,
  loading: true,
  refresh: async () => null,
});

export function TenantProvider({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const [bootstrap, setBootstrap] = useState<Bootstrap | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) {
      setBootstrap(null);
      setLoading(false);
      return null;
    }
    try {
      const data = await getBootstrap();
      setBootstrap(data);
      if (data.restaurant) {
        try {
          const catalog = await getCatalog();
          usePOSStore.getState().hydrateCatalog(catalog);
        } catch {
          /* PIN/catalog hydrate is best-effort */
        }
      }
      return data;
    } catch {
      setBootstrap(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (isPending) return;
    setLoading(true);
    void refresh();
  }, [isPending, refresh]);

  return (
    <TenantContext.Provider value={{ bootstrap, loading: isPending || loading, refresh }}>
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant() {
  return useContext(TenantContext);
}
