import type { Category, FloorTable, Order, Product, Staff } from "./types";

export const SEED_VERSION = 1;

export const STAFF: Staff[] = [
  { id: "s_admin", name: "Hana Bekele", nameAm: "ሃና በቀለ", pin: "1234", role: "admin" },
  { id: "s_manager", name: "Yonas Tadesse", nameAm: "ዮናስ ታደሰ", pin: "2222", role: "manager" },
  { id: "s_cashier", name: "Marta Alemu", nameAm: "ማርታ ዓለሙ", pin: "1111", role: "cashier" },
  { id: "s_waiter", name: "Abel Tesfaye", nameAm: "አቤል ተስፋዬ", pin: "0000", role: "waiter" },
];

export const CATEGORIES: Category[] = [
  { id: "cat_breakfast", name: "Breakfast", nameAm: "ቁርስ" },
  { id: "cat_mains", name: "Mains", nameAm: "ዋና ምግብ" },
  { id: "cat_fasting", name: "Fasting", nameAm: "የጾም" },
  { id: "cat_sides", name: "Sides", nameAm: "ተጨማሪ" },
  { id: "cat_drinks", name: "Drinks", nameAm: "መጠጦች" },
];

export const PRODUCTS: Product[] = [
  { id: "p1", categoryId: "cat_breakfast", name: "Chechebsa", nameAm: "ቸቸብሳ", price: 110, available: true },
  { id: "p2", categoryId: "cat_breakfast", name: "Firfir", nameAm: "ፍርፍር", price: 120, available: true },
  { id: "p3", categoryId: "cat_breakfast", name: "Genfo", nameAm: "ገንፎ", price: 95, available: true },
  { id: "p4", categoryId: "cat_breakfast", name: "Kinche", nameAm: "ቂንጬ", price: 90, available: true },
  { id: "p5", categoryId: "cat_mains", name: "Doro Wot", nameAm: "ዶሮ ወጥ", price: 320, available: true },
  { id: "p6", categoryId: "cat_mains", name: "Kitfo", nameAm: "ክትፎ", price: 340, available: true },
  { id: "p7", categoryId: "cat_mains", name: "Special Kitfo", nameAm: "ስፔሻል ክትፎ", price: 390, available: true },
  { id: "p8", categoryId: "cat_mains", name: "Beef Tibs", nameAm: "የበሬ ጥብስ", price: 280, available: true },
  { id: "p9", categoryId: "cat_mains", name: "Lamb Tibs", nameAm: "የበግ ጥብስ", price: 350, available: true },
  { id: "p10", categoryId: "cat_mains", name: "Awaze Tibs", nameAm: "አዋዜ ጥብስ", price: 290, available: true },
  { id: "p11", categoryId: "cat_mains", name: "Key Wot", nameAm: "ቀይ ወጥ", price: 240, available: true },
  { id: "p12", categoryId: "cat_mains", name: "Dulet", nameAm: "ዱለት", price: 220, available: true },
  { id: "p13", categoryId: "cat_mains", name: "Meat Combo", nameAm: "የፍስክ በያይነቱ", price: 360, available: true },
  { id: "p14", categoryId: "cat_fasting", name: "Shiro", nameAm: "ሽሮ", price: 130, available: true },
  { id: "p15", categoryId: "cat_fasting", name: "Misir Wot", nameAm: "ምስር ወጥ", price: 120, available: true },
  { id: "p16", categoryId: "cat_fasting", name: "Gomen", nameAm: "ጎመን", price: 110, available: true },
  { id: "p17", categoryId: "cat_fasting", name: "Fasting Combo", nameAm: "የጾም በያይነቱ", price: 220, available: true },
  { id: "p18", categoryId: "cat_fasting", name: "Atkilt Wot", nameAm: "አትክልት ወጥ", price: 125, available: true },
  { id: "p19", categoryId: "cat_sides", name: "Injera Basket", nameAm: "እንጀራ", price: 40, available: true },
  { id: "p20", categoryId: "cat_sides", name: "Ayib", nameAm: "አይብ", price: 50, available: true },
  { id: "p21", categoryId: "cat_sides", name: "Salad", nameAm: "ሰላጣ", price: 80, available: true },
  { id: "p22", categoryId: "cat_sides", name: "French Fries", nameAm: "ቺፕስ", price: 70, available: true },
  { id: "p23", categoryId: "cat_drinks", name: "Buna", nameAm: "ቡና", price: 50, available: true },
  { id: "p24", categoryId: "cat_drinks", name: "Macchiato", nameAm: "ማኪያቶ", price: 45, available: true },
  { id: "p25", categoryId: "cat_drinks", name: "Shai", nameAm: "ሻይ", price: 30, available: true },
  { id: "p26", categoryId: "cat_drinks", name: "Fresh Juice", nameAm: "ፍሬ ጭማቂ", price: 75, available: true },
  { id: "p27", categoryId: "cat_drinks", name: "Soft Drink", nameAm: "ለስላሳ", price: 40, available: true },
  { id: "p28", categoryId: "cat_drinks", name: "Water", nameAm: "ውሃ", price: 25, available: true },
  { id: "p29", categoryId: "cat_drinks", name: "Tej", nameAm: "ጠጅ", price: 90, available: true },
  { id: "p30", categoryId: "cat_drinks", name: "Draft Beer", nameAm: "ቢራ", price: 80, available: true },
];

export const TABLES: FloorTable[] = [
  { id: "t1", label: "T1", seats: 2, status: "available" },
  { id: "t2", label: "T2", seats: 2, status: "available" },
  { id: "t3", label: "T3", seats: 4, status: "occupied", orderId: "o_live_1" },
  { id: "t4", label: "T4", seats: 4, status: "available" },
  { id: "t5", label: "T5", seats: 4, status: "available" },
  { id: "t6", label: "T6", seats: 6, status: "available" },
  { id: "t7", label: "T7", seats: 4, status: "occupied", orderId: "o_live_2" },
  { id: "t8", label: "T8", seats: 2, status: "available" },
  { id: "t9", label: "T9", seats: 8, status: "available" },
  { id: "t10", label: "T10", seats: 4, status: "available" },
  { id: "t11", label: "T11", seats: 4, status: "reserved" },
  { id: "t12", label: "T12", seats: 6, status: "available" },
];

function hoursAgo(hours: number): number {
  return Date.now() - hours * 60 * 60 * 1000;
}

function daysAgo(days: number, hour = 14): number {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, 12, 0, 0);
  return d.getTime();
}

export function seedOrders(): Order[] {
  const now = Date.now();
  return [
    {
      id: "o_live_1",
      number: 104,
      tableId: "t3",
      tableLabel: "T3",
      staffId: "s_waiter",
      staffName: "Abel Tesfaye",
      type: "dine-in",
      status: "preparing",
      paid: false,
      createdAt: now - 12 * 60 * 1000,
      updatedAt: now - 8 * 60 * 1000,
      items: [
        { id: "li1", productId: "p5", name: "Doro Wot", nameAm: "ዶሮ ወጥ", price: 320, qty: 1 },
        { id: "li2", productId: "p19", name: "Injera Basket", nameAm: "እንጀራ", price: 40, qty: 2 },
        { id: "li3", productId: "p23", name: "Buna", nameAm: "ቡና", price: 50, qty: 2 },
      ],
    },
    {
      id: "o_live_2",
      number: 105,
      tableId: "t7",
      tableLabel: "T7",
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "dine-in",
      status: "new",
      paid: false,
      createdAt: now - 4 * 60 * 1000,
      updatedAt: now - 4 * 60 * 1000,
      items: [
        { id: "li4", productId: "p6", name: "Kitfo", nameAm: "ክትፎ", price: 340, qty: 2 },
        { id: "li5", productId: "p17", name: "Fasting Combo", nameAm: "የጾም በያይነቱ", price: 220, qty: 1 },
        { id: "li6", productId: "p26", name: "Fresh Juice", nameAm: "ፍሬ ጭማቂ", price: 75, qty: 2 },
      ],
    },
    {
      id: "o_live_3",
      number: 106,
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "takeaway",
      status: "ready",
      paid: true,
      paymentMethod: "telebirr",
      createdAt: now - 22 * 60 * 1000,
      updatedAt: now - 3 * 60 * 1000,
      items: [
        { id: "li7", productId: "p8", name: "Beef Tibs", nameAm: "የበሬ ጥብስ", price: 280, qty: 1 },
        { id: "li8", productId: "p19", name: "Injera Basket", nameAm: "እንጀራ", price: 40, qty: 1 },
      ],
    },
    {
      id: "o_done_1",
      number: 101,
      tableId: "t1",
      tableLabel: "T1",
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "cash",
      tendered: 600,
      createdAt: hoursAgo(3),
      updatedAt: hoursAgo(2.4),
      items: [
        { id: "li9", productId: "p14", name: "Shiro", nameAm: "ሽሮ", price: 130, qty: 2 },
        { id: "li10", productId: "p24", name: "Macchiato", nameAm: "ማኪያቶ", price: 45, qty: 2 },
      ],
    },
    {
      id: "o_done_2",
      number: 102,
      staffId: "s_manager",
      staffName: "Yonas Tadesse",
      type: "takeaway",
      status: "completed",
      paid: true,
      paymentMethod: "card",
      createdAt: hoursAgo(5),
      updatedAt: hoursAgo(4.5),
      items: [
        { id: "li11", productId: "p13", name: "Meat Combo", nameAm: "የፍስክ በያይነቱ", price: 360, qty: 1 },
        { id: "li12", productId: "p30", name: "Draft Beer", nameAm: "ቢራ", price: 80, qty: 2 },
      ],
    },
    {
      id: "o_done_3",
      number: 103,
      tableId: "t6",
      tableLabel: "T6",
      staffId: "s_waiter",
      staffName: "Abel Tesfaye",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "telebirr",
      createdAt: hoursAgo(6.5),
      updatedAt: hoursAgo(5.8),
      items: [
        { id: "li13", productId: "p5", name: "Doro Wot", nameAm: "ዶሮ ወጥ", price: 320, qty: 2 },
        { id: "li14", productId: "p9", name: "Lamb Tibs", nameAm: "የበግ ጥብስ", price: 350, qty: 1 },
        { id: "li15", productId: "p29", name: "Tej", nameAm: "ጠጅ", price: 90, qty: 3 },
      ],
    },
    {
      id: "o_d1",
      number: 88,
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "cash",
      createdAt: daysAgo(1, 13),
      updatedAt: daysAgo(1, 14),
      items: [
        { id: "li16", productId: "p7", name: "Special Kitfo", nameAm: "ስፔሻል ክትፎ", price: 390, qty: 2 },
        { id: "li17", productId: "p26", name: "Fresh Juice", nameAm: "ፍሬ ጭማቂ", price: 75, qty: 2 },
      ],
    },
    {
      id: "o_d2",
      number: 76,
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "takeaway",
      status: "completed",
      paid: true,
      paymentMethod: "card",
      createdAt: daysAgo(2, 19),
      updatedAt: daysAgo(2, 19),
      items: [
        { id: "li18", productId: "p17", name: "Fasting Combo", nameAm: "የጾም በያይነቱ", price: 220, qty: 3 },
      ],
    },
    {
      id: "o_d3",
      number: 64,
      staffId: "s_manager",
      staffName: "Yonas Tadesse",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "telebirr",
      createdAt: daysAgo(3, 12),
      updatedAt: daysAgo(3, 13),
      items: [
        { id: "li19", productId: "p8", name: "Beef Tibs", nameAm: "የበሬ ጥብስ", price: 280, qty: 4 },
        { id: "li20", productId: "p19", name: "Injera Basket", nameAm: "እንጀራ", price: 40, qty: 4 },
      ],
    },
    {
      id: "o_d4",
      number: 51,
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "cash",
      createdAt: daysAgo(4, 18),
      updatedAt: daysAgo(4, 19),
      items: [
        { id: "li21", productId: "p11", name: "Key Wot", nameAm: "ቀይ ወጥ", price: 240, qty: 2 },
        { id: "li22", productId: "p23", name: "Buna", nameAm: "ቡና", price: 50, qty: 4 },
      ],
    },
    {
      id: "o_d5",
      number: 40,
      staffId: "s_waiter",
      staffName: "Abel Tesfaye",
      type: "takeaway",
      status: "completed",
      paid: true,
      paymentMethod: "telebirr",
      createdAt: daysAgo(5, 11),
      updatedAt: daysAgo(5, 11),
      items: [
        { id: "li23", productId: "p1", name: "Chechebsa", nameAm: "ቸቸብሳ", price: 110, qty: 3 },
        { id: "li24", productId: "p24", name: "Macchiato", nameAm: "ማኪያቶ", price: 45, qty: 3 },
      ],
    },
    {
      id: "o_d6",
      number: 33,
      staffId: "s_cashier",
      staffName: "Marta Alemu",
      type: "dine-in",
      status: "completed",
      paid: true,
      paymentMethod: "card",
      createdAt: daysAgo(6, 20),
      updatedAt: daysAgo(6, 21),
      items: [
        { id: "li25", productId: "p13", name: "Meat Combo", nameAm: "የፍስክ በያይነቱ", price: 360, qty: 2 },
        { id: "li26", productId: "p29", name: "Tej", nameAm: "ጠጅ", price: 90, qty: 4 },
      ],
    },
  ];
}
