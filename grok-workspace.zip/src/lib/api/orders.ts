import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { requireRestaurant } from "@/lib/api/tenant";
import { cartTotals, hasFeature, type Order, type OrderStatus } from "@/lib/types";
import { uid } from "@/lib/utils";

const itemSchema = z.object({
  productId: z.string(),
  name: z.string(),
  nameAm: z.string(),
  price: z.number().int(),
  qty: z.number().int().min(1),
});

async function loadOrders(sql: Awaited<ReturnType<typeof import("@/lib/db").getSql>>, restaurantId: string): Promise<Order[]> {
  const orders = await sql<{
    id: string;
    number: number;
    table_id: string | null;
    table_label: string | null;
    staff_id: string | null;
    staff_name: string;
    status: OrderStatus;
    paid: boolean;
    payment_method: "cash" | "card" | "telebirr" | null;
    tendered: number | null;
    discount: number;
    order_type: "dine-in" | "takeaway";
    created_at: string;
    updated_at: string;
  }>`
    select id, number, table_id, table_label, staff_id, staff_name, status, paid, payment_method, tendered, discount, order_type, created_at, updated_at
    from orders where restaurant_id = ${restaurantId}
    order by created_at desc
    limit 80
  `;
  if (orders.length === 0) return [];
  const ids = orders.map((o) => o.id);
  const items = await sql<{
    id: string;
    order_id: string;
    product_id: string | null;
    name: string;
    name_am: string;
    price: number;
    qty: number;
  }>`
    select id, order_id, product_id, name, name_am, price, qty
    from order_items where restaurant_id = ${restaurantId}
  `;
  const byOrder = new Map<string, Order["items"]>();
  for (const it of items) {
    if (!ids.includes(it.order_id)) continue;
    const list = byOrder.get(it.order_id) ?? [];
    list.push({
      id: it.id,
      productId: it.product_id ?? "",
      name: it.name,
      nameAm: it.name_am,
      price: Number(it.price),
      qty: Number(it.qty),
    });
    byOrder.set(it.order_id, list);
  }
  return orders.map((o) => ({
    id: o.id,
    number: Number(o.number),
    tableId: o.table_id ?? undefined,
    tableLabel: o.table_label ?? undefined,
    staffId: o.staff_id ?? "",
    staffName: o.staff_name,
    items: byOrder.get(o.id) ?? [],
    status: o.status,
    paid: o.paid,
    paymentMethod: o.payment_method ?? undefined,
    tendered: o.tendered != null ? Number(o.tendered) : undefined,
    discount: Number(o.discount),
    createdAt: new Date(o.created_at).getTime(),
    updatedAt: new Date(o.updated_at).getTime(),
    type: o.order_type,
  }));
}

export const listOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    return loadOrders(sql, restaurant.id);
  });

export const placeOrder = createServerFn({ method: "POST" })
  .validator(
    z.object({
      items: z.array(itemSchema).min(1),
      tableId: z.string().optional(),
      staffId: z.string().optional(),
      staffName: z.string().default("Staff"),
      pay: z.boolean(),
      paymentMethod: z.enum(["cash", "card", "telebirr"]).optional(),
      tendered: z.number().int().optional(),
      discount: z.number().int().min(0).default(0),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
    if (entitlements.billingLocked) throw new Error("BILLING_LOCKED");
    if (data.discount > 0 && !hasFeature(entitlements, "discounts")) throw new Error("DISCOUNTS_LOCKED");

    let tableLabel: string | undefined;
    if (data.tableId) {
      const tables = await sql<{ label: string; order_id: string | null }>`
        select label, order_id from dining_tables
        where id = ${data.tableId} and restaurant_id = ${restaurant.id}
      `;
      if (!tables[0]) throw new Error("TABLE_NOT_FOUND");
      tableLabel = tables[0].label;
      if (tables[0].order_id && !data.pay) {
        const existingId = tables[0].order_id;
        await sql`delete from order_items where order_id = ${existingId} and restaurant_id = ${restaurant.id}`;
        for (const item of data.items) {
          await sql`
            insert into order_items (id, order_id, restaurant_id, product_id, name, name_am, price, qty)
            values (${uid("li")}, ${existingId}, ${restaurant.id}, ${item.productId}, ${item.name}, ${item.nameAm}, ${item.price}, ${item.qty})
          `;
        }
        await sql`
          update orders set discount = ${data.discount}, updated_at = now(),
            paid = case when ${data.pay} then true else paid end,
            payment_method = coalesce(${data.paymentMethod ?? null}, payment_method),
            tendered = coalesce(${data.tendered ?? null}, tendered)
          where id = ${existingId} and restaurant_id = ${restaurant.id}
        `;
        return { id: existingId, merged: true };
      }
    } else if (!data.pay) {
      throw new Error("TAKEAWAY_REQUIRES_PAY");
    }

    const totals = cartTotals(data.items, data.discount);
    if (data.pay && data.paymentMethod === "cash" && data.tendered != null && data.tendered < totals.total) {
      throw new Error("INSUFFICIENT");
    }

    const [{ n }] = await sql<{ n: number }>`
      select coalesce(max(number), 100)::int as n from orders where restaurant_id = ${restaurant.id}
    `;
    const id = uid("o");
    await sql`
      insert into orders (id, restaurant_id, number, table_id, table_label, staff_id, staff_name, status, paid, payment_method, tendered, discount, order_type)
      values (
        ${id}, ${restaurant.id}, ${n + 1}, ${data.tableId ?? null}, ${tableLabel ?? null},
        ${data.staffId ?? null}, ${data.staffName}, 'new', ${data.pay},
        ${data.paymentMethod ?? null}, ${data.tendered ?? null}, ${data.discount},
        ${data.tableId ? "dine-in" : "takeaway"}
      )
    `;
    for (const item of data.items) {
      await sql`
        insert into order_items (id, order_id, restaurant_id, product_id, name, name_am, price, qty)
        values (${uid("li")}, ${id}, ${restaurant.id}, ${item.productId}, ${item.name}, ${item.nameAm}, ${item.price}, ${item.qty})
      `;
    }
    if (data.tableId) {
      await sql`
        update dining_tables set status = 'occupied', order_id = ${id}
        where id = ${data.tableId} and restaurant_id = ${restaurant.id}
      `;
    }
    return { id, number: n + 1, merged: false };
  });

export const advanceOrder = createServerFn({ method: "POST" })
  .validator(z.object({ orderId: z.string() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
    if (!hasFeature(entitlements, "kds") && entitlements.billingLocked) throw new Error("KDS_LOCKED");
    const rows = await sql<{ status: OrderStatus }>`
      select status from orders where id = ${data.orderId} and restaurant_id = ${restaurant.id}
    `;
    const cur = rows[0]?.status;
    if (!cur) throw new Error("NOT_FOUND");
    const next: Record<OrderStatus, OrderStatus> = {
      new: "preparing",
      preparing: "ready",
      ready: "completed",
      completed: "completed",
    };
    await sql`
      update orders set status = ${next[cur]}, updated_at = now()
      where id = ${data.orderId} and restaurant_id = ${restaurant.id}
    `;
    return { status: next[cur] };
  });

export const closeTable = createServerFn({ method: "POST" })
  .validator(z.object({ tableId: z.string() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    const tables = await sql<{ order_id: string | null }>`
      select order_id from dining_tables where id = ${data.tableId} and restaurant_id = ${restaurant.id}
    `;
    const table = tables[0];
    if (!table) throw new Error("NOT_FOUND");
    if (table.order_id) {
      const orders = await sql<{ paid: boolean }>`
        select paid from orders where id = ${table.order_id} and restaurant_id = ${restaurant.id}
      `;
      if (orders[0] && !orders[0].paid) throw new Error("UNPAID");
      await sql`
        update orders set status = 'completed', updated_at = now()
        where id = ${table.order_id} and restaurant_id = ${restaurant.id}
      `;
    }
    await sql`
      update dining_tables set status = 'available', order_id = null
      where id = ${data.tableId} and restaurant_id = ${restaurant.id}
    `;
    return { ok: true };
  });
