import type { Entitlements, Lang, PlatformRole, RestaurantDTO, RestaurantStatus } from "@/lib/types";
import type { Sql } from "@/lib/db";
import { CATEGORIES, PRODUCTS, STAFF, TABLES } from "@/lib/seed";
import { uid } from "@/lib/utils";

type ProfileRow = {
  user_id: string;
  platform_role: PlatformRole;
  restaurant_id: string | null;
  email_verified: boolean;
  display_name: string | null;
};

type RestaurantRow = {
  id: string;
  owner_user_id: string;
  name: string;
  slug: string;
  status: RestaurantStatus;
  plan_id: string;
  currency: string;
  language: Lang;
  receipt_footer: string;
  trial_ends_at: string;
};

export function mapRestaurant(row: RestaurantRow): RestaurantDTO {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    status: row.status,
    planId: row.plan_id,
    currency: row.currency,
    language: row.language,
    receiptFooter: row.receipt_footer,
    trialEndsAt: String(row.trial_ends_at),
    ownerUserId: row.owner_user_id,
  };
}

export function trialDaysLeft(trialEndsAt: string): number {
  const end = new Date(trialEndsAt).getTime();
  return Math.max(0, Math.ceil((end - Date.now()) / 86400000));
}

export async function getOrCreateProfile(
  sql: Sql,
  userId: string,
  opts?: { displayName?: string | null; verified?: boolean },
): Promise<ProfileRow> {
  const existing = await sql<ProfileRow>`
    select user_id, platform_role, restaurant_id, email_verified, display_name
    from profiles where user_id = ${userId}
  `;
  if (existing[0]) return existing[0];

  const admins = await sql<{ n: number }>`select count(*)::int as n from profiles where platform_role = 'super_admin'`;
  const role: PlatformRole = (admins[0]?.n ?? 0) === 0 ? "super_admin" : "owner";
  const verified = opts?.verified ?? role === "super_admin";
  await sql`
    insert into profiles (user_id, platform_role, email_verified, display_name)
    values (${userId}, ${role}, ${verified}, ${opts?.displayName ?? null})
  `;
  return {
    user_id: userId,
    platform_role: role,
    restaurant_id: null,
    email_verified: verified,
    display_name: opts?.displayName ?? null,
  };
}

export async function getEntitlements(sql: Sql, restaurant: RestaurantDTO): Promise<Entitlements> {
  const subs = await sql<{ plan_id: string; status: string; current_period_end: string | null }>`
    select plan_id, status, current_period_end from subscriptions
    where restaurant_id = ${restaurant.id}
    order by created_at desc limit 1
  `;
  const sub = subs[0];
  const days = trialDaysLeft(restaurant.trialEndsAt);
  const paidActive = sub?.status === "active";
  const billingLocked =
    restaurant.status !== "active" || (!paidActive && days <= 0);
  const planId = paidActive ? sub.plan_id : days > 0 ? "plan_trial" : restaurant.planId;

  const planRows = await sql<{ id: string; name: string }>`select id, name from plans where id = ${planId}`;
  const feats = await sql<{ key: string; kind: string; enabled: boolean; limit_value: number | null }>`
    select f.key, f.kind, pf.enabled, pf.limit_value
    from plan_features pf
    join features f on f.id = pf.feature_id
    where pf.plan_id = ${planId}
  `;

  const toggles: Record<string, boolean> = {};
  const limits: Record<string, number> = {};
  for (const f of feats) {
    if (f.kind === "limit") limits[f.key] = f.limit_value ?? 0;
    else toggles[f.key] = Boolean(f.enabled) && !billingLocked;
  }

  return {
    planId,
    planName: planRows[0]?.name ?? "Trial",
    trialDaysLeft: days,
    subscriptionStatus: paidActive ? "active" : days > 0 ? "trialing" : "expired",
    billingLocked,
    toggles,
    limits,
  };
}

export async function requireRestaurant(sql: Sql, userId: string) {
  const profile = await getOrCreateProfile(sql, userId);
  if (!profile.restaurant_id) {
    throw new Error("NO_RESTAURANT");
  }
  const rows = await sql<RestaurantRow>`
    select id, owner_user_id, name, slug, status, plan_id, currency, language, receipt_footer, trial_ends_at
    from restaurants where id = ${profile.restaurant_id}
  `;
  const row = rows[0];
  if (!row) throw new Error("NO_RESTAURANT");
  if (row.owner_user_id !== userId && profile.platform_role !== "super_admin") {
    throw new Error("FORBIDDEN");
  }
  const restaurant = mapRestaurant(row);
  const entitlements = await getEntitlements(sql, restaurant);
  return { profile, restaurant, entitlements };
}

export async function seedRestaurantCatalog(sql: Sql, restaurantId: string) {
  const catIds = new Map<string, string>();
  for (const [i, c] of CATEGORIES.entries()) {
    const id = uid("cat");
    catIds.set(c.id, id);
    await sql`
      insert into categories (id, restaurant_id, name, name_am, sort_order)
      values (${id}, ${restaurantId}, ${c.name}, ${c.nameAm}, ${i})
    `;
  }
  for (const p of PRODUCTS) {
    const categoryId = catIds.get(p.categoryId);
    if (!categoryId) continue;
    await sql`
      insert into products (id, restaurant_id, category_id, name, name_am, price, available)
      values (${uid("p")}, ${restaurantId}, ${categoryId}, ${p.name}, ${p.nameAm}, ${p.price}, ${p.available})
    `;
  }
  for (const t of TABLES) {
    await sql`
      insert into dining_tables (id, restaurant_id, label, seats, status)
      values (${uid("t")}, ${restaurantId}, ${t.label}, ${t.seats}, 'available')
    `;
  }
  for (const s of STAFF) {
    await sql`
      insert into staff (id, restaurant_id, name, name_am, pin, role, active)
      values (${uid("s")}, ${restaurantId}, ${s.name}, ${s.nameAm}, ${s.pin}, ${s.role}, true)
    `;
  }
}

export function slugify(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 24);
  return `${base || "restaurant"}-${uid("r").slice(-5)}`;
}
