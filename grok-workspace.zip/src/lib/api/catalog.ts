import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { requireRestaurant } from "@/lib/api/tenant";
import { limitOf } from "@/lib/types";
import { uid } from "@/lib/utils";

export const getCatalog = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
    const categories = await sql<{ id: string; name: string; name_am: string }>`
      select id, name, name_am from categories where restaurant_id = ${restaurant.id} order by sort_order, name
    `;
    const products = await sql<{
      id: string;
      category_id: string;
      name: string;
      name_am: string;
      price: number;
      available: boolean;
    }>`
      select id, category_id, name, name_am, price, available
      from products where restaurant_id = ${restaurant.id} order by name
    `;
    const tables = await sql<{
      id: string;
      label: string;
      seats: number;
      status: "available" | "occupied" | "reserved";
      order_id: string | null;
    }>`
      select id, label, seats, status, order_id from dining_tables
      where restaurant_id = ${restaurant.id} order by label
    `;
    const staff = await sql<{
      id: string;
      name: string;
      name_am: string;
      pin: string;
      role: "admin" | "manager" | "cashier" | "waiter" | "kitchen";
      active: boolean;
    }>`
      select id, name, name_am, pin, role, active from staff
      where restaurant_id = ${restaurant.id} order by name
    `;
    return {
      restaurant,
      entitlements,
      categories: categories.map((c) => ({ id: c.id, name: c.name, nameAm: c.name_am })),
      products: products.map((p) => ({
        id: p.id,
        categoryId: p.category_id,
        name: p.name,
        nameAm: p.name_am,
        price: Number(p.price),
        available: p.available,
      })),
      tables: tables.map((t) => ({
        id: t.id,
        label: t.label,
        seats: Number(t.seats),
        status: t.status,
        orderId: t.order_id ?? undefined,
      })),
      staff: staff.map((s) => ({
        id: s.id,
        name: s.name,
        nameAm: s.name_am,
        pin: s.pin,
        role: s.role,
        active: s.active,
      })),
    };
  });

export const staffPinLogin = createServerFn({ method: "POST" })
  .validator(z.object({ pin: z.string().length(4) }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    const rows = await sql<{
      id: string;
      name: string;
      name_am: string;
      pin: string;
      role: "admin" | "manager" | "cashier" | "waiter" | "kitchen";
    }>`
      select id, name, name_am, pin, role from staff
      where restaurant_id = ${restaurant.id} and pin = ${data.pin} and active = true
    `;
    const s = rows[0];
    if (!s) return null;
    return { id: s.id, name: s.name, nameAm: s.name_am, pin: s.pin, role: s.role };
  });

export const toggleProduct = createServerFn({ method: "POST" })
  .validator(z.object({ productId: z.string() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    await sql`
      update products set available = not available
      where id = ${data.productId} and restaurant_id = ${restaurant.id}
    `;
    return { ok: true };
  });

export const addStaff = createServerFn({ method: "POST" })
  .validator(
    z.object({
      name: z.string().trim().min(2),
      nameAm: z.string().trim().default(""),
      pin: z.string().regex(/^\d{4}$/),
      role: z.enum(["admin", "manager", "cashier", "waiter", "kitchen"]),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
    const [{ n }] = await sql<{ n: number }>`
      select count(*)::int as n from staff where restaurant_id = ${restaurant.id} and active = true
    `;
    const cap = limitOf(entitlements, "max_staff");
    if (cap !== -1 && n >= cap) throw new Error("STAFF_LIMIT");
    const dup = await sql`select id from staff where restaurant_id = ${restaurant.id} and pin = ${data.pin}`;
    if (dup[0]) throw new Error("PIN_TAKEN");
    await sql`
      insert into staff (id, restaurant_id, name, name_am, pin, role, active)
      values (${uid("s")}, ${restaurant.id}, ${data.name}, ${data.nameAm || data.name}, ${data.pin}, ${data.role}, true)
    `;
    return { ok: true };
  });

export const addTable = createServerFn({ method: "POST" })
  .validator(z.object({ label: z.string().trim().min(1), seats: z.number().int().min(1).max(20) }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
    const [{ n }] = await sql<{ n: number }>`
      select count(*)::int as n from dining_tables where restaurant_id = ${restaurant.id}
    `;
    const cap = limitOf(entitlements, "max_tables");
    if (cap !== -1 && n >= cap) throw new Error("TABLE_LIMIT");
    await sql`
      insert into dining_tables (id, restaurant_id, label, seats, status)
      values (${uid("t")}, ${restaurant.id}, ${data.label}, ${data.seats}, 'available')
    `;
    return { ok: true };
  });

export const updateSettings = createServerFn({ method: "POST" })
  .validator(
    z.object({
      name: z.string().trim().min(2).optional(),
      language: z.enum(["en", "am"]).optional(),
      receiptFooter: z.string().max(200).optional(),
      currency: z.string().trim().min(3).max(8).optional(),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    await sql`
      update restaurants
      set name = coalesce(${data.name ?? null}, name),
          language = coalesce(${data.language ?? null}, language),
          receipt_footer = coalesce(${data.receiptFooter ?? null}, receipt_footer),
          currency = coalesce(${data.currency ?? null}, currency)
      where id = ${restaurant.id} and owner_user_id = ${context.userId}
    `;
    return { ok: true };
  });
