import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { getOrCreateProfile, requireRestaurant } from "@/lib/api/tenant";
import { uid } from "@/lib/utils";
import type { PlanDTO } from "@/lib/types";

export const listPlans = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<PlanDTO[]> => {
    const sql = await getSql();
    await getOrCreateProfile(sql, context.userId);
    const plans = await sql<{
      id: string;
      name: string;
      slug: string;
      price_etb: number;
      billing_interval: string;
      description: string;
    }>`
      select id, name, slug, price_etb, billing_interval, description
      from plans where is_public = true order by sort_order
    `;
    const feats = await sql<{
      plan_id: string;
      key: string;
      name: string;
      enabled: boolean;
      limit_value: number | null;
    }>`
      select pf.plan_id, f.key, f.name, pf.enabled, pf.limit_value
      from plan_features pf
      join features f on f.id = pf.feature_id
    `;
    return plans.map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      priceEtb: Number(p.price_etb),
      interval: p.billing_interval,
      description: p.description,
      features: feats
        .filter((f) => f.plan_id === p.id)
        .map((f) => ({
          key: f.key,
          name: f.name,
          enabled: f.enabled,
          limit: f.limit_value == null ? null : Number(f.limit_value),
        })),
    }));
  });

export const startCheckout = createServerFn({ method: "POST" })
  .validator(
    z.object({
      planId: z.string(),
      provider: z.enum(["stripe", "chapa", "telebirr", "card"]),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    const plans = await sql<{ id: string; price_etb: number }>`
      select id, price_etb from plans where id = ${data.planId}
    `;
    const plan = plans[0];
    if (!plan) throw new Error("PLAN_NOT_FOUND");
    const paymentId = uid("pay");
    await sql`
      insert into payments (id, restaurant_id, plan_id, amount_etb, provider, status)
      values (${paymentId}, ${restaurant.id}, ${plan.id}, ${plan.price_etb}, ${data.provider}, 'pending')
    `;
    return {
      paymentId,
      amountEtb: Number(plan.price_etb),
      provider: data.provider,
      checkoutHint:
        data.provider === "chapa"
          ? "Chapa hosted checkout will open here."
          : data.provider === "telebirr"
            ? "Telebirr STK / USSD prompt will open here."
            : data.provider === "stripe"
              ? "Stripe Checkout session will be created here."
              : "Card fields will be collected by your processor.",
    };
  });

export const confirmSandboxPayment = createServerFn({ method: "POST" })
  .validator(z.object({ paymentId: z.string() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const { restaurant } = await requireRestaurant(sql, context.userId);
    const pays = await sql<{ plan_id: string; status: string }>`
      select plan_id, status from payments
      where id = ${data.paymentId} and restaurant_id = ${restaurant.id}
    `;
    const pay = pays[0];
    if (!pay) throw new Error("NOT_FOUND");
    const periodEnd = new Date(Date.now() + 30 * 86400000).toISOString();
    await sql`
      update payments set status = 'completed' where id = ${data.paymentId} and restaurant_id = ${restaurant.id}
    `;
    await sql`
      insert into subscriptions (id, restaurant_id, plan_id, status, current_period_end)
      values (${uid("sub")}, ${restaurant.id}, ${pay.plan_id}, 'active', ${periodEnd})
    `;
    await sql`
      update restaurants set plan_id = ${pay.plan_id}, status = 'active'
      where id = ${restaurant.id} and owner_user_id = ${context.userId}
    `;
    return { ok: true, planId: pay.plan_id };
  });
