import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { getOrCreateProfile, trialDaysLeft } from "@/lib/api/tenant";

async function requireSuperAdmin(userId: string) {
  const sql = await getSql();
  const profile = await getOrCreateProfile(sql, userId);
  if (profile.platform_role !== "super_admin") throw new Error("FORBIDDEN");
  return { sql, profile };
}

export const platformOverview = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { sql } = await requireSuperAdmin(context.userId);
    const restaurants = await sql<{
      id: string;
      name: string;
      slug: string;
      status: string;
      plan_id: string;
      owner_user_id: string;
      trial_ends_at: string;
      created_at: string;
    }>`
      select id, name, slug, status, plan_id, owner_user_id, trial_ends_at, created_at
      from restaurants order by created_at desc
    `;
    const [{ n: owners }] = await sql<{ n: number }>`select count(*)::int as n from profiles`;
    const [{ n: active }] = await sql<{ n: number }>`select count(*)::int as n from restaurants where status = 'active'`;
    const [{ n: pending }] = await sql<{ n: number }>`select count(*)::int as n from restaurants where status = 'pending'`;
    const plans = await sql<{ id: string; name: string; slug: string; price_etb: number }>`
      select id, name, slug, price_etb from plans order by sort_order
    `;
    const features = await sql<{
      plan_id: string;
      feature_id: string;
      key: string;
      name: string;
      kind: string;
      enabled: boolean;
      limit_value: number | null;
    }>`
      select pf.plan_id, pf.feature_id, f.key, f.name, f.kind, pf.enabled, pf.limit_value
      from plan_features pf join features f on f.id = pf.feature_id
    `;
    return {
      stats: { restaurants: restaurants.length, owners, active, pending },
      restaurants: restaurants.map((r) => ({
        id: r.id,
        name: r.name,
        slug: r.slug,
        status: r.status,
        planId: r.plan_id,
        ownerUserId: r.owner_user_id,
        trialDaysLeft: trialDaysLeft(String(r.trial_ends_at)),
        createdAt: String(r.created_at),
      })),
      plans: plans.map((p) => ({
        id: p.id,
        name: p.name,
        slug: p.slug,
        priceEtb: Number(p.price_etb),
        features: features
          .filter((f) => f.plan_id === p.id)
          .map((f) => ({
            featureId: f.feature_id,
            key: f.key,
            name: f.name,
            kind: f.kind,
            enabled: f.enabled,
            limit: f.limit_value == null ? null : Number(f.limit_value),
          })),
      })),
    };
  });

export const setRestaurantStatus = createServerFn({ method: "POST" })
  .validator(z.object({ restaurantId: z.string(), status: z.enum(["pending", "active", "suspended", "rejected"]) }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { sql } = await requireSuperAdmin(context.userId);
    await sql`update restaurants set status = ${data.status} where id = ${data.restaurantId}`;
    return { ok: true };
  });

export const setPlanFeature = createServerFn({ method: "POST" })
  .validator(
    z.object({
      planId: z.string(),
      featureId: z.string(),
      enabled: z.boolean(),
      limit: z.number().int().nullable().optional(),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { sql } = await requireSuperAdmin(context.userId);
    await sql`
      update plan_features
      set enabled = ${data.enabled},
          limit_value = coalesce(${data.limit ?? null}, limit_value)
      where plan_id = ${data.planId} and feature_id = ${data.featureId}
    `;
    return { ok: true };
  });

export const setPlanPrice = createServerFn({ method: "POST" })
  .validator(z.object({ planId: z.string(), priceEtb: z.number().int().min(0) }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { sql } = await requireSuperAdmin(context.userId);
    await sql`update plans set price_etb = ${data.priceEtb} where id = ${data.planId}`;
    return { ok: true };
  });
