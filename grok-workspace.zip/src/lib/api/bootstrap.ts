import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import {
  getEntitlements,
  getOrCreateProfile,
  mapRestaurant,
  seedRestaurantCatalog,
  slugify,
  trialDaysLeft,
} from "@/lib/api/tenant";
import type { Bootstrap } from "@/lib/types";
import { uid } from "@/lib/utils";

export const getBootstrap = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Bootstrap> => {
    const sql = await getSql();
    const profileRow = await getOrCreateProfile(sql, context.userId);
    const profile = {
      userId: profileRow.user_id,
      platformRole: profileRow.platform_role,
      emailVerified: profileRow.email_verified,
      displayName: profileRow.display_name,
      restaurantId: profileRow.restaurant_id,
    };
    if (!profileRow.restaurant_id) {
      return { profile, restaurant: null, entitlements: null };
    }
    const rows = await sql<Parameters<typeof mapRestaurant>[0]>`
      select id, owner_user_id, name, slug, status, plan_id, currency, language, receipt_footer, trial_ends_at
      from restaurants where id = ${profileRow.restaurant_id}
    `;
    const restaurant = rows[0] ? mapRestaurant(rows[0]) : null;
    const entitlements = restaurant ? await getEntitlements(sql, restaurant) : null;
    return { profile, restaurant, entitlements };
  });

export const verifyEmail = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await getOrCreateProfile(sql, context.userId);
    await sql`update profiles set email_verified = true where user_id = ${context.userId}`;
    return { ok: true };
  });

export const markEmailUnverified = createServerFn({ method: "POST" })
  .validator(z.object({ displayName: z.string().trim().min(2).max(80).optional() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await getOrCreateProfile(sql, context.userId, {
      verified: false,
      displayName: data.displayName ?? null,
    });
    await sql`
      update profiles
      set email_verified = false,
          display_name = coalesce(${data.displayName ?? null}, display_name)
      where user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const createRestaurant = createServerFn({ method: "POST" })
  .validator(
    z.object({
      name: z.string().trim().min(2).max(80),
      language: z.enum(["en", "am"]).default("en"),
      ownerName: z.string().trim().min(2).max(80).optional(),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const profile = await getOrCreateProfile(sql, context.userId, {
      displayName: data.ownerName,
    });
    if (!profile.email_verified) throw new Error("EMAIL_UNVERIFIED");
    if (profile.restaurant_id) throw new Error("ALREADY_HAS_RESTAURANT");

    const id = uid("rst");
    const slug = slugify(data.name);
    // New restaurants start on a 45-day trial and can use POS immediately.
    // Super Admin can still suspend or reject from the platform panel.
    const trialEnds = new Date(Date.now() + 45 * 86400000).toISOString();

    await sql`
      insert into restaurants (id, owner_user_id, name, slug, status, plan_id, language, trial_ends_at)
      values (${id}, ${context.userId}, ${data.name}, ${slug}, 'active', 'plan_trial', ${data.language}, ${trialEnds})
    `;
    await sql`
      update profiles
      set restaurant_id = ${id},
          display_name = coalesce(${data.ownerName ?? null}, display_name)
      where user_id = ${context.userId}
    `;
    await sql`
      insert into subscriptions (id, restaurant_id, plan_id, status, current_period_end)
      values (${uid("sub")}, ${id}, 'plan_trial', 'trialing', ${trialEnds})
    `;
    await seedRestaurantCatalog(sql, id);
    return { id, status: "active" as const, trialDaysLeft: trialDaysLeft(trialEnds) };
  });
