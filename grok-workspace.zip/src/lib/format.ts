import type { Lang } from "./types";

export function formatETB(amount: number, lang: Lang): string {
  const n = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(Math.round(amount));
  return lang === "am" ? `${n} ብር` : `Br ${n}`;
}

export function formatClock(ts: number, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(ts));
}

export function formatDate(ts: number, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
    weekday: "short",
    month: "short",
    day: "numeric",
  }).format(new Date(ts));
}

export function elapsedMinutes(from: number, now: number): number {
  return Math.max(0, Math.floor((now - from) / 60000));
}

export function startOfDay(ts = Date.now()): number {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
