export type Role = "admin" | "manager" | "cashier" | "waiter" | "kitchen";
export type Lang = "en" | "am";
export type Theme = "dark" | "light";
export type OrderStatus = "new" | "preparing" | "ready" | "completed";
export type PaymentMethod = "cash" | "card" | "telebirr";
export type TableStatus = "available" | "occupied" | "reserved";
export type RestaurantStatus = "pending" | "active" | "suspended" | "rejected";
export type PlatformRole = "super_admin" | "owner";
export type BillingProvider = "stripe" | "chapa" | "telebirr" | "card";

export type FeatureKey =
  | "max_staff"
  | "max_products"
  | "max_tables"
  | "kds"
  | "reports"
  | "inventory"
  | "multi_device"
  | "printer"
  | "customers"
  | "discounts"
  | "i18n"
  | "receipt_branding";

export interface Staff {
  id: string;
  name: string;
  nameAm: string;
  pin: string;
  role: Role;
  active?: boolean;
}

export interface Category {
  id: string;
  name: string;
  nameAm: string;
}

export interface Product {
  id: string;
  categoryId: string;
  name: string;
  nameAm: string;
  price: number;
  available: boolean;
}

export interface FloorTable {
  id: string;
  label: string;
  seats: number;
  status: TableStatus;
  orderId?: string;
}

export interface LineItem {
  id: string;
  productId: string;
  name: string;
  nameAm: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  number: number;
  tableId?: string;
  tableLabel?: string;
  staffId: string;
  staffName: string;
  items: LineItem[];
  status: OrderStatus;
  paid: boolean;
  paymentMethod?: PaymentMethod;
  tendered?: number;
  discount?: number;
  createdAt: number;
  updatedAt: number;
  type: "dine-in" | "takeaway";
}

export interface CartState {
  tableId?: string;
  discount: number;
  items: LineItem[];
}

export interface Entitlements {
  planId: string;
  planName: string;
  trialDaysLeft: number;
  subscriptionStatus: string;
  billingLocked: boolean;
  toggles: Record<string, boolean>;
  limits: Record<string, number>;
}

export interface RestaurantDTO {
  id: string;
  name: string;
  slug: string;
  status: RestaurantStatus;
  planId: string;
  currency: string;
  language: Lang;
  receiptFooter: string;
  trialEndsAt: string;
  ownerUserId: string;
}

export interface Bootstrap {
  profile: {
    userId: string;
    platformRole: PlatformRole;
    emailVerified: boolean;
    displayName: string | null;
    restaurantId: string | null;
  };
  restaurant: RestaurantDTO | null;
  entitlements: Entitlements | null;
}

export interface PlanDTO {
  id: string;
  name: string;
  slug: string;
  priceEtb: number;
  interval: string;
  description: string;
  features: { key: string; name: string; enabled: boolean; limit: number | null }[];
}

export const VAT_RATE = 0.15;

export function lineTotal(item: LineItem): number {
  return item.price * item.qty;
}

export function cartTotals(items: LineItem[], discount = 0): {
  subtotal: number;
  discount: number;
  vat: number;
  total: number;
  count: number;
} {
  const subtotal = items.reduce((sum, item) => sum + lineTotal(item), 0);
  const cut = Math.min(Math.max(0, discount), subtotal);
  const after = subtotal - cut;
  const vat = Math.round(after * VAT_RATE);
  const total = after + vat;
  const count = items.reduce((sum, item) => sum + item.qty, 0);
  return { subtotal, discount: cut, vat, total, count };
}

export const ALL_ROLES: Role[] = ["admin", "manager", "cashier", "waiter", "kitchen"];
export const ADMIN_ROLES: Role[] = ["admin", "manager"];

export function hasFeature(ent: Entitlements | null | undefined, key: FeatureKey): boolean {
  if (!ent || ent.billingLocked) return false;
  if (key.startsWith("max_")) return true;
  return Boolean(ent.toggles[key]);
}

export function limitOf(ent: Entitlements | null | undefined, key: FeatureKey): number {
  if (!ent) return 0;
  return ent.limits[key] ?? 0;
}
