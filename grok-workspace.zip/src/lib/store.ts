import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  cartTotals,
  type CartState,
  type Category,
  type FloorTable,
  type Lang,
  type LineItem,
  type Order,
  type OrderStatus,
  type PaymentMethod,
  type Product,
  type Staff,
  type Theme,
} from "./types";
import { CATEGORIES, PRODUCTS, SEED_VERSION, STAFF, TABLES, seedOrders } from "./seed";
import { uid } from "./utils";

interface POSState {
  seedVersion: number;
  language: Lang;
  theme: Theme;
  session: Staff | null;
  staff: Staff[];
  categories: Category[];
  products: Product[];
  tables: FloorTable[];
  orders: Order[];
  nextOrderNumber: number;
  cart: CartState;
  setLanguage: (language: Lang) => void;
  setTheme: (theme: Theme) => void;
  login: (pin: string) => Staff | null;
  logout: () => void;
  addToCart: (product: Product) => void;
  setQty: (lineId: string, qty: number) => void;
  setDiscount: (discount: number) => void;
  clearCart: () => void;
  assignTable: (tableId?: string) => void;
  loadOrderIntoCart: (orderId: string) => void;
  sendToKitchen: () => Order | null;
  checkout: (method: PaymentMethod, tendered?: number) => Order | null;
  advanceOrder: (orderId: string) => void;
  completeOrder: (orderId: string) => void;
  closeTable: (tableId: string) => boolean;
  openTable: (tableId: string) => void;
  toggleProduct: (productId: string) => void;
  hydrateCatalog: (data: {
    staff: Staff[];
    categories: Category[];
    products: Product[];
    tables: FloorTable[];
  }) => void;
  resetDemo: () => void;
}

const noopStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

function getStorage() {
  if (typeof window === "undefined") return noopStorage;
  return window.localStorage;
}

function emptyCart(): CartState {
  return { items: [], discount: 0 };
}

function freshState() {
  return {
    seedVersion: SEED_VERSION,
    language: "en" as Lang,
    theme: "dark" as Theme,
    session: null as Staff | null,
    staff: STAFF.map((s) => ({ ...s })),
    categories: CATEGORIES.map((c) => ({ ...c })),
    products: PRODUCTS.map((p) => ({ ...p })),
    tables: TABLES.map((t) => ({ ...t })),
    orders: seedOrders(),
    nextOrderNumber: 107,
    cart: emptyCart(),
  };
}

function upsertLine(items: LineItem[], product: Product): LineItem[] {
  const existing = items.find((i) => i.productId === product.id);
  if (existing) {
    return items.map((i) =>
      i.productId === product.id ? { ...i, qty: i.qty + 1 } : i,
    );
  }
  return [
    ...items,
    {
      id: uid("li"),
      productId: product.id,
      name: product.name,
      nameAm: product.nameAm,
      price: product.price,
      qty: 1,
    },
  ];
}

export const usePOSStore = create<POSState>()(
  persist(
    (set, get) => ({
      ...freshState(),

      setLanguage: (language) => set({ language }),
      setTheme: (theme) => set({ theme }),

      login: (pin) => {
        const staff = get().staff.find((s) => s.pin === pin && s.active !== false) ?? null;
        if (staff) set({ session: staff });
        return staff;
      },

      logout: () => set({ session: null, cart: emptyCart() }),

      addToCart: (product) => {
        if (!product.available) return;
        set((s) => ({ cart: { ...s.cart, items: upsertLine(s.cart.items, product) } }));
      },

      setQty: (lineId, qty) => {
        set((s) => ({
          cart: {
            ...s.cart,
            items:
              qty <= 0
                ? s.cart.items.filter((i) => i.id !== lineId)
                : s.cart.items.map((i) => (i.id === lineId ? { ...i, qty } : i)),
          },
        }));
      },

      setDiscount: (discount) => {
        set((s) => ({ cart: { ...s.cart, discount: Math.max(0, discount) } }));
      },

      clearCart: () => set({ cart: emptyCart() }),

      assignTable: (tableId) => {
        set((s) => ({ cart: { ...s.cart, tableId } }));
      },

      loadOrderIntoCart: (orderId) => {
        const order = get().orders.find((o) => o.id === orderId);
        if (!order || order.status === "completed") return;
        set({
          cart: {
            tableId: order.tableId,
            discount: order.discount ?? 0,
            items: order.items.map((i) => ({ ...i, id: uid("li") })),
          },
        });
      },

      sendToKitchen: () => {
        const { cart, session, tables, orders, nextOrderNumber } = get();
        if (!session || cart.items.length === 0) return null;
        const table = tables.find((t) => t.id === cart.tableId);
        if (!table) return null;

        const existing = table.orderId
          ? orders.find((o) => o.id === table.orderId)
          : undefined;

        const now = Date.now();
        if (existing && existing.status !== "completed") {
          const merged: Order = {
            ...existing,
            items: cart.items.map((i) => ({ ...i })),
            discount: cart.discount,
            updatedAt: now,
            status: existing.status === "ready" ? "preparing" : existing.status,
          };
          set({
            orders: orders.map((o) => (o.id === existing.id ? merged : o)),
          });
          return merged;
        }

        const order: Order = {
          id: uid("o"),
          number: nextOrderNumber,
          tableId: table.id,
          tableLabel: table.label,
          staffId: session.id,
          staffName: session.name,
          items: cart.items.map((i) => ({ ...i })),
          status: "new",
          paid: false,
          discount: cart.discount,
          createdAt: now,
          updatedAt: now,
          type: "dine-in",
        };
        set({
          orders: [order, ...orders],
          nextOrderNumber: nextOrderNumber + 1,
          tables: tables.map((t) =>
            t.id === table.id ? { ...t, status: "occupied", orderId: order.id } : t,
          ),
        });
        return order;
      },

      checkout: (method, tendered) => {
        const { cart, session, tables, orders, nextOrderNumber } = get();
        if (!session || cart.items.length === 0) return null;
        const { total } = cartTotals(cart.items, cart.discount);
        if (method === "cash" && tendered !== undefined && tendered < total) return null;

        const table = tables.find((t) => t.id === cart.tableId);
        const now = Date.now();
        const existing = table?.orderId
          ? orders.find((o) => o.id === table.orderId && o.status !== "completed")
          : undefined;

        if (existing) {
          const updated: Order = {
            ...existing,
            items: cart.items.map((i) => ({ ...i })),
            paid: true,
            paymentMethod: method,
            tendered,
            discount: cart.discount,
            updatedAt: now,
          };
          set({
            orders: orders.map((o) => (o.id === existing.id ? updated : o)),
            cart: emptyCart(),
          });
          return updated;
        }

        const order: Order = {
          id: uid("o"),
          number: nextOrderNumber,
          tableId: table?.id,
          tableLabel: table?.label,
          staffId: session.id,
          staffName: session.name,
          items: cart.items.map((i) => ({ ...i })),
          status: "new",
          paid: true,
          paymentMethod: method,
          tendered,
          discount: cart.discount,
          createdAt: now,
          updatedAt: now,
          type: table ? "dine-in" : "takeaway",
        };

        set({
          orders: [order, ...orders],
          nextOrderNumber: nextOrderNumber + 1,
          tables: table
            ? tables.map((t) =>
                t.id === table.id ? { ...t, status: "occupied", orderId: order.id } : t,
              )
            : tables,
          cart: emptyCart(),
        });
        return order;
      },

      advanceOrder: (orderId) => {
        const next: Record<OrderStatus, OrderStatus> = {
          new: "preparing",
          preparing: "ready",
          ready: "completed",
          completed: "completed",
        };
        set((s) => ({
          orders: s.orders.map((o) => {
            if (o.id !== orderId) return o;
            return { ...o, status: next[o.status], updatedAt: Date.now() };
          }),
        }));
      },

      completeOrder: (orderId) => {
        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === orderId ? { ...o, status: "completed", updatedAt: Date.now() } : o,
          ),
          tables: s.tables.map((t) =>
            t.orderId === orderId ? { ...t, status: "available", orderId: undefined } : t,
          ),
        }));
      },

      closeTable: (tableId) => {
        const { tables, orders, cart } = get();
        const table = tables.find((t) => t.id === tableId);
        if (!table?.orderId) {
          set({
            tables: tables.map((t) =>
              t.id === tableId ? { ...t, status: "available", orderId: undefined } : t,
            ),
          });
          return true;
        }
        const order = orders.find((o) => o.id === table.orderId);
        if (order && !order.paid) return false;
        set({
          orders: order
            ? orders.map((o) =>
                o.id === order.id ? { ...o, status: "completed", updatedAt: Date.now() } : o,
              )
            : orders,
          tables: tables.map((t) =>
            t.id === tableId ? { ...t, status: "available", orderId: undefined } : t,
          ),
          cart: cart.tableId === tableId ? emptyCart() : cart,
        });
        return true;
      },

      openTable: (tableId) => {
        const table = get().tables.find((t) => t.id === tableId);
        if (!table || table.status === "reserved") return;
        if (table.orderId) {
          get().loadOrderIntoCart(table.orderId);
          return;
        }
        set({ cart: { tableId, items: [], discount: 0 } });
      },

      toggleProduct: (productId) => {
        set((s) => ({
          products: s.products.map((p) =>
            p.id === productId ? { ...p, available: !p.available } : p,
          ),
        }));
      },

      hydrateCatalog: (data) => {
        set({
          staff: data.staff.length ? data.staff : get().staff,
          categories: data.categories.length ? data.categories : get().categories,
          products: data.products.length ? data.products : get().products,
          tables: data.tables.length ? data.tables : get().tables,
        });
      },

      resetDemo: () => {
        const { language, theme, session, staff } = get();
        set({ ...freshState(), language, theme, session, staff });
      },
    }),
    {
      name: "simplepos-v2",
      storage: createJSONStorage(getStorage),
      skipHydration: true,
      partialize: (s) => ({
        seedVersion: s.seedVersion,
        language: s.language,
        theme: s.theme,
        session: s.session,
        staff: s.staff,
        categories: s.categories,
        products: s.products,
        tables: s.tables,
        orders: s.orders,
        nextOrderNumber: s.nextOrderNumber,
        cart: s.cart,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<POSState>;
        if (p.seedVersion !== SEED_VERSION) {
          return {
            ...current,
            language: p.language ?? current.language,
            theme: p.theme ?? current.theme,
          };
        }
        return {
          ...current,
          ...p,
          cart: p.cart ? { items: p.cart.items ?? [], discount: p.cart.discount ?? 0 } : current.cart,
        };
      },
    },
  ),
);

export function useLang(): Lang {
  return usePOSStore((s) => s.language);
}
