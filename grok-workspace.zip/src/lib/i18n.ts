import type { Lang, OrderStatus, PaymentMethod, Role, TableStatus } from "./types";

const dict = {
  appName: { en: "simplePOS", am: "ሲምፕል ፒኦኤስ" },
  tagline: { en: "Addis service terminal", am: "የአዲስ አገልግሎት ተርሚናል" },
  enterPin: { en: "Enter staff PIN", am: "የሰራተኛ ፒን ያስገቡ" },
  incorrectPin: { en: "Incorrect PIN", am: "የተሳሳተ ፒን" },
  demoAccounts: { en: "Demo PINs", am: "የሙከራ ፒን" },
  clear: { en: "Clear", am: "አጽዳ" },
  navPos: { en: "POS", am: "ሽያጭ" },
  navTables: { en: "Tables", am: "ጠረጴዛ" },
  navKds: { en: "Kitchen", am: "ኩሽና" },
  navAdmin: { en: "Admin", am: "አስተዳደር" },
  logout: { en: "Sign out", am: "ውጣ" },
  language: { en: "Language", am: "ቋንቋ" },
  english: { en: "English", am: "እንግሊዘኛ" },
  amharic: { en: "Amharic", am: "አማርኛ" },
  theme: { en: "Theme", am: "ገጽታ" },
  dark: { en: "Dark", am: "ጨለማ" },
  light: { en: "Light", am: "ብርሃን" },
  searchMenu: { en: "Search menu", am: "ምናሌ ፈልግ" },
  all: { en: "All", am: "ሁሉም" },
  cart: { en: "Ticket", am: "ትዕዛዝ" },
  emptyCart: { en: "No items yet", am: "ምንም አልተጨመረም" },
  emptyCartHint: { en: "Tap a dish to add it to this ticket.", am: "ምግብ በመንካት ወደ ትዕዛዙ ይጨምሩ።" },
  qty: { en: "Qty", am: "ብዛት" },
  subtotal: { en: "Subtotal", am: "ንዑስ ድምር" },
  vat: { en: "VAT 15%", am: "ተ.እ.ታ 15%" },
  total: { en: "Total", am: "ጠቅላላ" },
  pay: { en: "Take payment", am: "ክፈል" },
  sendKitchen: { en: "Send to kitchen", am: "ወደ ኩሽና ላክ" },
  holdTable: { en: "Table", am: "ጠረጴዛ" },
  takeaway: { en: "Takeaway", am: "ቶንኮ" },
  dineIn: { en: "Dine in", am: "በቦታው" },
  noTable: { en: "No table", am: "ጠረጴዛ የለም" },
  checkout: { en: "Checkout", am: "ክፍያ" },
  paymentMethod: { en: "Payment method", am: "የክፍያ መንገድ" },
  cash: { en: "Cash", am: "ጥሬ ገንዘብ" },
  card: { en: "Card", am: "ካርድ" },
  telebirr: { en: "Telebirr", am: "ቴሌብር" },
  tendered: { en: "Amount received", am: "የተቀበለው" },
  change: { en: "Change", am: "ቅሪት" },
  confirmPay: { en: "Confirm payment", am: "ክፍያ አረጋግጥ" },
  cancel: { en: "Cancel", am: "ሰርዝ" },
  paid: { en: "Paid", am: "ተከፍሏል" },
  unpaid: { en: "Unpaid", am: "ያልተከፈለ" },
  newOrder: { en: "New ticket", am: "አዲስ ትዕዛዝ" },
  orderSent: { en: "Sent to kitchen", am: "ወደ ኩሽና ተልኳል" },
  paymentOk: { en: "Payment recorded", am: "ክፍያ ተመዝግቧል" },
  unavailable: { en: "Unavailable", am: "አይገኝም" },
  floor: { en: "Floor plan", am: "የአዳራሽ ንድፍ" },
  seats: { en: "seats", am: "ወንበር" },
  available: { en: "Open", am: "ክፍት" },
  occupied: { en: "Seated", am: "ተይዟል" },
  reserved: { en: "Reserved", am: "ተያይዟል" },
  openTable: { en: "Open table", am: "ጠረጴዛ ክፈት" },
  closeTable: { en: "Close table", am: "ጠረጴዛ ዝጋ" },
  viewOrder: { en: "View ticket", am: "ትዕዛዝ ይመልከቱ" },
  kitchenDisplay: { en: "Kitchen display", am: "የኩሽና ማሳያ" },
  noTickets: { en: "No tickets in this column", am: "በዚህ ዓምድ ትዕዛዝ የለም" },
  bump: { en: "Bump", am: "አስቀጥል" },
  startCook: { en: "Start", am: "ጀምር" },
  markReady: { en: "Ready", am: "ዝግጁ" },
  complete: { en: "Complete", am: "ጨርስ" },
  statusNew: { en: "New", am: "አዲስ" },
  statusPreparing: { en: "Preparing", am: "በዝግጅት" },
  statusReady: { en: "Ready", am: "ዝግጁ" },
  statusCompleted: { en: "Completed", am: "ተጠናቋል" },
  dashboard: { en: "Dashboard", am: "ዳሽቦርድ" },
  todaySales: { en: "Today’s sales", am: "የዛሬ ሽያጭ" },
  todayOrders: { en: "Orders today", am: "የዛሬ ትዕዛዞች" },
  avgTicket: { en: "Average ticket", am: "አማካይ ትዕዛዝ" },
  openTables: { en: "Open tables", am: "ክፍት ጠረጴዛዎች" },
  last7: { en: "Last 7 days", am: "ባለፉት 7 ቀናት" },
  menuAvailability: { en: "Menu availability", am: "የምናሌ ዝግጁነት" },
  staff: { en: "Staff", am: "ሰራተኞች" },
  recentOrders: { en: "Recent tickets", am: "የቅርብ ትዕዛዞች" },
  resetDemo: { en: "Reset demo data", am: "ሙከራውን ዳግም አስጀምር" },
  resetOk: { en: "Demo data restored", am: "ሙከራው ተመልሷል" },
  roleAdmin: { en: "Admin", am: "አስተዳዳሪ" },
  roleManager: { en: "Manager", am: "ሥራ አስኪያጅ" },
  roleCashier: { en: "Cashier", am: "ገንዘብ ተቀባይ" },
  roleWaiter: { en: "Waiter", am: "አስተናጋጅ" },
  order: { en: "Order", am: "ትዕዛዝ" },
  items: { en: "items", am: "ዓይነት" },
  ago: { en: "ago", am: "በፊት" },
  min: { en: "m", am: "ደ" },
  accessDenied: { en: "You do not have access to this screen.", am: "ይህን ማያ መጠቀም አይችሉም።" },
  backToPos: { en: "Back to POS", am: "ወደ ሽያጭ ተመለስ" },
  signedInAs: { en: "Signed in", am: "ገብተዋል" },
  add: { en: "Add", am: "ጨምር" },
  remove: { en: "Remove", am: "አስወግድ" },
  close: { en: "Close", am: "ዝጋ" },
  insufficient: { en: "Amount is less than the total", am: "መጠኑ ከጠቅላላው ያነሰ ነው" },
  ticketN: { en: "Ticket", am: "ትዕዛዝ" },
  live: { en: "Live", am: "ቀጥታ" },
  sales: { en: "Sales", am: "ሽያጭ" },
  on: { en: "On", am: "ክፍት" },
  off: { en: "Off", am: "ዝግ" },
  emptyKitchen: { en: "Kitchen is clear", am: "ኩሽናው ባዶ ነው" },
  emptyKitchenHint: { en: "New tickets will appear here as soon as they are sent.", am: "አዲስ ትዕዛዞች ሲላኩ እዚህ ይታያሉ።" },
  pickTable: { en: "Assign table", am: "ጠረጴዛ ምረጥ" },
  needItems: { en: "Add items first", am: "መጀመሪያ ምግብ ይጨምሩ" },
  sendNeedTable: { en: "Assign a table or take payment for takeaway.", am: "ጠረጴዛ ይምረጡ ወይም ለቶንኮ ይክፈሉ።" },
  tableClosed: { en: "Table closed", am: "ጠረጴዛ ተዘግቷል" },
  mustPay: { en: "Collect payment before closing.", am: "ከመዝጋት በፊት ክፍያ ይሰብስቡ።" },
} as const;

export type MsgKey = keyof typeof dict;

export function t(lang: Lang, key: MsgKey): string {
  return dict[key][lang];
}

export function roleLabel(lang: Lang, role: Role): string {
  const map: Record<Role, MsgKey> = {
    admin: "roleAdmin",
    manager: "roleManager",
    cashier: "roleCashier",
    waiter: "roleWaiter",
  };
  return t(lang, map[role]);
}

export function statusLabel(lang: Lang, status: OrderStatus): string {
  const map: Record<OrderStatus, MsgKey> = {
    new: "statusNew",
    preparing: "statusPreparing",
    ready: "statusReady",
    completed: "statusCompleted",
  };
  return t(lang, map[status]);
}

export function tableStatusLabel(lang: Lang, status: TableStatus): string {
  const map: Record<TableStatus, MsgKey> = {
    available: "available",
    occupied: "occupied",
    reserved: "reserved",
  };
  return t(lang, map[status]);
}

export function paymentLabel(lang: Lang, method: PaymentMethod): string {
  return t(lang, method);
}

export function localizedName(
  lang: Lang,
  item: { name: string; nameAm: string },
): string {
  return lang === "am" ? item.nameAm : item.name;
}
