import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  ChefHat,
  LayoutGrid,
  LogOut,
  Moon,
  ShoppingBag,
  Sun,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatClock } from "@/lib/format";
import { localizedName, roleLabel, t, type MsgKey } from "@/lib/i18n";
import { ADMIN_ROLES, type Role } from "@/lib/types";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV: { to: string; icon: typeof ShoppingBag; key: MsgKey; roles: Role[] }[] = [
  { to: "/pos", icon: ShoppingBag, key: "navPos", roles: ["admin", "manager", "cashier", "waiter"] },
  { to: "/tables", icon: LayoutGrid, key: "navTables", roles: ["admin", "manager", "cashier", "waiter"] },
  { to: "/kds", icon: ChefHat, key: "navKds", roles: ["admin", "manager", "cashier", "waiter"] },
  { to: "/admin", icon: BarChart3, key: "navAdmin", roles: ADMIN_ROLES },
];

function useTick(ms = 30000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

export function AppShell({ children }: { children: ReactNode }) {
  const session = usePOSStore((s) => s.session);
  const language = usePOSStore((s) => s.language);
  const theme = usePOSStore((s) => s.theme);
  const orders = usePOSStore((s) => s.orders);
  const setLanguage = usePOSStore((s) => s.setLanguage);
  const setTheme = usePOSStore((s) => s.setTheme);
  const logout = usePOSStore((s) => s.logout);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const now = useTick();

  if (!session) return <>{children}</>;

  const kitchenCount = orders.filter(
    (o) => o.status === "new" || o.status === "preparing",
  ).length;
  const nav = NAV.filter((item) => item.roles.includes(session.role));

  return (
    <div className="flex min-h-dvh bg-bg text-fg">
      <aside className="hidden w-[5.5rem] shrink-0 flex-col border-r border-border bg-surface md:flex">
        <div className="flex h-16 items-center justify-center">
          <div className="flex size-10 items-center justify-center rounded-lg bg-fg text-bg">
            <span className="text-sm font-semibold">sP</span>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 px-2 py-2">
          {nav.map((item) => {
            const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative flex min-h-11 flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-xs font-medium transition-colors duration-150",
                  active ? "bg-fg text-bg" : "text-muted hover:bg-elevated hover:text-fg",
                )}
              >
                <Icon className="size-5" />
                {t(language, item.key)}
                {item.to === "/kds" && kitchenCount > 0 && !active ? (
                  <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-warning" />
                ) : null}
              </Link>
            );
          })}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 md:h-16 md:px-5">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold tracking-tight">
              {t(language, "appName")}
            </p>
            <p className="truncate text-xs text-muted">
              {localizedName(language, session)} · {roleLabel(language, session.role)}
            </p>
          </div>
          <p className="hidden tabular-nums text-sm text-muted sm:block">
            {formatClock(now, language)}
          </p>
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            aria-label={t(language, "language")}
          >
            <span className="text-xs font-semibold">{language === "en" ? "አማ" : "EN"}</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label={t(language, "theme")}
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            onClick={logout}
            aria-label={t(language, "logout")}
          >
            <LogOut className="size-4" />
          </Button>
        </header>

        <main className="flex min-h-0 flex-1 flex-col overflow-hidden pb-20 md:pb-0">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] md:hidden">
        {nav.map((item) => {
          const active = pathname === item.to;
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "relative flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                active ? "text-fg" : "text-muted",
              )}
            >
              <Icon className="size-5" />
              {t(language, item.key)}
              {item.to === "/kds" && kitchenCount > 0 ? (
                <Badge tone="warning" className="absolute top-1 right-1/4 px-1.5 py-0 text-xs">
                  {kitchenCount}
                </Badge>
              ) : null}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
