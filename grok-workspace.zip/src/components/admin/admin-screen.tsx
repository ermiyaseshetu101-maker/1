import { Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { addStaff, getCatalog } from "@/lib/api/catalog";
import { ADMIN_ROLES, ALL_ROLES, cartTotals, hasFeature, limitOf, type Role } from "@/lib/types";
import { formatDate, formatETB, startOfDay } from "@/lib/format";
import { localizedName, paymentLabel, roleLabel, statusLabel, t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";

export function AdminScreen() {
  const session = usePOSStore((s) => s.session);
  const language = usePOSStore((s) => s.language);
  const orders = usePOSStore((s) => s.orders);
  const tables = usePOSStore((s) => s.tables);
  const products = usePOSStore((s) => s.products);
  const categories = usePOSStore((s) => s.categories);
  const staff = usePOSStore((s) => s.staff);
  const toggleProduct = usePOSStore((s) => s.toggleProduct);
  const resetDemo = usePOSStore((s) => s.resetDemo);
  const hydrateCatalog = usePOSStore((s) => s.hydrateCatalog);
  const { bootstrap, refresh } = useTenant();
  const ent = bootstrap?.entitlements;
  const canReports = hasFeature(ent, "reports");
  const staffCap = limitOf(ent, "max_staff");
  const atStaffLimit = staffCap !== -1 && staff.filter((s) => s.active !== false).length >= staffCap;

  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const [role, setRole] = useState<Role>("cashier");
  const [busy, setBusy] = useState(false);

  if (!session || !ADMIN_ROLES.includes(session.role)) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="text-sm text-muted">{t(language, "accessDenied")}</p>
        <Button asChild>
          <Link to="/pos">{t(language, "backToPos")}</Link>
        </Button>
      </div>
    );
  }

  const today = startOfDay();
  const paidToday = orders.filter((o) => o.paid && o.createdAt >= today);
  const salesToday = paidToday.reduce((s, o) => s + cartTotals(o.items, o.discount).total, 0);
  const avg = paidToday.length ? Math.round(salesToday / paidToday.length) : 0;
  const occupied = tables.filter((tb) => tb.status === "occupied").length;

  const chart = Array.from({ length: 7 }, (_, i) => {
    const day = startOfDay(Date.now() - (6 - i) * 86400000);
    const next = day + 86400000;
    const dayOrders = orders.filter((o) => o.paid && o.createdAt >= day && o.createdAt < next);
    return {
      label: formatDate(day, language),
      sales: dayOrders.reduce((s, o) => s + cartTotals(o.items, o.discount).total, 0),
    };
  });

  const recent = [...orders].sort((a, b) => b.createdAt - a.createdAt).slice(0, 8);

  async function onAddStaff(e: FormEvent) {
    e.preventDefault();
    if (atStaffLimit) {
      toast.error(t(language, "staffLimit"));
      return;
    }
    setBusy(true);
    try {
      await addStaff({ data: { name, nameAm: name, pin, role } });
      const catalog = await getCatalog();
      hydrateCatalog(catalog);
      setName("");
      setPin("");
      toast.success(t(language, "addStaff"));
      await refresh();
    } catch (err) {
      const msg = err instanceof Error ? err.message : t(language, "staffLimit");
      toast.error(msg === "STAFF_LIMIT" ? t(language, "staffLimit") : msg);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col gap-5 overflow-auto p-4 md:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-lg font-semibold tracking-tight">{t(language, "dashboard")}</h1>
        <Link to="/plans" className="text-xs text-muted hover:text-fg">
          {ent?.planName} · {t(language, "choosePlan")}
        </Link>
        <Button
          variant="outline"
          size="sm"
          className="ml-auto"
          onClick={() => {
            resetDemo();
            toast.success(t(language, "resetOk"));
          }}
        >
          {t(language, "resetDemo")}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label={t(language, "todaySales")} value={formatETB(salesToday, language)} />
        <Kpi label={t(language, "todayOrders")} value={String(paidToday.length)} />
        <Kpi label={t(language, "avgTicket")} value={formatETB(avg, language)} />
        <Kpi label={t(language, "openTables")} value={`${occupied}/${tables.length}`} />
      </div>

      {canReports ? (
        <section className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <h2 className="mb-4 text-sm font-semibold">{t(language, "last7")}</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} barCategoryGap="28%">
                <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="currentColor" className="text-subtle" />
                <YAxis tick={{ fontSize: 11 }} stroke="currentColor" className="text-subtle" width={48} />
                <Tooltip
                  cursor={{ fill: "color-mix(in oklab, var(--fg) 6%, transparent)" }}
                  contentStyle={{
                    background: "var(--surface)",
                    border: "1px solid var(--border)",
                    borderRadius: 12,
                    color: "var(--fg)",
                  }}
                  formatter={(value) => [formatETB(Number(value ?? 0), language), t(language, "sales")]}
                />
                <Bar dataKey="sales" fill="var(--fg)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
      ) : (
        <section className="rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <h2 className="text-sm font-semibold">{t(language, "advancedReports")}</h2>
          <p className="mt-2 text-sm text-muted">{t(language, "featureLocked")}</p>
          <Button asChild size="sm" className="mt-3">
            <Link to="/plans">{t(language, "upgrade")}</Link>
          </Button>
        </section>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <h2 className="mb-3 text-sm font-semibold">{t(language, "staff")}</h2>
          <ul className="divide-y divide-border">
            {staff.map((s) => (
              <li key={s.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium">{localizedName(language, s)}</p>
                  <p className="text-xs text-muted">{roleLabel(language, s.role)}</p>
                </div>
                <span className="font-mono text-sm tabular-nums text-muted">{s.pin}</span>
              </li>
            ))}
          </ul>
          <form className="mt-4 grid gap-2 sm:grid-cols-4" onSubmit={(e) => void onAddStaff(e)}>
            <input
              required
              minLength={2}
              placeholder={t(language, "ownerName")}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-10 rounded-xl bg-elevated px-3 text-sm outline-none sm:col-span-2"
            />
            <input
              required
              pattern="\d{4}"
              maxLength={4}
              placeholder={t(language, "pin")}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
              className="h-10 rounded-xl bg-elevated px-3 text-sm outline-none"
            />
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as Role)}
              className="h-10 rounded-xl bg-elevated px-3 text-sm outline-none"
            >
              {ALL_ROLES.map((r) => (
                <option key={r} value={r}>
                  {roleLabel(language, r)}
                </option>
              ))}
            </select>
            <Button type="submit" className="sm:col-span-4" disabled={busy || atStaffLimit}>
              {atStaffLimit ? t(language, "staffLimit") : t(language, "addStaff")}
            </Button>
          </form>
        </section>

        <section className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <h2 className="mb-3 text-sm font-semibold">{t(language, "recentOrders")}</h2>
          <ul className="divide-y divide-border">
            {recent.map((o) => (
              <li key={o.id} className="flex items-center gap-2 py-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium tabular-nums">
                    #{o.number} · {o.tableLabel ?? t(language, "takeaway")}
                  </p>
                  <p className="text-xs text-muted">
                    {o.paymentMethod ? paymentLabel(language, o.paymentMethod) : t(language, "unpaid")}
                  </p>
                </div>
                <Badge
                  tone={
                    o.status === "completed"
                      ? "success"
                      : o.status === "ready"
                        ? "success"
                        : o.status === "preparing"
                          ? "warning"
                          : "info"
                  }
                >
                  {statusLabel(language, o.status)}
                </Badge>
                <span className="text-sm tabular-nums">{formatETB(cartTotals(o.items, o.discount).total, language)}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <h2 className="mb-3 text-sm font-semibold">{t(language, "menuAvailability")}</h2>
        {categories.map((cat) => (
          <div key={cat.id} className="mb-4 last:mb-0">
            <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">
              {localizedName(language, cat)}
            </p>
            <ul className="grid gap-2 sm:grid-cols-2">
              {products
                .filter((p) => p.categoryId === cat.id)
                .map((p) => (
                  <li
                    key={p.id}
                    className="flex items-center justify-between rounded-xl bg-elevated px-3 py-2"
                  >
                    <span className="text-sm">{localizedName(language, p)}</span>
                    <button
                      type="button"
                      onClick={() => toggleProduct(p.id)}
                      className="text-xs font-medium text-muted"
                    >
                      {p.available ? t(language, "on") : t(language, "off")}
                    </button>
                  </li>
                ))}
            </ul>
          </div>
        ))}
      </section>
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-2 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
    </div>
  );
}
