import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function OwnerShell({
  children,
  title,
  subtitle,
}: {
  children: ReactNode;
  title: string;
  subtitle?: string;
}) {
  const language = usePOSStore((s) => s.language);
  const { bootstrap } = useTenant();
  const isAdmin = bootstrap?.profile.platformRole === "super_admin";
  const hasRestaurant = Boolean(bootstrap?.restaurant);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-border bg-surface px-4 py-3">
        <Link to="/" className="flex size-9 items-center justify-center rounded-lg bg-fg text-bg">
          <span className="text-xs font-semibold">sP</span>
        </Link>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{title}</p>
          {subtitle ? <p className="truncate text-xs text-muted">{subtitle}</p> : null}
        </div>
        <nav className="hidden items-center gap-3 text-sm sm:flex">
          {hasRestaurant ? (
            <Link to="/pin" className="text-muted hover:text-fg">
              {t(language, "pinFor")}
            </Link>
          ) : null}
          <Link to="/plans" className="text-muted hover:text-fg">
            {t(language, "plansTitle")}
          </Link>
          {isAdmin ? (
            <Link to="/platform" className="text-muted hover:text-fg">
              {t(language, "platform")}
            </Link>
          ) : null}
        </nav>
        <UserButton />
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-8">{children}</main>
    </div>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-medium tracking-wide text-muted uppercase">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "h-11 w-full rounded-xl bg-elevated px-3 text-sm text-fg outline-none focus:ring-2 focus:ring-accent/40";

export function PageSkeleton() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg text-fg">
      <div className="flex flex-col items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-xl bg-fg text-bg">
          <span className="text-lg font-semibold tracking-tight">sP</span>
        </div>
        <div className="h-1.5 w-24 overflow-hidden rounded-full bg-elevated">
          <div className="h-full w-1/2 animate-pulse bg-fg/40" />
        </div>
      </div>
    </div>
  );
}

export function StatusScreen({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <OwnerShell title="simplePOS">
      <div className="mx-auto max-w-md rounded-3xl bg-surface p-6 text-center shadow-[var(--shadow-border)]">
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-2 text-sm text-muted">{body}</p>
        {action ? <div className="mt-6">{action}</div> : null}
      </div>
    </OwnerShell>
  );
}

export function UpgradeCard({ message }: { message: string }) {
  const language = usePOSStore((s) => s.language);
  return (
    <div className="mx-auto flex min-h-[50vh] max-w-md flex-col items-center justify-center gap-3 px-6 text-center">
      <p className="text-sm text-muted">{message}</p>
      <Link
        to="/plans"
        className={cn(
          "inline-flex h-11 items-center rounded-xl bg-fg px-5 text-sm font-medium text-bg",
        )}
      >
        {t(language, "upgrade")}
      </Link>
    </div>
  );
}
