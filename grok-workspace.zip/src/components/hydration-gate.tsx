import { useEffect, useState, type ReactNode } from "react";
import { usePOSStore } from "@/lib/store";

function Splash() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg text-fg">
      <div className="flex flex-col items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-xl bg-fg text-bg">
          <span className="text-lg font-semibold tracking-tight">sP</span>
        </div>
        <p className="text-sm text-muted">simplePOS</p>
      </div>
    </div>
  );
}

export function HydrationGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const theme = usePOSStore((s) => s.theme);
  const language = usePOSStore((s) => s.language);

  useEffect(() => {
    const persist = usePOSStore.persist;
    if (!persist) {
      setReady(true);
      return;
    }
    const unsub = persist.onFinishHydration(() => setReady(true));
    void persist.rehydrate();
    if (persist.hasHydrated()) setReady(true);
    const fallback = window.setTimeout(() => setReady(true), 80);
    return () => {
      unsub?.();
      window.clearTimeout(fallback);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.classList.toggle("light", theme === "light");
    root.lang = language === "am" ? "am" : "en";
  }, [ready, theme, language]);

  if (!ready) return <Splash />;
  return <>{children}</>;
}
