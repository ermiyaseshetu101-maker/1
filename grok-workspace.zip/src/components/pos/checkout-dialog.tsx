import { Banknote, CreditCard, Smartphone, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cartTotals, type PaymentMethod } from "@/lib/types";
import { formatETB } from "@/lib/format";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const METHODS: { id: PaymentMethod; icon: typeof Banknote }[] = [
  { id: "cash", icon: Banknote },
  { id: "card", icon: CreditCard },
  { id: "telebirr", icon: Smartphone },
];

export function CheckoutDialog({ onClose }: { onClose: () => void }) {
  const language = usePOSStore((s) => s.language);
  const cart = usePOSStore((s) => s.cart);
  const checkout = usePOSStore((s) => s.checkout);
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [digits, setDigits] = useState("");
  const totals = cartTotals(cart.items);
  const tendered = digits ? Number(digits) : totals.total;
  const change = Math.max(0, tendered - totals.total);
  const short = method === "cash" && tendered < totals.total;

  const quick = useMemo(
    () => [totals.total, Math.ceil(totals.total / 100) * 100, 500, 1000].filter(
      (v, i, arr) => v >= totals.total && arr.indexOf(v) === i,
    ),
    [totals.total],
  );

  function confirm() {
    if (short) {
      toast.error(t(language, "insufficient"));
      return;
    }
    const order = checkout(method, method === "cash" ? tendered : undefined);
    if (!order) {
      toast.error(t(language, "insufficient"));
      return;
    }
    toast.success(`${t(language, "paymentOk")} #${order.number}`);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-0 sm:items-center sm:p-6">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-auto rounded-t-3xl bg-surface shadow-[var(--shadow-border)] sm:rounded-3xl">
        <div className="flex items-center justify-between px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold">{t(language, "checkout")}</h2>
            <p className="text-sm tabular-nums text-muted">{formatETB(totals.total, language)}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label={t(language, "close")}>
            <X className="size-4" />
          </Button>
        </div>

        <div className="px-5 pb-2">
          <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">
            {t(language, "paymentMethod")}
          </p>
          <div className="grid grid-cols-3 gap-2">
            {METHODS.map((m) => {
              const Icon = m.icon;
              const active = method === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMethod(m.id)}
                  className={cn(
                    "flex min-h-20 flex-col items-center justify-center gap-1 rounded-2xl text-sm font-medium transition-colors duration-150",
                    active ? "bg-fg text-bg" : "bg-elevated text-fg",
                  )}
                >
                  <Icon className="size-5" />
                  {t(language, m.id)}
                </button>
              );
            })}
          </div>
        </div>

        {method === "cash" ? (
          <div className="px-5 py-4">
            <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">
              {t(language, "tendered")}
            </p>
            <p className="mb-3 text-3xl font-semibold tabular-nums tracking-tight">
              {formatETB(tendered, language)}
            </p>
            <div className="mb-3 flex flex-wrap gap-2">
              {quick.map((v) => (
                <Button key={v} variant="muted" size="sm" onClick={() => setDigits(String(v))}>
                  {formatETB(v, language)}
                </Button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⌫"].map((k) => (
                <Button
                  key={k}
                  variant="outline"
                  size="lg"
                  onClick={() => {
                    if (k === "C") setDigits("");
                    else if (k === "⌫") setDigits((d) => d.slice(0, -1));
                    else setDigits((d) => (d + k).replace(/^0+/, "") || "0");
                  }}
                >
                  {k}
                </Button>
              ))}
            </div>
            <div className="mt-4 flex justify-between text-sm">
              <span className="text-muted">{t(language, "change")}</span>
              <span className={cn("font-semibold tabular-nums", short && "text-danger")}>
                {short ? t(language, "insufficient") : formatETB(change, language)}
              </span>
            </div>
          </div>
        ) : (
          <p className="px-5 py-6 text-sm text-muted">
            {method === "telebirr"
              ? language === "am"
                ? "ቴሌብር ክፍያውን በተርሚናሉ ላይ ያረጋግጡ።"
                : "Confirm the Telebirr push on the terminal, then record payment."
              : language === "am"
                ? "ካርዱን በመሣሪያው ላይ ያስነሱ እና ያረጋግጡ።"
                : "Tap the card on the reader, then record payment."}
          </p>
        )}

        <div className="grid grid-cols-2 gap-2 p-5">
          <Button variant="outline" size="lg" onClick={onClose}>
            {t(language, "cancel")}
          </Button>
          <Button size="lg" onClick={confirm} disabled={short}>
            {t(language, "confirmPay")}
          </Button>
        </div>
      </div>
    </div>
  );
}
