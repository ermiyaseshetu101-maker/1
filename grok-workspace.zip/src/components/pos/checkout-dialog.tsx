import { Banknote, CreditCard, Smartphone, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cartTotals, hasFeature, type PaymentMethod } from "@/lib/types";
import { formatETB } from "@/lib/format";
import { t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { useTenant } from "@/lib/tenant";
import { cn } from "@/lib/utils";

const METHODS: { id: PaymentMethod; icon: typeof Banknote }[] = [
  { id: "cash", icon: Banknote },
  { id: "card", icon: CreditCard },
  { id: "telebirr", icon: Smartphone },
];

export function CheckoutDialog({ onClose }: { onClose: () => void }) {
  const language = usePOSStore((s) => s.language);
  const cart = usePOSStore((s) => s.cart);
  const checkout = usePOSStore((s) => s.checkout);
  const { bootstrap } = useTenant();
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [digits, setDigits] = useState("");
  const totals = cartTotals(cart.items, cart.discount);
  const tendered = digits ? Number(digits) : totals.total;
  const change = Math.max(0, tendered - totals.total);
  const short = method === "cash" && tendered < totals.total;
  const canPrint = hasFeature(bootstrap?.entitlements, "printer");

  const quick = useMemo(
    () => [totals.total, Math.ceil(totals.total / 100) * 100, 500, 1000].filter(
      (v, i, arr) => v >= totals.total && arr.indexOf(v) === i,
    ),
    [totals.total],
  );

  function confirm() {
    if (short) {
      toast.error(t(language, "insufficient"));
      return;
    }
    const order = checkout(method, method === "cash" ? tendered : undefined);
    if (!order) {
      toast.error(t(language, "insufficient"));
      return;
    }
    toast.success(`${t(language, "paymentOk")} #${order.number}`);
    onClose();
  }

  function printReceipt() {
    if (!canPrint) {
      toast.error(t(language, "featureLocked"));
      return;
    }
    const win = window.open("", "receipt", "width=360,height=640");
    if (!win) return;
    const lines = cart.items
      .map((i) => `${i.qty} × ${i.name} — ${formatETB(i.price * i.qty, language)}`)
      .join("<br/>");
    win.document.write(`
      <html><body style="font-family:sans-serif;padding:16px">
        <h2>${bootstrap?.restaurant?.name ?? "simplePOS"}</h2>
        <p>${lines}</p>
        <p><strong>${formatETB(totals.total, language)}</strong></p>
        <p>${bootstrap?.restaurant?.receiptFooter ?? ""}</p>
      </body></html>
    `);
    win.document.close();
    win.print();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-0 sm:items-center sm:p-6">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-auto rounded-t-3xl bg-surface shadow-[var(--shadow-border)] sm:rounded-3xl">
        <div className="flex items-center justify-between px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold">{t(language, "checkout")}</h2>
            <p className="text-sm tabular-nums text-muted">{formatETB(totals.total, language)}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label={t(language, "close")}>
            <X className="size-4" />
          </Button>
        </div>
        <div className="grid grid-cols-3 gap-2 px-5">
          {METHODS.map((m) => {
            const Icon = m.icon;
            const active = method === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={cn(
                  "flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl text-xs font-medium",
                  active ? "bg-fg text-bg" : "bg-elevated text-muted",
                )}
              >
                <Icon className="size-4" />
                {t(language, m.id)}
              </button>
            );
          })}
        </div>
        {method === "cash" ? (
          <div className="space-y-3 px-5 py-4">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">{t(language, "tendered")}</p>
            <input
              value={digits}
              onChange={(e) => setDigits(e.target.value.replace(/\D/g, ""))}
              inputMode="numeric"
              className="h-12 w-full rounded-xl bg-elevated px-3 text-lg tabular-nums outline-none"
              placeholder={String(totals.total)}
            />
            <div className="flex flex-wrap gap-2">
              {quick.map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setDigits(String(v))}
                  className="h-9 rounded-full bg-elevated px-3 text-xs tabular-nums"
                >
                  {formatETB(v, language)}
                </button>
              ))}
            </div>
            <p className="text-sm text-muted">
              {t(language, "change")}: <span className="tabular-nums text-fg">{formatETB(change, language)}</span>
            </p>
          </div>
        ) : (
          <div className="px-5 py-4 text-sm text-muted">{t(language, "confirmPay")}</div>
        )}
        <div className="flex flex-col gap-2 px-5 pb-5">
          <Button size="lg" onClick={confirm} disabled={short}>
            {t(language, "confirmPay")}
          </Button>
          <Button variant="outline" onClick={printReceipt}>
            {t(language, "printReceipt")}
          </Button>
          <Button variant="ghost" onClick={onClose}>
            {t(language, "cancel")}
          </Button>
        </div>
      </div>
    </div>
  );
}
