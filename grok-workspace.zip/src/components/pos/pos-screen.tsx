import { Minus, Plus, Search, Trash2, UtensilsCrossed, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckoutDialog } from "@/components/pos/checkout-dialog";
import { cartTotals } from "@/lib/types";
import { formatETB } from "@/lib/format";
import { localizedName, t } from "@/lib/i18n";
import { CATEGORIES } from "@/lib/seed";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function PosScreen() {
  const language = usePOSStore((s) => s.language);
  const products = usePOSStore((s) => s.products);
  const tables = usePOSStore((s) => s.tables);
  const cart = usePOSStore((s) => s.cart);
  const addToCart = usePOSStore((s) => s.addToCart);
  const setQty = usePOSStore((s) => s.setQty);
  const assignTable = usePOSStore((s) => s.assignTable);
  const sendToKitchen = usePOSStore((s) => s.sendToKitchen);
  const clearCart = usePOSStore((s) => s.clearCart);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [payOpen, setPayOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (cat !== "all" && p.categoryId !== cat) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.nameAm.includes(q) ||
        String(p.price).includes(q)
      );
    });
  }, [products, cat, query]);

  const totals = cartTotals(cart.items);
  const table = tables.find((tb) => tb.id === cart.tableId);
  const nameOf = (item: { name: string; nameAm: string }) => localizedName(language, item);

  function onSend() {
    if (cart.items.length === 0) {
      toast.error(t(language, "needItems"));
      return;
    }
    const order = sendToKitchen();
    if (!order) {
      toast.error(t(language, "sendNeedTable"));
      return;
    }
    toast.success(`${t(language, "orderSent")} #${order.number}`);
  }

  return (
    <div className="flex min-h-0 flex-1">
      <section className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-col gap-3 border-b border-border px-3 py-3 md:px-5">
          <div className="flex items-center gap-2">
            <div className="relative min-w-0 flex-1">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t(language, "searchMenu")}
                className="h-11 w-full rounded-xl bg-surface pr-3 pl-10 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus:ring-2 focus:ring-accent/40"
              />
            </div>
            <select
              value={cart.tableId ?? ""}
              onChange={(e) => assignTable(e.target.value || undefined)}
              className="h-11 max-w-[9.5rem] rounded-xl bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none"
              aria-label={t(language, "pickTable")}
            >
              <option value="">{t(language, "takeaway")}</option>
              {tables.map((tb) => (
                <option key={tb.id} value={tb.id} disabled={tb.status === "reserved"}>
                  {tb.label}
                  {tb.status === "occupied" ? " ●" : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-0.5">
            <CategoryChip active={cat === "all"} onClick={() => setCat("all")}>
              {t(language, "all")}
            </CategoryChip>
            {CATEGORIES.map((c) => (
              <CategoryChip key={c.id} active={cat === c.id} onClick={() => setCat(c.id)}>
                {nameOf(c)}
              </CategoryChip>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 overflow-auto p-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 md:p-4">
          {filtered.map((p) => {
            const inCart = cart.items.find((i) => i.productId === p.id);
            return (
              <button
                key={p.id}
                type="button"
                disabled={!p.available}
                onClick={() => addToCart(p)}
                className={cn(
                  "flex min-h-[7.5rem] flex-col rounded-2xl bg-surface p-3 text-left shadow-[var(--shadow-border)] transition-[transform,background-color] duration-150 active:scale-[0.98]",
                  !p.available && "opacity-40",
                  inCart && "ring-1 ring-fg/20",
                )}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm leading-snug font-medium">{nameOf(p)}</p>
                  {inCart ? (
                    <Badge tone="solid" className="tabular-nums">
                      {inCart.qty}
                    </Badge>
                  ) : null}
                </div>
                <p className="mt-auto pt-3 font-medium tabular-nums text-muted">
                  {p.available ? formatETB(p.price, language) : t(language, "unavailable")}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      <aside className="hidden w-[22rem] shrink-0 flex-col border-l border-border bg-surface md:flex">
        <CartBody
          language={language}
          tableLabel={table?.label}
          totals={totals}
          items={cart.items}
          onQty={setQty}
          onClear={clearCart}
          onSend={onSend}
          onPay={() => setPayOpen(true)}
        />
      </aside>

      {totals.count > 0 ? (
        <div className="fixed inset-x-0 bottom-14 z-20 p-3 md:hidden">
          <Button
            size="xl"
            className="w-full justify-between rounded-2xl"
            onClick={() => setCartOpen(true)}
          >
            <span>
              {t(language, "cart")} · {totals.count}
            </span>
            <span className="tabular-nums">{formatETB(totals.total, language)}</span>
          </Button>
        </div>
      ) : null}

      {cartOpen ? (
        <div className="fixed inset-0 z-40 flex flex-col bg-bg/70 md:hidden" onClick={() => setCartOpen(false)}>
          <div
            className="mt-auto flex max-h-[85dvh] flex-col rounded-t-3xl bg-surface"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3">
              <p className="font-semibold">{t(language, "cart")}</p>
              <Button variant="ghost" size="icon" onClick={() => setCartOpen(false)}>
                <X className="size-4" />
              </Button>
            </div>
            <CartBody
              language={language}
              tableLabel={table?.label}
              totals={totals}
              items={cart.items}
              onQty={setQty}
              onClear={clearCart}
              onSend={onSend}
              onPay={() => {
                setCartOpen(false);
                setPayOpen(true);
              }}
            />
          </div>
        </div>
      ) : null}

      {payOpen ? <CheckoutDialog onClose={() => setPayOpen(false)} /> : null}
    </div>
  );
}

function CategoryChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full px-4 text-sm font-medium transition-colors duration-150",
        active ? "bg-fg text-bg" : "bg-surface text-muted shadow-[var(--shadow-border)]",
      )}
    >
      {children}
    </button>
  );
}

function CartBody({
  language,
  tableLabel,
  totals,
  items,
  onQty,
  onClear,
  onSend,
  onPay,
}: {
  language: "en" | "am";
  tableLabel?: string;
  totals: ReturnType<typeof cartTotals>;
  items: { id: string; name: string; nameAm: string; price: number; qty: number }[];
  onQty: (id: string, qty: number) => void;
  onClear: () => void;
  onSend: () => void;
  onPay: () => void;
}) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <p className="font-semibold">{t(language, "cart")}</p>
          <p className="text-xs text-muted">
            {tableLabel ?? t(language, "takeaway")}
          </p>
        </div>
        {items.length > 0 ? (
          <Button variant="ghost" size="icon" onClick={onClear} aria-label={t(language, "clear")}>
            <Trash2 className="size-4" />
          </Button>
        ) : null}
      </div>
      <div className="min-h-0 flex-1 overflow-auto px-3 py-3">
        {items.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 px-6 text-center">
            <UtensilsCrossed className="size-8 text-subtle" />
            <p className="text-sm font-medium">{t(language, "emptyCart")}</p>
            <p className="text-xs text-muted">{t(language, "emptyCartHint")}</p>
          </div>
        ) : (
          <ul className="space-y-2">
            {items.map((item) => (
              <li
                key={item.id}
                className="flex items-center gap-2 rounded-xl bg-elevated px-3 py-2"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{localizedName(language, item)}</p>
                  <p className="text-xs tabular-nums text-muted">
                    {formatETB(item.price, language)}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9"
                    onClick={() => onQty(item.id, item.qty - 1)}
                  >
                    <Minus className="size-4" />
                  </Button>
                  <span className="w-6 text-center text-sm tabular-nums">{item.qty}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9"
                    onClick={() => onQty(item.id, item.qty + 1)}
                  >
                    <Plus className="size-4" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="space-y-2 border-t border-border p-4">
        <Row label={t(language, "subtotal")} value={formatETB(totals.subtotal, language)} />
        <Row label={t(language, "vat")} value={formatETB(totals.vat, language)} muted />
        <Row label={t(language, "total")} value={formatETB(totals.total, language)} strong />
        <div className="grid grid-cols-2 gap-2 pt-2">
          <Button variant="outline" size="lg" onClick={onSend} disabled={items.length === 0}>
            {t(language, "sendKitchen")}
          </Button>
          <Button size="lg" onClick={onPay} disabled={items.length === 0}>
            {t(language, "pay")}
          </Button>
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  muted,
  strong,
}: {
  label: string;
  value: string;
  muted?: boolean;
  strong?: boolean;
}) {
  return (
    <div className={cn("flex items-center justify-between text-sm", muted && "text-muted", strong && "font-semibold")}>
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}
