import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cartTotals, type FloorTable, type TableStatus } from "@/lib/types";
import { formatETB } from "@/lib/format";
import { t, tableStatusLabel } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const TONE: Record<TableStatus, "success" | "warning" | "info" | "default"> = {
  available: "success",
  occupied: "warning",
  reserved: "info",
};

export function FloorPlan() {
  const language = usePOSStore((s) => s.language);
  const tables = usePOSStore((s) => s.tables);
  const orders = usePOSStore((s) => s.orders);
  const openTable = usePOSStore((s) => s.openTable);
  const closeTable = usePOSStore((s) => s.closeTable);
  const assignTable = usePOSStore((s) => s.assignTable);
  const navigate = useNavigate();

  function go(table: FloorTable) {
    if (table.status === "reserved") return;
    openTable(table.id);
    assignTable(table.id);
    void navigate({ to: "/pos" });
  }

  function onClose(table: FloorTable) {
    const ok = closeTable(table.id);
    if (!ok) toast.error(t(language, "mustPay"));
    else toast.success(t(language, "tableClosed"));
  }

  const counts = {
    available: tables.filter((tb) => tb.status === "available").length,
    occupied: tables.filter((tb) => tb.status === "occupied").length,
    reserved: tables.filter((tb) => tb.status === "reserved").length,
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
        <h1 className="mr-auto text-lg font-semibold tracking-tight">{t(language, "floor")}</h1>
        {(["available", "occupied", "reserved"] as const).map((s) => (
          <Badge key={s} tone={TONE[s]}>
            {tableStatusLabel(language, s)} {counts[s]}
          </Badge>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 overflow-auto p-4 sm:grid-cols-3 lg:grid-cols-4">
        {tables.map((table) => {
          const order = orders.find((o) => o.id === table.orderId);
          const total = order ? cartTotals(order.items).total : 0;
          return (
            <article
              key={table.id}
              className={cn(
                "flex min-h-36 flex-col rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
                table.status === "occupied" && "ring-1 ring-warning/40",
                table.status === "reserved" && "opacity-70",
              )}
            >
              <div className="flex items-start justify-between">
                <p className="text-2xl font-semibold tracking-tight">{table.label}</p>
                <Badge tone={TONE[table.status]}>{tableStatusLabel(language, table.status)}</Badge>
              </div>
              <p className="mt-1 text-xs text-muted">
                {table.seats} {t(language, "seats")}
              </p>
              {order ? (
                <p className="mt-2 text-sm tabular-nums text-fg">
                  #{order.number} · {formatETB(total, language)}
                </p>
              ) : (
                <p className="mt-2 text-sm text-subtle">—</p>
              )}
              <div className="mt-auto flex gap-2 pt-3">
                <Button
                  size="sm"
                  className="flex-1"
                  disabled={table.status === "reserved"}
                  onClick={() => go(table)}
                >
                  {order ? t(language, "viewOrder") : t(language, "openTable")}
                </Button>
                {table.status === "occupied" ? (
                  <Button size="sm" variant="outline" onClick={() => onClose(table)}>
                    {t(language, "closeTable")}
                  </Button>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
