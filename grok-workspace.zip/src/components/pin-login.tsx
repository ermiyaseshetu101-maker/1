import { useNavigate } from "@tanstack/react-router";
import { Delete } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { STAFF } from "@/lib/seed";
import { roleLabel, t } from "@/lib/i18n";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⌫"] as const;

export function PinLogin() {
  const language = usePOSStore((s) => s.language);
  const theme = usePOSStore((s) => s.theme);
  const setLanguage = usePOSStore((s) => s.setLanguage);
  const setTheme = usePOSStore((s) => s.setTheme);
  const login = usePOSStore((s) => s.login);
  const navigate = useNavigate();
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);

  function submit(next: string) {
    const staff = login(next);
    if (!staff) {
      setError(true);
      window.setTimeout(() => {
        setError(false);
        setPin("");
      }, 420);
      return;
    }
    const dest =
      staff.role === "waiter" ? "/tables" : staff.role === "admin" || staff.role === "manager" ? "/admin" : "/pos";
    void navigate({ to: dest });
  }

  function press(key: string) {
    if (error) return;
    if (key === "C") {
      setPin("");
      return;
    }
    if (key === "⌫") {
      setPin((p) => p.slice(0, -1));
      return;
    }
    const next = (pin + key).slice(0, 4);
    setPin(next);
    if (next.length === 4) submit(next);
  }

  return (
    <div className="relative flex min-h-dvh flex-col bg-bg text-fg">
      <div className="flex items-center justify-end gap-2 px-4 py-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLanguage(language === "en" ? "am" : "en")}
        >
          {language === "en" ? "አማርኛ" : "English"}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
          {t(language, theme === "dark" ? "light" : "dark")}
        </Button>
      </div>

      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 pb-8">
        <div className="enter-up mb-8 flex flex-col items-center text-center">
          <div className="mb-5 flex size-14 items-center justify-center rounded-2xl bg-fg text-bg">
            <span className="text-xl font-semibold tracking-tight">sP</span>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight">{t(language, "appName")}</h1>
          <p className="mt-1 text-sm text-muted">{t(language, "tagline")}</p>
        </div>

        <p className="mb-4 text-center text-sm text-muted">{t(language, "enterPin")}</p>
        <div className={cn("mb-6 flex justify-center gap-3", error && "pin-shake")}>
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className={cn(
                "size-3.5 rounded-full transition-colors duration-150",
                pin.length > i ? "bg-fg" : "bg-elevated shadow-[var(--shadow-border)]",
                error && "bg-danger",
              )}
            />
          ))}
        </div>
        {error ? (
          <p className="mb-4 text-center text-sm text-danger">{t(language, "incorrectPin")}</p>
        ) : (
          <div className="mb-4 h-5" />
        )}

        <div className="grid grid-cols-3 gap-2">
          {KEYS.map((key) => (
            <Button
              key={key}
              variant={key === "C" ? "muted" : "outline"}
              size="keypad"
              className="min-h-16"
              onClick={() => press(key)}
              aria-label={key === "⌫" ? "Backspace" : key === "C" ? t(language, "clear") : key}
            >
              {key === "⌫" ? <Delete className="size-6" /> : key === "C" ? t(language, "clear") : key}
            </Button>
          ))}
        </div>

        <div className="mt-8 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="mb-3 text-xs font-medium tracking-wide text-muted uppercase">
            {t(language, "demoAccounts")}
          </p>
          <ul className="grid grid-cols-2 gap-2">
            {STAFF.map((s) => (
              <li
                key={s.id}
                className="flex items-center justify-between rounded-xl bg-elevated px-3 py-2.5"
              >
                <span className="text-xs text-muted">{roleLabel(language, s.role)}</span>
                <span className="font-mono text-sm tabular-nums">{s.pin}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
