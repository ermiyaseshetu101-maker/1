import { ChefHat } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { elapsedMinutes } from "@/lib/format";
import { localizedName, statusLabel, t } from "@/lib/i18n";
import type { Order, OrderStatus } from "@/lib/types";
import { usePOSStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const COLS: { status: OrderStatus; tone: "info" | "warning" | "success" }[] = [
  { status: "new", tone: "info" },
  { status: "preparing", tone: "warning" },
  { status: "ready", tone: "success" },
];

function useNow() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 15000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function KdsScreen() {
  const language = usePOSStore((s) => s.language);
  const orders = usePOSStore((s) => s.orders);
  const advanceOrder = usePOSStore((s) => s.advanceOrder);
  const now = useNow();
  const live = orders.filter((o) => o.status !== "completed");

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <h1 className="text-lg font-semibold tracking-tight">{t(language, "kitchenDisplay")}</h1>
        <Badge tone="accent">{t(language, "live")}</Badge>
        <span className="ml-auto text-sm text-muted tabular-nums">{live.length}</span>
      </div>
      {live.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center">
          <ChefHat className="size-10 text-subtle" />
          <p className="font-medium">{t(language, "emptyKitchen")}</p>
          <p className="max-w-sm text-sm text-muted">{t(language, "emptyKitchenHint")}</p>
        </div>
      ) : (
        <div className="grid min-h-0 flex-1 gap-3 overflow-auto p-3 md:grid-cols-3">
          {COLS.map((col) => {
            const tickets = live.filter((o) => o.status === col.status);
            return (
              <section key={col.status} className="flex min-h-64 flex-col rounded-3xl bg-surface p-3">
                <div className="mb-2 flex items-center justify-between px-1">
                  <h2 className="text-sm font-semibold">{statusLabel(language, col.status)}</h2>
                  <Badge tone={col.tone}>{tickets.length}</Badge>
                </div>
                <div className="flex flex-col gap-2">
                  {tickets.length === 0 ? (
                    <p className="px-2 py-8 text-center text-xs text-subtle">{t(language, "noTickets")}</p>
                  ) : (
                    tickets.map((order) => (
                      <Ticket
                        key={order.id}
                        order={order}
                        now={now}
                        onBump={() => advanceOrder(order.id)}
                      />
                    ))
                  )}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Ticket({
  order,
  now,
  onBump,
}: {
  order: Order;
  now: number;
  onBump: () => void;
}) {
  const language = usePOSStore((s) => s.language);
  const mins = elapsedMinutes(order.createdAt, now);
  const action =
    order.status === "new"
      ? t(language, "startCook")
      : order.status === "preparing"
        ? t(language, "markReady")
        : t(language, "complete");

  return (
    <article
      className={cn(
        "rounded-2xl bg-elevated p-3 shadow-[var(--shadow-border)]",
        mins >= 15 && order.status !== "ready" && "ring-1 ring-danger/50",
      )}
    >
      <div className="mb-2 flex items-baseline justify-between gap-2">
        <p className="text-lg font-semibold tabular-nums">#{order.number}</p>
        <p className={cn("text-xs tabular-nums", mins >= 15 ? "text-danger" : "text-muted")}>
          {mins}
          {t(language, "min")}
        </p>
      </div>
      <p className="mb-2 text-xs text-muted">
        {order.tableLabel ?? t(language, "takeaway")} · {order.staffName}
      </p>
      <ul className="mb-3 space-y-1">
        {order.items.map((item) => (
          <li key={item.id} className="flex justify-between gap-2 text-sm">
            <span className="min-w-0 truncate">
              <span className="mr-2 inline-block w-5 font-semibold tabular-nums">{item.qty}</span>
              {localizedName(language, item)}
            </span>
          </li>
        ))}
      </ul>
      <Button
        size="sm"
        className="w-full"
        variant={order.status === "ready" ? "success" : "primary"}
        onClick={onBump}
      >
        {action}
      </Button>
    </article>
  );
}
