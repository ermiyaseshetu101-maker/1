//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Sd2UJs12.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/_app"],
		preloads: ["/assets/index-BLnhF_1v.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BLnhF_1v.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-9x6JJxiJ.js", "/assets/i18n-CCtUgRMD.js"]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/admin",
			"/_app/kds",
			"/_app/pos",
			"/_app/tables"
		],
		preloads: [
			"/assets/_app-DCZckyt3.js",
			"/assets/chef-hat-Cn4rNGQJ.js",
			"/assets/i18n-CCtUgRMD.js",
			"/assets/format-Cwn50fKZ.js"
		]
	},
	"/_app/admin": {
		filePath: "/workspace/src/routes/_app/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-BwxkGeq2.js"]
	},
	"/_app/kds": {
		filePath: "/workspace/src/routes/_app/kds.tsx",
		children: void 0,
		preloads: ["/assets/kds-Vx_tF4At.js"]
	},
	"/_app/pos": {
		filePath: "/workspace/src/routes/_app/pos.tsx",
		children: void 0,
		preloads: ["/assets/pos-CoEdeIYn.js"]
	},
	"/_app/tables": {
		filePath: "/workspace/src/routes/_app/tables.tsx",
		children: void 0,
		preloads: ["/assets/tables-C9TyFvzK.js"]
	}
} });
//#endregion
export { tsrStartManifest };
