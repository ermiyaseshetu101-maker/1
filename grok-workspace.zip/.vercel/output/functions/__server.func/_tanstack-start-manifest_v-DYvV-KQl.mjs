//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DYvV-KQl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/_app",
			"/login",
			"/onboarding",
			"/pending",
			"/pin",
			"/plans",
			"/platform",
			"/register",
			"/verify",
			"/checkout/$planId",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-CLYlIwXT.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/tenant-BxF9-q84.js",
			"/assets/link-CLa4D0lu.js",
			"/assets/useMatch-Nbhoexqh.js",
			"/assets/i18n-DPJH3loo.js",
			"/assets/useRouter-DTQ3YH1D.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CLYlIwXT.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BUP2g8iX.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/admin",
			"/_app/kds",
			"/_app/pos",
			"/_app/tables"
		],
		preloads: [
			"/assets/_app-CRtorxoe.js",
			"/assets/chef-hat-CLr92BJP.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/badge-Bx8s5ZkQ.js",
			"/assets/format-DoXhSDz5.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DRYKaknG.js",
			"/assets/client-bLCk0icn.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/onboarding": {
		filePath: "/workspace/src/routes/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-DBmXjZoT.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/pending": {
		filePath: "/workspace/src/routes/pending.tsx",
		children: void 0,
		preloads: [
			"/assets/pending-nleAHMkQ.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/pin": {
		filePath: "/workspace/src/routes/pin.tsx",
		children: void 0,
		preloads: [
			"/assets/pin-DUjq0h8k.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/plans": {
		filePath: "/workspace/src/routes/plans.tsx",
		children: void 0,
		preloads: [
			"/assets/plans-Ab6280XY.js",
			"/assets/minus-BCpVm-Xt.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/badge-Bx8s5ZkQ.js",
			"/assets/format-DoXhSDz5.js",
			"/assets/owner-shell-DKmFk9R1.js",
			"/assets/billing-DonaIFUy.js"
		]
	},
	"/platform": {
		filePath: "/workspace/src/routes/platform.tsx",
		children: void 0,
		preloads: [
			"/assets/platform-Df7PY3ho.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/badge-Bx8s5ZkQ.js",
			"/assets/format-DoXhSDz5.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-CXXwqK0Z.js",
			"/assets/client-bLCk0icn.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/verify": {
		filePath: "/workspace/src/routes/verify.tsx",
		children: void 0,
		preloads: [
			"/assets/verify-BwKhCSon.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/owner-shell-DKmFk9R1.js"
		]
	},
	"/_app/admin": {
		filePath: "/workspace/src/routes/_app/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-Dh0MTr6h.js"]
	},
	"/_app/kds": {
		filePath: "/workspace/src/routes/_app/kds.tsx",
		children: void 0,
		preloads: ["/assets/kds-CVdbHxRe.js"]
	},
	"/_app/pos": {
		filePath: "/workspace/src/routes/_app/pos.tsx",
		children: void 0,
		preloads: ["/assets/pos--eBTO9MK.js", "/assets/minus-BCpVm-Xt.js"]
	},
	"/_app/tables": {
		filePath: "/workspace/src/routes/_app/tables.tsx",
		children: void 0,
		preloads: ["/assets/tables-DJyQ-oIs.js"]
	},
	"/checkout/$planId": {
		filePath: "/workspace/src/routes/checkout.$planId.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout._planId-C__vociw.js",
			"/assets/button-DqJOZ8iz.js",
			"/assets/format-DoXhSDz5.js",
			"/assets/owner-shell-DKmFk9R1.js",
			"/assets/billing-DonaIFUy.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
