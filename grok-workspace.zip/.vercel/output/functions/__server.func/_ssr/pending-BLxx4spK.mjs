import { S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTenant, b as usePOSStore, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { a as StatusScreen, i as RedirectToSignIn, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pending-BLxx4spK.js
var import_jsx_runtime = require_jsx_runtime();
function Pending() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const language = usePOSStore((s) => s.language);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	const status = bootstrap?.restaurant?.status;
	if (status === "active" && !bootstrap?.entitlements?.billingLocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pin" });
	if (bootstrap?.entitlements?.billingLocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/plans" });
	const suspended = status === "suspended" || status === "rejected";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
		title: t(language, suspended ? "suspendedTitle" : "pendingTitle"),
		body: suspended ? t(language, "suspendedTitle") : t(language, "pendingBody"),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/plans",
				children: t(language, "plansTitle")
			})
		})
	});
}
//#endregion
export { Pending as component };
