import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, d as uid, l as getSql } from "./utils-zqpJ-D4Z.mjs";
import { Ft as string, Mt as object, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { c as trialDaysLeft, i as mapRestaurant, n as getEntitlements, o as seedRestaurantCatalog, r as getOrCreateProfile, s as slugify, t as createServerRpc } from "./tenant-v1xgc2D-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bootstrap-DpwV5KVW.js
var getBootstrap_createServerFn_handler = createServerRpc({
	id: "d06f35d7ccfc6bbc1796182b4b4567c7df6ed504ba779ad703619d8555311a43",
	name: "getBootstrap",
	filename: "src/lib/api/bootstrap.ts"
}, (opts) => getBootstrap.__executeServer(opts));
var getBootstrap = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getBootstrap_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const profileRow = await getOrCreateProfile(sql, context.userId);
	const profile = {
		userId: profileRow.user_id,
		platformRole: profileRow.platform_role,
		emailVerified: profileRow.email_verified,
		displayName: profileRow.display_name,
		restaurantId: profileRow.restaurant_id
	};
	if (!profileRow.restaurant_id) return {
		profile,
		restaurant: null,
		entitlements: null
	};
	const rows = await sql`
      select id, owner_user_id, name, slug, status, plan_id, currency, language, receipt_footer, trial_ends_at
      from restaurants where id = ${profileRow.restaurant_id}
    `;
	const restaurant = rows[0] ? mapRestaurant(rows[0]) : null;
	return {
		profile,
		restaurant,
		entitlements: restaurant ? await getEntitlements(sql, restaurant) : null
	};
});
var verifyEmail_createServerFn_handler = createServerRpc({
	id: "4c3cf656b45ea22a722dd78ca4c5c42eaf999bb3c1c18187df0ac506fdfcf1f0",
	name: "verifyEmail",
	filename: "src/lib/api/bootstrap.ts"
}, (opts) => verifyEmail.__executeServer(opts));
var verifyEmail = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(verifyEmail_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await getOrCreateProfile(sql, context.userId);
	await sql`update profiles set email_verified = true where user_id = ${context.userId}`;
	return { ok: true };
});
var markEmailUnverified_createServerFn_handler = createServerRpc({
	id: "e5fb5567a68ae0b71e7fde8e8344e71d29802471e01edbcbe59f6482c72511f8",
	name: "markEmailUnverified",
	filename: "src/lib/api/bootstrap.ts"
}, (opts) => markEmailUnverified.__executeServer(opts));
var markEmailUnverified = createServerFn({ method: "POST" }).validator(object({ displayName: string().trim().min(2).max(80).optional() })).middleware([authMiddleware]).handler(markEmailUnverified_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await getOrCreateProfile(sql, context.userId, {
		verified: false,
		displayName: data.displayName ?? null
	});
	await sql`
      update profiles
      set email_verified = false,
          display_name = coalesce(${data.displayName ?? null}, display_name)
      where user_id = ${context.userId}
    `;
	return { ok: true };
});
var createRestaurant_createServerFn_handler = createServerRpc({
	id: "a9db28c574137613505463582be471112c7014f84b1bd177acc99bbecc0e0c9a",
	name: "createRestaurant",
	filename: "src/lib/api/bootstrap.ts"
}, (opts) => createRestaurant.__executeServer(opts));
var createRestaurant = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2).max(80),
	language: _enum(["en", "am"]).default("en"),
	ownerName: string().trim().min(2).max(80).optional()
})).middleware([authMiddleware]).handler(createRestaurant_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const profile = await getOrCreateProfile(sql, context.userId, { displayName: data.ownerName });
	if (!profile.email_verified) throw new Error("EMAIL_UNVERIFIED");
	if (profile.restaurant_id) throw new Error("ALREADY_HAS_RESTAURANT");
	const id = uid("rst");
	const slug = slugify(data.name);
	const trialEnds = new Date(Date.now() + 3888e6).toISOString();
	await sql`
      insert into restaurants (id, owner_user_id, name, slug, status, plan_id, language, trial_ends_at)
      values (${id}, ${context.userId}, ${data.name}, ${slug}, 'active', 'plan_trial', ${data.language}, ${trialEnds})
    `;
	await sql`
      update profiles
      set restaurant_id = ${id},
          display_name = coalesce(${data.ownerName ?? null}, display_name)
      where user_id = ${context.userId}
    `;
	await sql`
      insert into subscriptions (id, restaurant_id, plan_id, status, current_period_end)
      values (${uid("sub")}, ${id}, 'plan_trial', 'trialing', ${trialEnds})
    `;
	await seedRestaurantCatalog(sql, id);
	return {
		id,
		status: "active",
		trialDaysLeft: trialDaysLeft(trialEnds)
	};
});
//#endregion
export { createRestaurant_createServerFn_handler, getBootstrap_createServerFn_handler, markEmailUnverified_createServerFn_handler, verifyEmail_createServerFn_handler };
