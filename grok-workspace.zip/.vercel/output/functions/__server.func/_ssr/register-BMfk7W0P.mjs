import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { t as GROK_PROVIDERS } from "./server-Bf62GwQt.mjs";
import { b as usePOSStore, d as markEmailUnverified, i as AuthPage, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { r as PageSkeleton, s as fieldClass, t as Field } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-BMfk7W0P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PENDING_KEY = "simplepos.pending-restaurant";
function savePendingRestaurant(name, ownerName, language) {
	try {
		sessionStorage.setItem(PENDING_KEY, JSON.stringify({
			name,
			ownerName,
			language
		}));
	} catch {}
}
function readPendingRestaurant() {
	try {
		const raw = sessionStorage.getItem(PENDING_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function Register() {
	const { user, isPending } = useCurrentUserState();
	const language = usePOSStore((s) => s.language);
	const [restaurantName, setRestaurantName] = (0, import_react.useState)("");
	const [ownerName, setOwnerName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function onSubmit(e) {
		e.preventDefault();
		if (password !== confirm) {
			setError("Passwords do not match");
			return;
		}
		if (password.length < 8) {
			setError("Password must be at least 8 characters");
			return;
		}
		setBusy(true);
		setError(null);
		const { error: err } = await authClient.signUp.email({
			email,
			password,
			name: ownerName
		});
		if (err) {
			setBusy(false);
			setError(err.message ?? "Could not create account");
			return;
		}
		savePendingRestaurant(restaurantName, ownerName, language);
		try {
			await markEmailUnverified({ data: { displayName: ownerName } });
		} catch {}
		setBusy(false);
		window.location.assign("/verify");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthPage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: t(language, "ownerRegister")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: t(language, "daysTrial")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 space-y-2",
			children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				className: "w-full",
				onClick: () => {
					savePendingRestaurant(restaurantName || "My restaurant", ownerName || "Owner", language);
					signIn(p.providerId, { callbackURL: "/" });
				},
				children: p.label === "X" ? t(language, "continueX") : t(language, "continueGoogle")
			}, p.providerId))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 mb-3 text-center text-xs tracking-wide text-muted uppercase",
			children: t(language, "orEmail")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: (e) => void onSubmit(e),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "restaurantName"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						required: true,
						minLength: 2,
						value: restaurantName,
						onChange: (e) => setRestaurantName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "ownerName"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						required: true,
						minLength: 2,
						autoComplete: "name",
						value: ownerName,
						onChange: (e) => setOwnerName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "email"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "email",
						required: true,
						autoComplete: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "password"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "password",
						required: true,
						minLength: 8,
						autoComplete: "new-password",
						value: password,
						onChange: (e) => setPassword(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "confirmPassword"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "password",
						required: true,
						minLength: 8,
						autoComplete: "new-password",
						value: confirm,
						onChange: (e) => setConfirm(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy,
					children: t(language, "createAccount")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-center text-sm text-muted",
			children: [
				t(language, "haveAccount"),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "text-fg underline-offset-4 hover:underline",
					children: t(language, "ownerLogin")
				})
			]
		})
	] });
}
//#endregion
export { Register as component, readPendingRestaurant, savePendingRestaurant };
