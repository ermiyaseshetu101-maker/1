import { C as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as cn } from "./utils-zqpJ-D4Z.mjs";
import { r as cartTotals } from "./types-CYB28pJW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { b as usePOSStore, v as t, y as tableStatusLabel } from "./router-DdtrxyM9.mjs";
import { t as Badge } from "./badge-BAjpSyJ1.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as formatETB } from "./format-CSAY-VyI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tables-BscmKCpY.js
var import_jsx_runtime = require_jsx_runtime();
var TONE = {
	available: "success",
	occupied: "warning",
	reserved: "info"
};
function FloorPlan() {
	const language = usePOSStore((s) => s.language);
	const tables = usePOSStore((s) => s.tables);
	const orders = usePOSStore((s) => s.orders);
	const openTable = usePOSStore((s) => s.openTable);
	const closeTable = usePOSStore((s) => s.closeTable);
	const assignTable = usePOSStore((s) => s.assignTable);
	const navigate = useNavigate();
	function go(table) {
		if (table.status === "reserved") return;
		openTable(table.id);
		assignTable(table.id);
		navigate({ to: "/pos" });
	}
	function onClose(table) {
		if (!closeTable(table.id)) toast.error(t(language, "mustPay"));
		else toast.success(t(language, "tableClosed"));
	}
	const counts = {
		available: tables.filter((tb) => tb.status === "available").length,
		occupied: tables.filter((tb) => tb.status === "occupied").length,
		reserved: tables.filter((tb) => tb.status === "reserved").length
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2 border-b border-border px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mr-auto text-lg font-semibold tracking-tight",
				children: t(language, "floor")
			}), [
				"available",
				"occupied",
				"reserved"
			].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				tone: TONE[s],
				children: [
					tableStatusLabel(language, s),
					" ",
					counts[s]
				]
			}, s))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 overflow-auto p-4 sm:grid-cols-3 lg:grid-cols-4",
			children: tables.map((table) => {
				const order = orders.find((o) => o.id === table.orderId);
				const total = order ? cartTotals(order.items).total : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("flex min-h-36 flex-col rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]", table.status === "occupied" && "ring-1 ring-warning/40", table.status === "reserved" && "opacity-70"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold tracking-tight",
								children: table.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: TONE[table.status],
								children: tableStatusLabel(language, table.status)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								table.seats,
								" ",
								t(language, "seats")
							]
						}),
						order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm tabular-nums text-fg",
							children: [
								"#",
								order.number,
								" · ",
								formatETB(total, language)
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-subtle",
							children: "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto flex gap-2 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "flex-1",
								disabled: table.status === "reserved",
								onClick: () => go(table),
								children: order ? t(language, "viewOrder") : t(language, "openTable")
							}), table.status === "occupied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => onClose(table),
								children: t(language, "closeTable")
							}) : null]
						})
					]
				}, table.id);
			})
		})]
	});
}
var SplitComponent = FloorPlan;
//#endregion
export { SplitComponent as component };
