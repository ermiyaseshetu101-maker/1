import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Search, d as Minus, h as CreditCard, i as Trash2, l as Plus, n as UtensilsCrossed, o as Smartphone, t as X, v as Banknote } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as CATEGORIES, n as usePOSStore, r as cn, s as cartTotals } from "./router-CAWKn_qj.mjs";
import { a as formatETB, t as Badge } from "./format-LHQ-Xxf1.mjs";
import { n as localizedName, o as t, t as Button } from "./i18n-BC5Nz44z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pos-DrKnKMyw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var METHODS = [
	{
		id: "cash",
		icon: Banknote
	},
	{
		id: "card",
		icon: CreditCard
	},
	{
		id: "telebirr",
		icon: Smartphone
	}
];
function CheckoutDialog({ onClose }) {
	const language = usePOSStore((s) => s.language);
	const cart = usePOSStore((s) => s.cart);
	const checkout = usePOSStore((s) => s.checkout);
	const [method, setMethod] = (0, import_react.useState)("cash");
	const [digits, setDigits] = (0, import_react.useState)("");
	const totals = cartTotals(cart.items);
	const tendered = digits ? Number(digits) : totals.total;
	const change = Math.max(0, tendered - totals.total);
	const short = method === "cash" && tendered < totals.total;
	const quick = (0, import_react.useMemo)(() => [
		totals.total,
		Math.ceil(totals.total / 100) * 100,
		500,
		1e3
	].filter((v, i, arr) => v >= totals.total && arr.indexOf(v) === i), [totals.total]);
	function confirm() {
		if (short) {
			toast.error(t(language, "insufficient"));
			return;
		}
		const order = checkout(method, method === "cash" ? tendered : void 0);
		if (!order) {
			toast.error(t(language, "insufficient"));
			return;
		}
		toast.success(`${t(language, "paymentOk")} #${order.number}`);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-0 sm:items-center sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[92dvh] w-full max-w-lg flex-col overflow-auto rounded-t-3xl bg-surface shadow-[var(--shadow-border)] sm:rounded-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: t(language, "checkout")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tabular-nums text-muted",
						children: formatETB(totals.total, language)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						onClick: onClose,
						"aria-label": t(language, "close"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: t(language, "paymentMethod")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: METHODS.map((m) => {
							const Icon = m.icon;
							const active = method === m.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMethod(m.id),
								className: cn("flex min-h-20 flex-col items-center justify-center gap-1 rounded-2xl text-sm font-medium transition-colors duration-150", active ? "bg-fg text-bg" : "bg-elevated text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), t(language, m.id)]
							}, m.id);
						})
					})]
				}),
				method === "cash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
							children: t(language, "tendered")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-3xl font-semibold tabular-nums tracking-tight",
							children: formatETB(tendered, language)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex flex-wrap gap-2",
							children: quick.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "muted",
								size: "sm",
								onClick: () => setDigits(String(v)),
								children: formatETB(v, language)
							}, v))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								"1",
								"2",
								"3",
								"4",
								"5",
								"6",
								"7",
								"8",
								"9",
								"C",
								"0",
								"⌫"
							].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "lg",
								onClick: () => {
									if (k === "C") setDigits("");
									else if (k === "⌫") setDigits((d) => d.slice(0, -1));
									else setDigits((d) => (d + k).replace(/^0+/, "") || "0");
								},
								children: k
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: t(language, "change")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-semibold tabular-nums", short && "text-danger"),
								children: short ? t(language, "insufficient") : formatETB(change, language)
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-5 py-6 text-sm text-muted",
					children: method === "telebirr" ? language === "am" ? "ቴሌብር ክፍያውን በተርሚናሉ ላይ ያረጋግጡ።" : "Confirm the Telebirr push on the terminal, then record payment." : language === "am" ? "ካርዱን በመሣሪያው ላይ ያስነሱ እና ያረጋግጡ።" : "Tap the card on the reader, then record payment."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "lg",
						onClick: onClose,
						children: t(language, "cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: confirm,
						disabled: short,
						children: t(language, "confirmPay")
					})]
				})
			]
		})
	});
}
function PosScreen() {
	const language = usePOSStore((s) => s.language);
	const products = usePOSStore((s) => s.products);
	const tables = usePOSStore((s) => s.tables);
	const cart = usePOSStore((s) => s.cart);
	const addToCart = usePOSStore((s) => s.addToCart);
	const setQty = usePOSStore((s) => s.setQty);
	const assignTable = usePOSStore((s) => s.assignTable);
	const sendToKitchen = usePOSStore((s) => s.sendToKitchen);
	const clearCart = usePOSStore((s) => s.clearCart);
	const [query, setQuery] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("all");
	const [payOpen, setPayOpen] = (0, import_react.useState)(false);
	const [cartOpen, setCartOpen] = (0, import_react.useState)(false);
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return products.filter((p) => {
			if (cat !== "all" && p.categoryId !== cat) return false;
			if (!q) return true;
			return p.name.toLowerCase().includes(q) || p.nameAm.includes(q) || String(p.price).includes(q);
		});
	}, [
		products,
		cat,
		query
	]);
	const totals = cartTotals(cart.items);
	const table = tables.find((tb) => tb.id === cart.tableId);
	const nameOf = (item) => localizedName(language, item);
	function onSend() {
		if (cart.items.length === 0) {
			toast.error(t(language, "needItems"));
			return;
		}
		const order = sendToKitchen();
		if (!order) {
			toast.error(t(language, "sendNeedTable"));
			return;
		}
		toast.success(`${t(language, "orderSent")} #${order.number}`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 border-b border-border px-3 py-3 md:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: t(language, "searchMenu"),
								className: "h-11 w-full rounded-xl bg-surface pr-3 pl-10 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus:ring-2 focus:ring-accent/40"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: cart.tableId ?? "",
							onChange: (e) => assignTable(e.target.value || void 0),
							className: "h-11 max-w-[9.5rem] rounded-xl bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none",
							"aria-label": t(language, "pickTable"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: t(language, "takeaway")
							}), tables.map((tb) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: tb.id,
								disabled: tb.status === "reserved",
								children: [tb.label, tb.status === "occupied" ? " ●" : ""]
							}, tb.id))]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 overflow-x-auto pb-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryChip, {
							active: cat === "all",
							onClick: () => setCat("all"),
							children: t(language, "all")
						}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryChip, {
							active: cat === c.id,
							onClick: () => setCat(c.id),
							children: nameOf(c)
						}, c.id))]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 overflow-auto p-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 md:p-4",
					children: filtered.map((p) => {
						const inCart = cart.items.find((i) => i.productId === p.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !p.available,
							onClick: () => addToCart(p),
							className: cn("flex min-h-[7.5rem] flex-col rounded-2xl bg-surface p-3 text-left shadow-[var(--shadow-border)] transition-[transform,background-color] duration-150 active:scale-[0.98]", !p.available && "opacity-40", inCart && "ring-1 ring-fg/20"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-snug font-medium",
									children: nameOf(p)
								}), inCart ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "solid",
									className: "tabular-nums",
									children: inCart.qty
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-auto pt-3 font-medium tabular-nums text-muted",
								children: p.available ? formatETB(p.price, language) : t(language, "unavailable")
							})]
						}, p.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-[22rem] shrink-0 flex-col border-l border-border bg-surface md:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartBody, {
					language,
					tableLabel: table?.label,
					totals,
					items: cart.items,
					onQty: setQty,
					onClear: clearCart,
					onSend,
					onPay: () => setPayOpen(true)
				})
			}),
			totals.count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-14 z-20 p-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "xl",
					className: "w-full justify-between rounded-2xl",
					onClick: () => setCartOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t(language, "cart"),
						" · ",
						totals.count
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatETB(totals.total, language)
					})]
				})
			}) : null,
			cartOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex flex-col bg-bg/70 md:hidden",
				onClick: () => setCartOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex max-h-[85dvh] flex-col rounded-t-3xl bg-surface",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: t(language, "cart")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => setCartOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartBody, {
						language,
						tableLabel: table?.label,
						totals,
						items: cart.items,
						onQty: setQty,
						onClear: clearCart,
						onSend,
						onPay: () => {
							setCartOpen(false);
							setPayOpen(true);
						}
					})]
				})
			}) : null,
			payOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutDialog, { onClose: () => setPayOpen(false) }) : null
		]
	});
}
function CategoryChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 shrink-0 rounded-full px-4 text-sm font-medium transition-colors duration-150", active ? "bg-fg text-bg" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
		children
	});
}
function CartBody({ language, tableLabel, totals, items, onQty, onClear, onSend, onPay }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: t(language, "cart")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: tableLabel ?? t(language, "takeaway")
				})] }), items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					onClick: onClear,
					"aria-label": t(language, "clear"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-auto px-3 py-3",
				children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full flex-col items-center justify-center gap-2 px-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-8 text-subtle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: t(language, "emptyCart")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: t(language, "emptyCartHint")
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 rounded-xl bg-elevated px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: localizedName(language, item)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tabular-nums text-muted",
								children: formatETB(item.price, language)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "size-9",
									onClick: () => onQty(item.id, item.qty - 1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-6 text-center text-sm tabular-nums",
									children: item.qty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "size-9",
									onClick: () => onQty(item.id, item.qty + 1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								})
							]
						})]
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 border-t border-border p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(language, "subtotal"),
						value: formatETB(totals.subtotal, language)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(language, "vat"),
						value: formatETB(totals.vat, language),
						muted: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(language, "total"),
						value: formatETB(totals.total, language),
						strong: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "lg",
							onClick: onSend,
							disabled: items.length === 0,
							children: t(language, "sendKitchen")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							onClick: onPay,
							disabled: items.length === 0,
							children: t(language, "pay")
						})]
					})
				]
			})
		]
	});
}
function Row({ label, value, muted, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center justify-between text-sm", muted && "text-muted", strong && "font-semibold"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	});
}
var SplitComponent = PosScreen;
//#endregion
export { SplitComponent as component };
