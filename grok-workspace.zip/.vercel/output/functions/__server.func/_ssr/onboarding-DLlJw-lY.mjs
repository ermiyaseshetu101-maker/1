import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useNavigate, S as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTenant, b as usePOSStore, r as readPendingRestaurant, s as useCurrentUserState, u as createRestaurant, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as RedirectToSignIn, n as OwnerShell, r as PageSkeleton, s as fieldClass, t as Field } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-DLlJw-lY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Onboarding() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading, refresh } = useTenant();
	const language = usePOSStore((s) => s.language);
	const pending = typeof window !== "undefined" ? readPendingRestaurant() : null;
	const [name, setName] = (0, import_react.useState)(pending?.name ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!bootstrap?.profile.emailVerified) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/verify" });
	if (bootstrap.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pin" });
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await createRestaurant({ data: {
				name,
				language,
				ownerName: pending?.ownerName ?? user?.displayName ?? void 0
			} });
			await refresh();
			navigate({ to: "/pin" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not create restaurant");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerShell, {
		title: t(language, "onboardingTitle"),
		subtitle: t(language, "daysTrial"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => void onSubmit(e),
			className: "mx-auto max-w-md space-y-4 rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight",
					children: t(language, "onboardingTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(language, "restaurantName"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						required: true,
						minLength: 2,
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy,
					children: t(language, "startTrial")
				})
			]
		})
	});
}
//#endregion
export { Onboarding as component };
