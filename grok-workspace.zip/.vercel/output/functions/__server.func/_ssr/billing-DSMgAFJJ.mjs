import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware } from "./utils-zqpJ-D4Z.mjs";
import { Ft as string, Mt as object, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { p as createSsrRpc } from "./router-DdtrxyM9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-DSMgAFJJ.js
var listPlans = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4a6ebbae872f38d41ddadae96204346ad73b3c3d7b049584725bea46711414e7"));
var startCheckout = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	provider: _enum([
		"stripe",
		"chapa",
		"telebirr",
		"card"
	])
})).middleware([authMiddleware]).handler(createSsrRpc("08a84f880995420c6a0e493648a70d7c24760e05d7f19d421af75a6df0544df3"));
var confirmSandboxPayment = createServerFn({ method: "POST" }).validator(object({ paymentId: string() })).middleware([authMiddleware]).handler(createSsrRpc("a52985b2a4447cb3f16cee54a05fd10ff72dc64f4c30e029e730bed15abb9deb"));
//#endregion
export { listPlans as n, startCheckout as r, confirmSandboxPayment as t };
