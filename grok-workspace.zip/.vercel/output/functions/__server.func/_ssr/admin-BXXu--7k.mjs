import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as limitOf, i as hasFeature, n as ALL_ROLES, r as cartTotals, t as ADMIN_ROLES } from "./types-CYB28pJW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as statusLabel, a as useTenant, b as usePOSStore, c as addStaff, g as roleLabel, h as paymentLabel, l as getCatalog, m as localizedName, v as t } from "./router-DdtrxyM9.mjs";
import { t as Badge } from "./badge-BAjpSyJ1.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { a as startOfDay, i as formatETB, r as formatDate } from "./format-CSAY-VyI.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BXXu--7k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminScreen() {
	const session = usePOSStore((s) => s.session);
	const language = usePOSStore((s) => s.language);
	const orders = usePOSStore((s) => s.orders);
	const tables = usePOSStore((s) => s.tables);
	const products = usePOSStore((s) => s.products);
	const categories = usePOSStore((s) => s.categories);
	const staff = usePOSStore((s) => s.staff);
	const toggleProduct = usePOSStore((s) => s.toggleProduct);
	const resetDemo = usePOSStore((s) => s.resetDemo);
	const hydrateCatalog = usePOSStore((s) => s.hydrateCatalog);
	const { bootstrap, refresh } = useTenant();
	const ent = bootstrap?.entitlements;
	const canReports = hasFeature(ent, "reports");
	const staffCap = limitOf(ent, "max_staff");
	const atStaffLimit = staffCap !== -1 && staff.filter((s) => s.active !== false).length >= staffCap;
	const [name, setName] = (0, import_react.useState)("");
	const [pin, setPin] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("cashier");
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!session || !ADMIN_ROLES.includes(session.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[60vh] flex-col items-center justify-center gap-3 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t(language, "accessDenied")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/pos",
				children: t(language, "backToPos")
			})
		})]
	});
	const today = startOfDay();
	const paidToday = orders.filter((o) => o.paid && o.createdAt >= today);
	const salesToday = paidToday.reduce((s, o) => s + cartTotals(o.items, o.discount).total, 0);
	const avg = paidToday.length ? Math.round(salesToday / paidToday.length) : 0;
	const occupied = tables.filter((tb) => tb.status === "occupied").length;
	const chart = Array.from({ length: 7 }, (_, i) => {
		const day = startOfDay(Date.now() - (6 - i) * 864e5);
		const next = day + 864e5;
		const dayOrders = orders.filter((o) => o.paid && o.createdAt >= day && o.createdAt < next);
		return {
			label: formatDate(day, language),
			sales: dayOrders.reduce((s, o) => s + cartTotals(o.items, o.discount).total, 0)
		};
	});
	const recent = [...orders].sort((a, b) => b.createdAt - a.createdAt).slice(0, 8);
	async function onAddStaff(e) {
		e.preventDefault();
		if (atStaffLimit) {
			toast.error(t(language, "staffLimit"));
			return;
		}
		setBusy(true);
		try {
			await addStaff({ data: {
				name,
				nameAm: name,
				pin,
				role
			} });
			const catalog = await getCatalog();
			hydrateCatalog(catalog);
			setName("");
			setPin("");
			toast.success(t(language, "addStaff"));
			await refresh();
		} catch (err) {
			const msg = err instanceof Error ? err.message : t(language, "staffLimit");
			toast.error(msg === "STAFF_LIMIT" ? t(language, "staffLimit") : msg);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col gap-5 overflow-auto p-4 md:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-semibold tracking-tight",
						children: t(language, "dashboard")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/plans",
						className: "text-xs text-muted hover:text-fg",
						children: [
							ent?.planName,
							" · ",
							t(language, "choosePlan")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						className: "ml-auto",
						onClick: () => {
							resetDemo();
							toast.success(t(language, "resetOk"));
						},
						children: t(language, "resetDemo")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: t(language, "todaySales"),
						value: formatETB(salesToday, language)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: t(language, "todayOrders"),
						value: String(paidToday.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: t(language, "avgTicket"),
						value: formatETB(avg, language)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: t(language, "openTables"),
						value: `${occupied}/${tables.length}`
					})
				]
			}),
			canReports ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-sm font-semibold",
					children: t(language, "last7")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-52",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: chart,
							barCategoryGap: "28%",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									tick: { fontSize: 11 },
									stroke: "currentColor",
									className: "text-subtle"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: { fontSize: 11 },
									stroke: "currentColor",
									className: "text-subtle",
									width: 48
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "color-mix(in oklab, var(--fg) 6%, transparent)" },
									contentStyle: {
										background: "var(--surface)",
										border: "1px solid var(--border)",
										borderRadius: 12,
										color: "var(--fg)"
									},
									formatter: (value) => [formatETB(Number(value ?? 0), language), t(language, "sales")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "sales",
									fill: "var(--fg)",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: t(language, "advancedReports")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t(language, "featureLocked")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/plans",
							children: t(language, "upgrade")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-sm font-semibold",
							children: t(language, "staff")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border",
							children: staff.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: localizedName(language, s)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: roleLabel(language, s.role)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm tabular-nums text-muted",
									children: s.pin
								})]
							}, s.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-4 grid gap-2 sm:grid-cols-4",
							onSubmit: (e) => void onAddStaff(e),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									minLength: 2,
									placeholder: t(language, "ownerName"),
									value: name,
									onChange: (e) => setName(e.target.value),
									className: "h-10 rounded-xl bg-elevated px-3 text-sm outline-none sm:col-span-2"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									pattern: "\\d{4}",
									maxLength: 4,
									placeholder: t(language, "pin"),
									value: pin,
									onChange: (e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4)),
									className: "h-10 rounded-xl bg-elevated px-3 text-sm outline-none"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: role,
									onChange: (e) => setRole(e.target.value),
									className: "h-10 rounded-xl bg-elevated px-3 text-sm outline-none",
									children: ALL_ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: r,
										children: roleLabel(language, r)
									}, r))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "sm:col-span-4",
									disabled: busy || atStaffLimit,
									children: atStaffLimit ? t(language, "staffLimit") : t(language, "addStaff")
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: t(language, "recentOrders")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: recent.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-medium tabular-nums",
										children: [
											"#",
											o.number,
											" · ",
											o.tableLabel ?? t(language, "takeaway")
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: o.paymentMethod ? paymentLabel(language, o.paymentMethod) : t(language, "unpaid")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: o.status === "completed" ? "success" : o.status === "ready" ? "success" : o.status === "preparing" ? "warning" : "info",
									children: statusLabel(language, o.status)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm tabular-nums",
									children: formatETB(cartTotals(o.items, o.discount).total, language)
								})
							]
						}, o.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-semibold",
					children: t(language, "menuAvailability")
				}), categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 last:mb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: localizedName(language, cat)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2 sm:grid-cols-2",
						children: products.filter((p) => p.categoryId === cat.id).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-xl bg-elevated px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: localizedName(language, p)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleProduct(p.id),
								className: "text-xs font-medium text-muted",
								children: p.available ? t(language, "on") : t(language, "off")
							})]
						}, p.id))
					})]
				}, cat.id))]
			})
		]
	});
}
function Kpi({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-2xl font-semibold tracking-tight tabular-nums",
			children: value
		})]
	});
}
var SplitComponent = AdminScreen;
//#endregion
export { SplitComponent as component };
