import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useNavigate, S as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTenant, b as usePOSStore, f as verifyEmail, r as readPendingRestaurant, s as useCurrentUserState, u as createRestaurant, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as RedirectToSignIn, n as OwnerShell, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/verify-AxSKaumC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Verify() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading, refresh } = useTenant();
	const language = usePOSStore((s) => s.language);
	const navigate = useNavigate();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (bootstrap?.profile.emailVerified) {
		if (!bootstrap.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pin" });
	}
	async function onVerify() {
		setBusy(true);
		setError(null);
		try {
			await verifyEmail();
			const pending = readPendingRestaurant();
			const next = await refresh();
			if (next && !next.restaurant && pending?.name) {
				await createRestaurant({ data: {
					name: pending.name,
					ownerName: pending.ownerName,
					language: pending.language
				} });
				await refresh();
			}
			navigate({ to: "/" });
		} catch (e) {
			setError(e instanceof Error ? e.message : "Verification failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerShell, {
		title: t(language, "verifyTitle"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight",
					children: t(language, "verifyTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(language, "verifyBody")
				}),
				user.primaryEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-xl bg-elevated px-3 py-2 text-sm",
					children: user.primaryEmail
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					disabled: busy,
					onClick: () => void onVerify(),
					children: t(language, "verifyNow")
				})
			]
		})
	});
}
//#endregion
export { Verify as component };
