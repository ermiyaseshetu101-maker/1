import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, d as uid, l as getSql } from "./utils-zqpJ-D4Z.mjs";
import { Ft as string, Mt as object, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { a as requireRestaurant, r as getOrCreateProfile, t as createServerRpc } from "./tenant-v1xgc2D-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-DmfvD8TP.js
var listPlans_createServerFn_handler = createServerRpc({
	id: "4a6ebbae872f38d41ddadae96204346ad73b3c3d7b049584725bea46711414e7",
	name: "listPlans",
	filename: "src/lib/api/billing.ts"
}, (opts) => listPlans.__executeServer(opts));
var listPlans = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPlans_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await getOrCreateProfile(sql, context.userId);
	const plans = await sql`
      select id, name, slug, price_etb, billing_interval, description
      from plans where is_public = true order by sort_order
    `;
	const feats = await sql`
      select pf.plan_id, f.key, f.name, pf.enabled, pf.limit_value
      from plan_features pf
      join features f on f.id = pf.feature_id
    `;
	return plans.map((p) => ({
		id: p.id,
		name: p.name,
		slug: p.slug,
		priceEtb: Number(p.price_etb),
		interval: p.billing_interval,
		description: p.description,
		features: feats.filter((f) => f.plan_id === p.id).map((f) => ({
			key: f.key,
			name: f.name,
			enabled: f.enabled,
			limit: f.limit_value == null ? null : Number(f.limit_value)
		}))
	}));
});
var startCheckout_createServerFn_handler = createServerRpc({
	id: "08a84f880995420c6a0e493648a70d7c24760e05d7f19d421af75a6df0544df3",
	name: "startCheckout",
	filename: "src/lib/api/billing.ts"
}, (opts) => startCheckout.__executeServer(opts));
var startCheckout = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	provider: _enum([
		"stripe",
		"chapa",
		"telebirr",
		"card"
	])
})).middleware([authMiddleware]).handler(startCheckout_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant } = await requireRestaurant(sql, context.userId);
	const plan = (await sql`
      select id, price_etb from plans where id = ${data.planId}
    `)[0];
	if (!plan) throw new Error("PLAN_NOT_FOUND");
	const paymentId = uid("pay");
	await sql`
      insert into payments (id, restaurant_id, plan_id, amount_etb, provider, status)
      values (${paymentId}, ${restaurant.id}, ${plan.id}, ${plan.price_etb}, ${data.provider}, 'pending')
    `;
	return {
		paymentId,
		amountEtb: Number(plan.price_etb),
		provider: data.provider,
		checkoutHint: data.provider === "chapa" ? "Chapa hosted checkout will open here." : data.provider === "telebirr" ? "Telebirr STK / USSD prompt will open here." : data.provider === "stripe" ? "Stripe Checkout session will be created here." : "Card fields will be collected by your processor."
	};
});
var confirmSandboxPayment_createServerFn_handler = createServerRpc({
	id: "a52985b2a4447cb3f16cee54a05fd10ff72dc64f4c30e029e730bed15abb9deb",
	name: "confirmSandboxPayment",
	filename: "src/lib/api/billing.ts"
}, (opts) => confirmSandboxPayment.__executeServer(opts));
var confirmSandboxPayment = createServerFn({ method: "POST" }).validator(object({ paymentId: string() })).middleware([authMiddleware]).handler(confirmSandboxPayment_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant } = await requireRestaurant(sql, context.userId);
	const pay = (await sql`
      select plan_id, status from payments
      where id = ${data.paymentId} and restaurant_id = ${restaurant.id}
    `)[0];
	if (!pay) throw new Error("NOT_FOUND");
	const periodEnd = new Date(Date.now() + 2592e6).toISOString();
	await sql`
      update payments set status = 'completed' where id = ${data.paymentId} and restaurant_id = ${restaurant.id}
    `;
	await sql`
      insert into subscriptions (id, restaurant_id, plan_id, status, current_period_end)
      values (${uid("sub")}, ${restaurant.id}, ${pay.plan_id}, 'active', ${periodEnd})
    `;
	await sql`
      update restaurants set plan_id = ${pay.plan_id}, status = 'active'
      where id = ${restaurant.id} and owner_user_id = ${context.userId}
    `;
	return {
		ok: true,
		planId: pay.plan_id
	};
});
//#endregion
export { confirmSandboxPayment_createServerFn_handler, listPlans_createServerFn_handler, startCheckout_createServerFn_handler };
