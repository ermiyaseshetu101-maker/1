import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as cn } from "./utils-zqpJ-D4Z.mjs";
import { i as hasFeature } from "./types-CYB28pJW.mjs";
import { g as ChefHat } from "../_libs/lucide-react.mjs";
import { _ as statusLabel, a as useTenant, b as usePOSStore, m as localizedName, v as t } from "./router-DdtrxyM9.mjs";
import { t as Badge } from "./badge-BAjpSyJ1.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { t as elapsedMinutes } from "./format-CSAY-VyI.mjs";
import { o as UpgradeCard } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kds-CZxmEyk7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLS = [
	{
		status: "new",
		tone: "info"
	},
	{
		status: "preparing",
		tone: "warning"
	},
	{
		status: "ready",
		tone: "success"
	}
];
function useNow() {
	const [now, setNow] = (0, import_react.useState)(Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 15e3);
		return () => window.clearInterval(id);
	}, []);
	return now;
}
function KdsScreen() {
	const language = usePOSStore((s) => s.language);
	const orders = usePOSStore((s) => s.orders);
	const advanceOrder = usePOSStore((s) => s.advanceOrder);
	const now = useNow();
	const live = orders.filter((o) => o.status !== "completed");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 border-b border-border px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-semibold tracking-tight",
					children: t(language, "kitchenDisplay")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "accent",
					children: t(language, "live")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-auto text-sm text-muted tabular-nums",
					children: live.length
				})
			]
		}), live.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-10 text-subtle" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: t(language, "emptyKitchen")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted",
					children: t(language, "emptyKitchenHint")
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-0 flex-1 gap-3 overflow-auto p-3 md:grid-cols-3",
			children: COLS.map((col) => {
				const tickets = live.filter((o) => o.status === col.status);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-64 flex-col rounded-3xl bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: statusLabel(language, col.status)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: col.tone,
							children: tickets.length
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2",
						children: tickets.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 py-8 text-center text-xs text-subtle",
							children: t(language, "noTickets")
						}) : tickets.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, {
							order,
							now,
							onBump: () => advanceOrder(order.id)
						}, order.id))
					})]
				}, col.status);
			})
		})]
	});
}
function Ticket({ order, now, onBump }) {
	const language = usePOSStore((s) => s.language);
	const mins = elapsedMinutes(order.createdAt, now);
	const action = order.status === "new" ? t(language, "startCook") : order.status === "preparing" ? t(language, "markReady") : t(language, "complete");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("rounded-2xl bg-elevated p-3 shadow-[var(--shadow-border)]", mins >= 15 && order.status !== "ready" && "ring-1 ring-danger/50"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-lg font-semibold tabular-nums",
					children: ["#", order.number]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: cn("text-xs tabular-nums", mins >= 15 ? "text-danger" : "text-muted"),
					children: [mins, t(language, "min")]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-2 text-xs text-muted",
				children: [
					order.tableLabel ?? t(language, "takeaway"),
					" · ",
					order.staffName
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-3 space-y-1",
				children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "flex justify-between gap-2 text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 truncate",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 inline-block w-5 font-semibold tabular-nums",
							children: item.qty
						}), localizedName(language, item)]
					})
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				className: "w-full",
				variant: order.status === "ready" ? "success" : "primary",
				onClick: onBump,
				children: action
			})
		]
	});
}
function KdsRoute() {
	const { bootstrap } = useTenant();
	const language = usePOSStore((s) => s.language);
	if (!hasFeature(bootstrap?.entitlements, "kds")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradeCard, { message: t(language, "featureLocked") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KdsScreen, {});
}
//#endregion
export { KdsRoute as component };
