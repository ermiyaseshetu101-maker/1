import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn } from "./router-CAWKn_qj.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/i18n-BC5Nz44z.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,color,opacity,box-shadow] duration-150 ease-out select-none disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-fg text-bg shadow-[var(--shadow-border)] hover:opacity-90",
			accent: "bg-accent text-accent-fg hover:opacity-90",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			danger: "bg-danger text-bg hover:opacity-90",
			success: "bg-success text-bg hover:opacity-90",
			muted: "bg-elevated text-fg hover:bg-elevated/80"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-lg px-4 text-sm",
			lg: "h-12 rounded-xl px-5 text-base",
			xl: "h-16 rounded-xl px-6 text-base",
			icon: "size-11 rounded-lg",
			keypad: "h-[4.25rem] rounded-xl text-2xl font-semibold"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		type: asChild ? void 0 : type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var dict = {
	appName: {
		en: "simplePOS",
		am: "ሲምፕል ፒኦኤስ"
	},
	tagline: {
		en: "Addis service terminal",
		am: "የአዲስ አገልግሎት ተርሚናል"
	},
	enterPin: {
		en: "Enter staff PIN",
		am: "የሰራተኛ ፒን ያስገቡ"
	},
	incorrectPin: {
		en: "Incorrect PIN",
		am: "የተሳሳተ ፒን"
	},
	demoAccounts: {
		en: "Demo PINs",
		am: "የሙከራ ፒን"
	},
	clear: {
		en: "Clear",
		am: "አጽዳ"
	},
	navPos: {
		en: "POS",
		am: "ሽያጭ"
	},
	navTables: {
		en: "Tables",
		am: "ጠረጴዛ"
	},
	navKds: {
		en: "Kitchen",
		am: "ኩሽና"
	},
	navAdmin: {
		en: "Admin",
		am: "አስተዳደር"
	},
	logout: {
		en: "Sign out",
		am: "ውጣ"
	},
	language: {
		en: "Language",
		am: "ቋንቋ"
	},
	english: {
		en: "English",
		am: "እንግሊዘኛ"
	},
	amharic: {
		en: "Amharic",
		am: "አማርኛ"
	},
	theme: {
		en: "Theme",
		am: "ገጽታ"
	},
	dark: {
		en: "Dark",
		am: "ጨለማ"
	},
	light: {
		en: "Light",
		am: "ብርሃን"
	},
	searchMenu: {
		en: "Search menu",
		am: "ምናሌ ፈልግ"
	},
	all: {
		en: "All",
		am: "ሁሉም"
	},
	cart: {
		en: "Ticket",
		am: "ትዕዛዝ"
	},
	emptyCart: {
		en: "No items yet",
		am: "ምንም አልተጨመረም"
	},
	emptyCartHint: {
		en: "Tap a dish to add it to this ticket.",
		am: "ምግብ በመንካት ወደ ትዕዛዙ ይጨምሩ።"
	},
	qty: {
		en: "Qty",
		am: "ብዛት"
	},
	subtotal: {
		en: "Subtotal",
		am: "ንዑስ ድምር"
	},
	vat: {
		en: "VAT 15%",
		am: "ተ.እ.ታ 15%"
	},
	total: {
		en: "Total",
		am: "ጠቅላላ"
	},
	pay: {
		en: "Take payment",
		am: "ክፈል"
	},
	sendKitchen: {
		en: "Send to kitchen",
		am: "ወደ ኩሽና ላክ"
	},
	holdTable: {
		en: "Table",
		am: "ጠረጴዛ"
	},
	takeaway: {
		en: "Takeaway",
		am: "ቶንኮ"
	},
	dineIn: {
		en: "Dine in",
		am: "በቦታው"
	},
	noTable: {
		en: "No table",
		am: "ጠረጴዛ የለም"
	},
	checkout: {
		en: "Checkout",
		am: "ክፍያ"
	},
	paymentMethod: {
		en: "Payment method",
		am: "የክፍያ መንገድ"
	},
	cash: {
		en: "Cash",
		am: "ጥሬ ገንዘብ"
	},
	card: {
		en: "Card",
		am: "ካርድ"
	},
	telebirr: {
		en: "Telebirr",
		am: "ቴሌብር"
	},
	tendered: {
		en: "Amount received",
		am: "የተቀበለው"
	},
	change: {
		en: "Change",
		am: "ቅሪት"
	},
	confirmPay: {
		en: "Confirm payment",
		am: "ክፍያ አረጋግጥ"
	},
	cancel: {
		en: "Cancel",
		am: "ሰርዝ"
	},
	paid: {
		en: "Paid",
		am: "ተከፍሏል"
	},
	unpaid: {
		en: "Unpaid",
		am: "ያልተከፈለ"
	},
	newOrder: {
		en: "New ticket",
		am: "አዲስ ትዕዛዝ"
	},
	orderSent: {
		en: "Sent to kitchen",
		am: "ወደ ኩሽና ተልኳል"
	},
	paymentOk: {
		en: "Payment recorded",
		am: "ክፍያ ተመዝግቧል"
	},
	unavailable: {
		en: "Unavailable",
		am: "አይገኝም"
	},
	floor: {
		en: "Floor plan",
		am: "የአዳራሽ ንድፍ"
	},
	seats: {
		en: "seats",
		am: "ወንበር"
	},
	available: {
		en: "Open",
		am: "ክፍት"
	},
	occupied: {
		en: "Seated",
		am: "ተይዟል"
	},
	reserved: {
		en: "Reserved",
		am: "ተያይዟል"
	},
	openTable: {
		en: "Open table",
		am: "ጠረጴዛ ክፈት"
	},
	closeTable: {
		en: "Close table",
		am: "ጠረጴዛ ዝጋ"
	},
	viewOrder: {
		en: "View ticket",
		am: "ትዕዛዝ ይመልከቱ"
	},
	kitchenDisplay: {
		en: "Kitchen display",
		am: "የኩሽና ማሳያ"
	},
	noTickets: {
		en: "No tickets in this column",
		am: "በዚህ ዓምድ ትዕዛዝ የለም"
	},
	bump: {
		en: "Bump",
		am: "አስቀጥል"
	},
	startCook: {
		en: "Start",
		am: "ጀምር"
	},
	markReady: {
		en: "Ready",
		am: "ዝግጁ"
	},
	complete: {
		en: "Complete",
		am: "ጨርስ"
	},
	statusNew: {
		en: "New",
		am: "አዲስ"
	},
	statusPreparing: {
		en: "Preparing",
		am: "በዝግጅት"
	},
	statusReady: {
		en: "Ready",
		am: "ዝግጁ"
	},
	statusCompleted: {
		en: "Completed",
		am: "ተጠናቋል"
	},
	dashboard: {
		en: "Dashboard",
		am: "ዳሽቦርድ"
	},
	todaySales: {
		en: "Today’s sales",
		am: "የዛሬ ሽያጭ"
	},
	todayOrders: {
		en: "Orders today",
		am: "የዛሬ ትዕዛዞች"
	},
	avgTicket: {
		en: "Average ticket",
		am: "አማካይ ትዕዛዝ"
	},
	openTables: {
		en: "Open tables",
		am: "ክፍት ጠረጴዛዎች"
	},
	last7: {
		en: "Last 7 days",
		am: "ባለፉት 7 ቀናት"
	},
	menuAvailability: {
		en: "Menu availability",
		am: "የምናሌ ዝግጁነት"
	},
	staff: {
		en: "Staff",
		am: "ሰራተኞች"
	},
	recentOrders: {
		en: "Recent tickets",
		am: "የቅርብ ትዕዛዞች"
	},
	resetDemo: {
		en: "Reset demo data",
		am: "ሙከራውን ዳግም አስጀምር"
	},
	resetOk: {
		en: "Demo data restored",
		am: "ሙከራው ተመልሷል"
	},
	roleAdmin: {
		en: "Admin",
		am: "አስተዳዳሪ"
	},
	roleManager: {
		en: "Manager",
		am: "ሥራ አስኪያጅ"
	},
	roleCashier: {
		en: "Cashier",
		am: "ገንዘብ ተቀባይ"
	},
	roleWaiter: {
		en: "Waiter",
		am: "አስተናጋጅ"
	},
	order: {
		en: "Order",
		am: "ትዕዛዝ"
	},
	items: {
		en: "items",
		am: "ዓይነት"
	},
	ago: {
		en: "ago",
		am: "በፊት"
	},
	min: {
		en: "m",
		am: "ደ"
	},
	accessDenied: {
		en: "You do not have access to this screen.",
		am: "ይህን ማያ መጠቀም አይችሉም።"
	},
	backToPos: {
		en: "Back to POS",
		am: "ወደ ሽያጭ ተመለስ"
	},
	signedInAs: {
		en: "Signed in",
		am: "ገብተዋል"
	},
	add: {
		en: "Add",
		am: "ጨምር"
	},
	remove: {
		en: "Remove",
		am: "አስወግድ"
	},
	close: {
		en: "Close",
		am: "ዝጋ"
	},
	insufficient: {
		en: "Amount is less than the total",
		am: "መጠኑ ከጠቅላላው ያነሰ ነው"
	},
	ticketN: {
		en: "Ticket",
		am: "ትዕዛዝ"
	},
	live: {
		en: "Live",
		am: "ቀጥታ"
	},
	sales: {
		en: "Sales",
		am: "ሽያጭ"
	},
	on: {
		en: "On",
		am: "ክፍት"
	},
	off: {
		en: "Off",
		am: "ዝግ"
	},
	emptyKitchen: {
		en: "Kitchen is clear",
		am: "ኩሽናው ባዶ ነው"
	},
	emptyKitchenHint: {
		en: "New tickets will appear here as soon as they are sent.",
		am: "አዲስ ትዕዛዞች ሲላኩ እዚህ ይታያሉ።"
	},
	pickTable: {
		en: "Assign table",
		am: "ጠረጴዛ ምረጥ"
	},
	needItems: {
		en: "Add items first",
		am: "መጀመሪያ ምግብ ይጨምሩ"
	},
	sendNeedTable: {
		en: "Assign a table or take payment for takeaway.",
		am: "ጠረጴዛ ይምረጡ ወይም ለቶንኮ ይክፈሉ።"
	},
	tableClosed: {
		en: "Table closed",
		am: "ጠረጴዛ ተዘግቷል"
	},
	mustPay: {
		en: "Collect payment before closing.",
		am: "ከመዝጋት በፊት ክፍያ ይሰብስቡ።"
	}
};
function t(lang, key) {
	return dict[key][lang];
}
function roleLabel(lang, role) {
	return t(lang, {
		admin: "roleAdmin",
		manager: "roleManager",
		cashier: "roleCashier",
		waiter: "roleWaiter"
	}[role]);
}
function statusLabel(lang, status) {
	return t(lang, {
		new: "statusNew",
		preparing: "statusPreparing",
		ready: "statusReady",
		completed: "statusCompleted"
	}[status]);
}
function tableStatusLabel(lang, status) {
	return t(lang, {
		available: "available",
		occupied: "occupied",
		reserved: "reserved"
	}[status]);
}
function paymentLabel(lang, method) {
	return t(lang, method);
}
function localizedName(lang, item) {
	return lang === "am" ? item.nameAm : item.name;
}
//#endregion
export { statusLabel as a, roleLabel as i, localizedName as n, t as o, paymentLabel as r, tableStatusLabel as s, Button as t };
