import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn } from "./router-CAWKn_qj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-LHQ-Xxf1.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { tone: {
		default: "bg-elevated text-muted",
		accent: "bg-accent/15 text-accent",
		success: "bg-success/15 text-success",
		warning: "bg-warning/15 text-warning",
		danger: "bg-danger/15 text-danger",
		info: "bg-info/15 text-info",
		solid: "bg-fg text-bg"
	} },
	defaultVariants: { tone: "default" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
function formatETB(amount, lang) {
	const n = new Intl.NumberFormat("en-US", {
		minimumFractionDigits: 0,
		maximumFractionDigits: 0
	}).format(Math.round(amount));
	return lang === "am" ? `${n} ብር` : `Br ${n}`;
}
function formatClock(ts, lang) {
	return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).format(new Date(ts));
}
function formatDate(ts, lang) {
	return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
		weekday: "short",
		month: "short",
		day: "numeric"
	}).format(new Date(ts));
}
function elapsedMinutes(from, now) {
	return Math.max(0, Math.floor((now - from) / 6e4));
}
function startOfDay(ts = Date.now()) {
	const d = new Date(ts);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
//#endregion
export { formatETB as a, formatDate as i, elapsedMinutes as n, startOfDay as o, formatClock as r, Badge as t };
