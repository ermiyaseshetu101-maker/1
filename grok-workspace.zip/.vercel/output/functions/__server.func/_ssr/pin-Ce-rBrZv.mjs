import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useNavigate, S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as cn } from "./utils-zqpJ-D4Z.mjs";
import { m as Delete } from "../_libs/lucide-react.mjs";
import { a as useTenant, b as usePOSStore, g as roleLabel, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as RedirectToSignIn, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pin-Ce-rBrZv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYS = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"C",
	"0",
	"⌫"
];
function PinLogin() {
	const language = usePOSStore((s) => s.language);
	const theme = usePOSStore((s) => s.theme);
	const staff = usePOSStore((s) => s.staff);
	const setLanguage = usePOSStore((s) => s.setLanguage);
	const setTheme = usePOSStore((s) => s.setTheme);
	const login = usePOSStore((s) => s.login);
	const { bootstrap } = useTenant();
	const navigate = useNavigate();
	const [pin, setPin] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(false);
	const demoStaff = staff.filter((s) => [
		"1234",
		"2222",
		"1111",
		"0000"
	].includes(s.pin));
	function submit(next) {
		const member = login(next);
		if (!member) {
			setError(true);
			window.setTimeout(() => {
				setError(false);
				setPin("");
			}, 420);
			return;
		}
		const dest = member.role === "waiter" ? "/tables" : member.role === "kitchen" ? "/kds" : member.role === "admin" || member.role === "manager" ? "/admin" : "/pos";
		navigate({ to: dest });
	}
	function press(key) {
		if (error) return;
		if (key === "C") {
			setPin("");
			return;
		}
		if (key === "⌫") {
			setPin((p) => p.slice(0, -1));
			return;
		}
		const next = (pin + key).slice(0, 4);
		setPin(next);
		if (next.length === 4) submit(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-end gap-2 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => setLanguage(language === "en" ? "am" : "en"),
				children: language === "en" ? "አማርኛ" : "English"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
				children: t(language, theme === "dark" ? "light" : "dark")
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "enter-up mb-8 flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-5 flex size-14 items-center justify-center rounded-2xl bg-fg text-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl font-semibold tracking-tight",
								children: "sP"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-semibold tracking-tight",
							children: bootstrap?.restaurant?.name ?? t(language, "appName")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: t(language, "enterPin")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mb-6 flex justify-center gap-3", error && "pin-shake"),
					children: [
						0,
						1,
						2,
						3
					].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-3.5 rounded-full transition-colors duration-150", pin.length > i ? "bg-fg" : "bg-elevated shadow-[var(--shadow-border)]", error && "bg-danger") }, i))
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-center text-sm text-danger",
					children: t(language, "incorrectPin")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mb-4 h-5" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: key === "C" ? "muted" : "outline",
						size: "keypad",
						className: "min-h-16",
						onClick: () => press(key),
						"aria-label": key === "⌫" ? "Backspace" : key === "C" ? t(language, "clear") : key,
						children: key === "⌫" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "size-6" }) : key === "C" ? t(language, "clear") : key
					}, key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs font-medium tracking-wide text-muted uppercase",
						children: t(language, "demoAccounts")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid grid-cols-2 gap-2",
						children: demoStaff.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-xl bg-elevated px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: roleLabel(language, s.role)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-sm tabular-nums",
								children: s.pin
							})]
						}, s.id))
					})]
				})
			]
		})]
	});
}
function PinPage() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const session = usePOSStore((s) => s.session);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!bootstrap?.profile.emailVerified) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/verify" });
	if (!bootstrap.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
	if (bootstrap.restaurant.status === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pending" });
	if (bootstrap.restaurant.status === "suspended" || bootstrap.restaurant.status === "rejected") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pending" });
	if (bootstrap.entitlements?.billingLocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/plans" });
	if (session) {
		const dest = session.role === "waiter" ? "/tables" : session.role === "kitchen" ? "/kds" : session.role === "admin" || session.role === "manager" ? "/admin" : "/pos";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: dest });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinLogin, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute top-3 left-4 flex gap-3 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/plans",
				className: "text-muted hover:text-fg",
				children: "Plans"
			}), bootstrap.profile.platformRole === "super_admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/platform",
				className: "text-muted hover:text-fg",
				children: "Platform"
			}) : null]
		})]
	});
}
//#endregion
export { PinPage as component };
