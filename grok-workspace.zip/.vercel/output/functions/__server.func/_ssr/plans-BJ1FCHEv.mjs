import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useNavigate, S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Check, d as Minus } from "../_libs/lucide-react.mjs";
import { a as useTenant, b as usePOSStore, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Badge } from "./badge-BAjpSyJ1.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as formatETB } from "./format-CSAY-VyI.mjs";
import { i as RedirectToSignIn, n as OwnerShell, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
import { n as listPlans } from "./billing-DSMgAFJJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plans-BJ1FCHEv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlansPage() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const language = usePOSStore((s) => s.language);
	const [plans, setPlans] = (0, import_react.useState)([]);
	const [loadError, setLoadError] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!user) return;
		listPlans().then(setPlans).catch((e) => setLoadError(e instanceof Error ? e.message : "Failed to load plans"));
	}, [user]);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!bootstrap?.profile.emailVerified) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/verify" });
	if (!bootstrap.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
	const currentId = bootstrap.entitlements?.planId;
	const locked = bootstrap.entitlements?.billingLocked;
	const days = bootstrap.entitlements?.trialDaysLeft ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OwnerShell, {
		title: t(language, "plansTitle"),
		subtitle: locked ? t(language, "trialExpired") : days > 0 && bootstrap.entitlements?.subscriptionStatus === "trialing" ? `${days} ${t(language, "trialBanner")}` : bootstrap.entitlements?.planName,
		children: [
			locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 rounded-2xl bg-warning/15 px-4 py-3 text-sm text-fg",
				children: t(language, "trialExpired")
			}) : null,
			loadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-danger",
				children: loadError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: plans.map((plan) => {
					const current = plan.id === currentId && !locked;
					const isTrial = plan.slug === "trial";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex flex-col rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-semibold tracking-tight",
									children: plan.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: plan.description
								})] }), current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "success",
									children: t(language, "currentPlan")
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-3xl font-semibold tracking-tight tabular-nums",
								children: [plan.priceEtb === 0 ? "0" : formatETB(plan.priceEtb, language), plan.interval === "month" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-normal text-muted",
									children: t(language, "month")
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-5 flex-1 space-y-2",
								children: plan.features.map((f) => {
									const limitText = f.limit === -1 ? t(language, "unlimited") : f.limit != null ? String(f.limit) : null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2 text-sm",
										children: [f.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "mt-0.5 size-4 shrink-0 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: f.enabled ? "text-fg" : "text-muted",
											children: [f.name, limitText ? ` · ${limitText}` : ""]
										})]
									}, f.key);
								})
							}),
							isTrial || current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								className: "mt-6",
								disabled: true,
								children: t(language, "currentPlan")
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-6",
								onClick: () => navigate({
									to: "/checkout/$planId",
									params: { planId: plan.id }
								}),
								children: t(language, "choosePlan")
							})
						]
					}, plan.id);
				})
			}),
			bootstrap.restaurant.status === "active" && !locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pin",
					className: "text-muted underline-offset-4 hover:text-fg hover:underline",
					children: t(language, "backToFloor")
				})
			}) : null
		]
	});
}
//#endregion
export { PlansPage as component };
