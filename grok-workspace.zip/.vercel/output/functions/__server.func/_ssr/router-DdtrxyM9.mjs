import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, p as HeadContent, v as lazyRouteComponent, w as useRouter, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { a as authMiddleware, d as uid, i as TABLES, n as PRODUCTS, r as STAFF, t as CATEGORIES, u as seedOrders } from "./utils-zqpJ-D4Z.mjs";
import { r as cartTotals } from "./types-CYB28pJW.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { Ft as string, It as union, Mt as object, jt as number, kt as literal, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { n as auth } from "./server-Bf62GwQt.mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/i18n-C8Ly-vER.js
var noopStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function getStorage() {
	if (typeof window === "undefined") return noopStorage;
	return window.localStorage;
}
function emptyCart() {
	return {
		items: [],
		discount: 0
	};
}
function freshState() {
	return {
		seedVersion: 2,
		language: "en",
		theme: "dark",
		session: null,
		staff: STAFF.map((s) => ({ ...s })),
		categories: CATEGORIES.map((c) => ({ ...c })),
		products: PRODUCTS.map((p) => ({ ...p })),
		tables: TABLES.map((t) => ({ ...t })),
		orders: seedOrders(),
		nextOrderNumber: 107,
		cart: emptyCart()
	};
}
function upsertLine(items, product) {
	if (items.find((i) => i.productId === product.id)) return items.map((i) => i.productId === product.id ? {
		...i,
		qty: i.qty + 1
	} : i);
	return [...items, {
		id: uid("li"),
		productId: product.id,
		name: product.name,
		nameAm: product.nameAm,
		price: product.price,
		qty: 1
	}];
}
var usePOSStore = create()(persist((set, get) => ({
	...freshState(),
	setLanguage: (language) => set({ language }),
	setTheme: (theme) => set({ theme }),
	login: (pin) => {
		const staff = get().staff.find((s) => s.pin === pin && s.active !== false) ?? null;
		if (staff) set({ session: staff });
		return staff;
	},
	logout: () => set({
		session: null,
		cart: emptyCart()
	}),
	addToCart: (product) => {
		if (!product.available) return;
		set((s) => ({ cart: {
			...s.cart,
			items: upsertLine(s.cart.items, product)
		} }));
	},
	setQty: (lineId, qty) => {
		set((s) => ({ cart: {
			...s.cart,
			items: qty <= 0 ? s.cart.items.filter((i) => i.id !== lineId) : s.cart.items.map((i) => i.id === lineId ? {
				...i,
				qty
			} : i)
		} }));
	},
	setDiscount: (discount) => {
		set((s) => ({ cart: {
			...s.cart,
			discount: Math.max(0, discount)
		} }));
	},
	clearCart: () => set({ cart: emptyCart() }),
	assignTable: (tableId) => {
		set((s) => ({ cart: {
			...s.cart,
			tableId
		} }));
	},
	loadOrderIntoCart: (orderId) => {
		const order = get().orders.find((o) => o.id === orderId);
		if (!order || order.status === "completed") return;
		set({ cart: {
			tableId: order.tableId,
			discount: order.discount ?? 0,
			items: order.items.map((i) => ({
				...i,
				id: uid("li")
			}))
		} });
	},
	sendToKitchen: () => {
		const { cart, session, tables, orders, nextOrderNumber } = get();
		if (!session || cart.items.length === 0) return null;
		const table = tables.find((t) => t.id === cart.tableId);
		if (!table) return null;
		const existing = table.orderId ? orders.find((o) => o.id === table.orderId) : void 0;
		const now = Date.now();
		if (existing && existing.status !== "completed") {
			const merged = {
				...existing,
				items: cart.items.map((i) => ({ ...i })),
				discount: cart.discount,
				updatedAt: now,
				status: existing.status === "ready" ? "preparing" : existing.status
			};
			set({ orders: orders.map((o) => o.id === existing.id ? merged : o) });
			return merged;
		}
		const order = {
			id: uid("o"),
			number: nextOrderNumber,
			tableId: table.id,
			tableLabel: table.label,
			staffId: session.id,
			staffName: session.name,
			items: cart.items.map((i) => ({ ...i })),
			status: "new",
			paid: false,
			discount: cart.discount,
			createdAt: now,
			updatedAt: now,
			type: "dine-in"
		};
		set({
			orders: [order, ...orders],
			nextOrderNumber: nextOrderNumber + 1,
			tables: tables.map((t) => t.id === table.id ? {
				...t,
				status: "occupied",
				orderId: order.id
			} : t)
		});
		return order;
	},
	checkout: (method, tendered) => {
		const { cart, session, tables, orders, nextOrderNumber } = get();
		if (!session || cart.items.length === 0) return null;
		const { total } = cartTotals(cart.items, cart.discount);
		if (method === "cash" && tendered !== void 0 && tendered < total) return null;
		const table = tables.find((t) => t.id === cart.tableId);
		const now = Date.now();
		const existing = table?.orderId ? orders.find((o) => o.id === table.orderId && o.status !== "completed") : void 0;
		if (existing) {
			const updated = {
				...existing,
				items: cart.items.map((i) => ({ ...i })),
				paid: true,
				paymentMethod: method,
				tendered,
				discount: cart.discount,
				updatedAt: now
			};
			set({
				orders: orders.map((o) => o.id === existing.id ? updated : o),
				cart: emptyCart()
			});
			return updated;
		}
		const order = {
			id: uid("o"),
			number: nextOrderNumber,
			tableId: table?.id,
			tableLabel: table?.label,
			staffId: session.id,
			staffName: session.name,
			items: cart.items.map((i) => ({ ...i })),
			status: "new",
			paid: true,
			paymentMethod: method,
			tendered,
			discount: cart.discount,
			createdAt: now,
			updatedAt: now,
			type: table ? "dine-in" : "takeaway"
		};
		set({
			orders: [order, ...orders],
			nextOrderNumber: nextOrderNumber + 1,
			tables: table ? tables.map((t) => t.id === table.id ? {
				...t,
				status: "occupied",
				orderId: order.id
			} : t) : tables,
			cart: emptyCart()
		});
		return order;
	},
	advanceOrder: (orderId) => {
		const next = {
			new: "preparing",
			preparing: "ready",
			ready: "completed",
			completed: "completed"
		};
		set((s) => ({ orders: s.orders.map((o) => {
			if (o.id !== orderId) return o;
			return {
				...o,
				status: next[o.status],
				updatedAt: Date.now()
			};
		}) }));
	},
	completeOrder: (orderId) => {
		set((s) => ({
			orders: s.orders.map((o) => o.id === orderId ? {
				...o,
				status: "completed",
				updatedAt: Date.now()
			} : o),
			tables: s.tables.map((t) => t.orderId === orderId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t)
		}));
	},
	closeTable: (tableId) => {
		const { tables, orders, cart } = get();
		const table = tables.find((t) => t.id === tableId);
		if (!table?.orderId) {
			set({ tables: tables.map((t) => t.id === tableId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t) });
			return true;
		}
		const order = orders.find((o) => o.id === table.orderId);
		if (order && !order.paid) return false;
		set({
			orders: order ? orders.map((o) => o.id === order.id ? {
				...o,
				status: "completed",
				updatedAt: Date.now()
			} : o) : orders,
			tables: tables.map((t) => t.id === tableId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t),
			cart: cart.tableId === tableId ? emptyCart() : cart
		});
		return true;
	},
	openTable: (tableId) => {
		const table = get().tables.find((t) => t.id === tableId);
		if (!table || table.status === "reserved") return;
		if (table.orderId) {
			get().loadOrderIntoCart(table.orderId);
			return;
		}
		set({ cart: {
			tableId,
			items: [],
			discount: 0
		} });
	},
	toggleProduct: (productId) => {
		set((s) => ({ products: s.products.map((p) => p.id === productId ? {
			...p,
			available: !p.available
		} : p) }));
	},
	hydrateCatalog: (data) => {
		set({
			staff: data.staff.length ? data.staff : get().staff,
			categories: data.categories.length ? data.categories : get().categories,
			products: data.products.length ? data.products : get().products,
			tables: data.tables.length ? data.tables : get().tables
		});
	},
	resetDemo: () => {
		const { language, theme, session, staff } = get();
		set({
			...freshState(),
			language,
			theme,
			session,
			staff
		});
	}
}), {
	name: "simplepos-v2",
	storage: createJSONStorage(getStorage),
	skipHydration: true,
	partialize: (s) => ({
		seedVersion: s.seedVersion,
		language: s.language,
		theme: s.theme,
		session: s.session,
		staff: s.staff,
		categories: s.categories,
		products: s.products,
		tables: s.tables,
		orders: s.orders,
		nextOrderNumber: s.nextOrderNumber,
		cart: s.cart
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		if (p.seedVersion !== 2) return {
			...current,
			language: p.language ?? current.language,
			theme: p.theme ?? current.theme
		};
		return {
			...current,
			...p,
			cart: p.cart ? {
				items: p.cart.items ?? [],
				discount: p.cart.discount ?? 0
			} : current.cart
		};
	}
}));
var dict = {
	appName: {
		en: "simplePOS",
		am: "ሲምፕል ፒኦኤስ"
	},
	tagline: {
		en: "Addis service terminal",
		am: "የአዲስ አገልግሎት ተርሚናል"
	},
	enterPin: {
		en: "Enter staff PIN",
		am: "የሰራተኛ ፒን ያስገቡ"
	},
	incorrectPin: {
		en: "Incorrect PIN",
		am: "የተሳሳተ ፒን"
	},
	demoAccounts: {
		en: "Demo PINs",
		am: "የሙከራ ፒን"
	},
	clear: {
		en: "Clear",
		am: "አጽዳ"
	},
	navPos: {
		en: "POS",
		am: "ሽያጭ"
	},
	navTables: {
		en: "Tables",
		am: "ጠረጴዛ"
	},
	navKds: {
		en: "Kitchen",
		am: "ኩሽና"
	},
	navAdmin: {
		en: "Admin",
		am: "አስተዳደር"
	},
	logout: {
		en: "Sign out",
		am: "ውጣ"
	},
	language: {
		en: "Language",
		am: "ቋንቋ"
	},
	english: {
		en: "English",
		am: "እንግሊዘኛ"
	},
	amharic: {
		en: "Amharic",
		am: "አማርኛ"
	},
	theme: {
		en: "Theme",
		am: "ገጽታ"
	},
	dark: {
		en: "Dark",
		am: "ጨለማ"
	},
	light: {
		en: "Light",
		am: "ብርሃን"
	},
	searchMenu: {
		en: "Search menu",
		am: "ምናሌ ፈልግ"
	},
	all: {
		en: "All",
		am: "ሁሉም"
	},
	cart: {
		en: "Ticket",
		am: "ትዕዛዝ"
	},
	emptyCart: {
		en: "No items yet",
		am: "ምንም አልተጨመረም"
	},
	emptyCartHint: {
		en: "Tap a dish to add it to this ticket.",
		am: "ምግብ በመንካት ወደ ትዕዛዙ ይጨምሩ።"
	},
	qty: {
		en: "Qty",
		am: "ብዛት"
	},
	subtotal: {
		en: "Subtotal",
		am: "ንዑስ ድምር"
	},
	vat: {
		en: "VAT 15%",
		am: "ተ.እ.ታ 15%"
	},
	total: {
		en: "Total",
		am: "ጠቅላላ"
	},
	pay: {
		en: "Take payment",
		am: "ክፈል"
	},
	sendKitchen: {
		en: "Send to kitchen",
		am: "ወደ ኩሽና ላክ"
	},
	holdTable: {
		en: "Table",
		am: "ጠረጴዛ"
	},
	takeaway: {
		en: "Takeaway",
		am: "ቶንኮ"
	},
	dineIn: {
		en: "Dine in",
		am: "በቦታው"
	},
	noTable: {
		en: "No table",
		am: "ጠረጴዛ የለም"
	},
	checkout: {
		en: "Checkout",
		am: "ክፍያ"
	},
	paymentMethod: {
		en: "Payment method",
		am: "የክፍያ መንገድ"
	},
	cash: {
		en: "Cash",
		am: "ጥሬ ገንዘብ"
	},
	card: {
		en: "Card",
		am: "ካርድ"
	},
	telebirr: {
		en: "Telebirr",
		am: "ቴሌብር"
	},
	tendered: {
		en: "Amount received",
		am: "የተቀበለው"
	},
	change: {
		en: "Change",
		am: "ቅሪት"
	},
	confirmPay: {
		en: "Confirm payment",
		am: "ክፍያ አረጋግጥ"
	},
	cancel: {
		en: "Cancel",
		am: "ሰርዝ"
	},
	paid: {
		en: "Paid",
		am: "ተከፍሏል"
	},
	unpaid: {
		en: "Unpaid",
		am: "ያልተከፈለ"
	},
	newOrder: {
		en: "New ticket",
		am: "አዲስ ትዕዛዝ"
	},
	orderSent: {
		en: "Sent to kitchen",
		am: "ወደ ኩሽና ተልኳል"
	},
	paymentOk: {
		en: "Payment recorded",
		am: "ክፍያ ተመዝግቧል"
	},
	unavailable: {
		en: "Unavailable",
		am: "አይገኝም"
	},
	floor: {
		en: "Floor plan",
		am: "የአዳራሽ ንድፍ"
	},
	seats: {
		en: "seats",
		am: "ወንበር"
	},
	available: {
		en: "Open",
		am: "ክፍት"
	},
	occupied: {
		en: "Seated",
		am: "ተይዟል"
	},
	reserved: {
		en: "Reserved",
		am: "ተያይዟል"
	},
	openTable: {
		en: "Open table",
		am: "ጠረጴዛ ክፈት"
	},
	closeTable: {
		en: "Close table",
		am: "ጠረጴዛ ዝጋ"
	},
	viewOrder: {
		en: "View ticket",
		am: "ትዕዛዝ ይመልከቱ"
	},
	kitchenDisplay: {
		en: "Kitchen display",
		am: "የኩሽና ማሳያ"
	},
	noTickets: {
		en: "No tickets in this column",
		am: "በዚህ ዓምድ ትዕዛዝ የለም"
	},
	bump: {
		en: "Bump",
		am: "አስቀጥል"
	},
	startCook: {
		en: "Start",
		am: "ጀምር"
	},
	markReady: {
		en: "Ready",
		am: "ዝግጁ"
	},
	complete: {
		en: "Complete",
		am: "ጨርስ"
	},
	statusNew: {
		en: "New",
		am: "አዲስ"
	},
	statusPreparing: {
		en: "Preparing",
		am: "በዝግጅት"
	},
	statusReady: {
		en: "Ready",
		am: "ዝግጁ"
	},
	statusCompleted: {
		en: "Completed",
		am: "ተጠናቋል"
	},
	dashboard: {
		en: "Dashboard",
		am: "ዳሽቦርድ"
	},
	todaySales: {
		en: "Today’s sales",
		am: "የዛሬ ሽያጭ"
	},
	todayOrders: {
		en: "Orders today",
		am: "የዛሬ ትዕዛዞች"
	},
	avgTicket: {
		en: "Average ticket",
		am: "አማካይ ትዕዛዝ"
	},
	openTables: {
		en: "Open tables",
		am: "ክፍት ጠረጴዛዎች"
	},
	last7: {
		en: "Last 7 days",
		am: "ባለፉት 7 ቀናት"
	},
	menuAvailability: {
		en: "Menu availability",
		am: "የምናሌ ዝግጁነት"
	},
	staff: {
		en: "Staff",
		am: "ሰራተኞች"
	},
	recentOrders: {
		en: "Recent tickets",
		am: "የቅርብ ትዕዛዞች"
	},
	resetDemo: {
		en: "Reset floor data",
		am: "የአዳራሽ መረጃ ዳግም አስጀምር"
	},
	resetOk: {
		en: "Floor data restored",
		am: "መረጃው ተመልሷል"
	},
	roleAdmin: {
		en: "Admin",
		am: "አስተዳዳሪ"
	},
	roleManager: {
		en: "Manager",
		am: "ሥራ አስኪያጅ"
	},
	roleCashier: {
		en: "Cashier",
		am: "ገንዘብ ተቀባይ"
	},
	roleWaiter: {
		en: "Waiter",
		am: "አስተናጋጅ"
	},
	roleKitchen: {
		en: "Kitchen",
		am: "ኩሽና"
	},
	order: {
		en: "Order",
		am: "ትዕዛዝ"
	},
	items: {
		en: "items",
		am: "ዓይነት"
	},
	ago: {
		en: "ago",
		am: "በፊት"
	},
	min: {
		en: "m",
		am: "ደ"
	},
	accessDenied: {
		en: "You do not have access to this screen.",
		am: "ይህን ማያ መጠቀም አይችሉም።"
	},
	backToPos: {
		en: "Back to POS",
		am: "ወደ ሽያጭ ተመለስ"
	},
	signedInAs: {
		en: "Signed in",
		am: "ገብተዋል"
	},
	add: {
		en: "Add",
		am: "ጨምር"
	},
	remove: {
		en: "Remove",
		am: "አስወግድ"
	},
	close: {
		en: "Close",
		am: "ዝጋ"
	},
	insufficient: {
		en: "Amount is less than the total",
		am: "መጠኑ ከጠቅላላው ያነሰ ነው"
	},
	ticketN: {
		en: "Ticket",
		am: "ትዕዛዝ"
	},
	live: {
		en: "Live",
		am: "ቀጥታ"
	},
	sales: {
		en: "Sales",
		am: "ሽያጭ"
	},
	on: {
		en: "On",
		am: "ክፍት"
	},
	off: {
		en: "Off",
		am: "ዝግ"
	},
	emptyKitchen: {
		en: "Kitchen is clear",
		am: "ኩሽናው ባዶ ነው"
	},
	emptyKitchenHint: {
		en: "New tickets will appear here as soon as they are sent.",
		am: "አዲስ ትዕዛዞች ሲላኩ እዚህ ይታያሉ።"
	},
	pickTable: {
		en: "Assign table",
		am: "ጠረጴዛ ምረጥ"
	},
	needItems: {
		en: "Add items first",
		am: "መጀመሪያ ምግብ ይጨምሩ"
	},
	sendNeedTable: {
		en: "Assign a table or take payment for takeaway.",
		am: "ጠረጴዛ ይምረጡ ወይም ለቶንኮ ይክፈሉ።"
	},
	tableClosed: {
		en: "Table closed",
		am: "ጠረጴዛ ተዘግቷል"
	},
	mustPay: {
		en: "Collect payment before closing.",
		am: "ከመዝጋት በፊት ክፍያ ይሰብስቡ።"
	},
	ownerLogin: {
		en: "Owner sign in",
		am: "የባለቤት መግቢያ"
	},
	ownerRegister: {
		en: "Start free trial",
		am: "ነፃ ሙከራ ጀምር"
	},
	email: {
		en: "Email",
		am: "ኢሜይል"
	},
	password: {
		en: "Password",
		am: "የይለፍ ቃል"
	},
	confirmPassword: {
		en: "Confirm password",
		am: "የይለፍ ቃል አረጋግጥ"
	},
	ownerName: {
		en: "Owner full name",
		am: "የባለቤት ሙሉ ስም"
	},
	restaurantName: {
		en: "Restaurant name",
		am: "የሬስቶራንት ስም"
	},
	createAccount: {
		en: "Create account",
		am: "መለያ ፍጠር"
	},
	haveAccount: {
		en: "Already have an account?",
		am: "መለያ አለዎት?"
	},
	noAccount: {
		en: "New restaurant?",
		am: "አዲስ ሬስቶራንት?"
	},
	verifyTitle: {
		en: "Verify your email",
		am: "ኢሜይልዎን ያረጋግጡ"
	},
	verifyBody: {
		en: "We sent a confirmation to your inbox. For this preview, tap below to verify.",
		am: "ወደ ኢሜይልዎ ማረጋገጫ ልከናል። ለዚህ ቅድመ እይታ ከታች ይጫኑ።"
	},
	verifyNow: {
		en: "Verify email",
		am: "ኢሜይል አረጋግጥ"
	},
	trialBanner: {
		en: "days left in your trial",
		am: "ቀናት በሙከራዎ ቀርተዋል"
	},
	trialExpired: {
		en: "Your trial has ended. Choose a plan to keep selling.",
		am: "የሙከራ ጊዜዎ አልቋል። ለመቀጠል እቅድ ይምረጡ።"
	},
	choosePlan: {
		en: "Choose plan",
		am: "እቅድ ምረጥ"
	},
	currentPlan: {
		en: "Current plan",
		am: "አሁን ያለው እቅድ"
	},
	plansTitle: {
		en: "Payment plans",
		am: "የክፍያ እቅዶች"
	},
	upgrade: {
		en: "Upgrade",
		am: "አሻሽል"
	},
	featureLocked: {
		en: "This feature is on a higher plan.",
		am: "ይህ ባህሪ ከፍ ያለ እቅድ ይፈልጋል።"
	},
	printReceipt: {
		en: "Print receipt",
		am: "ደረሰኝ አትም"
	},
	discount: {
		en: "Discount",
		am: "ቅናሽ"
	},
	addStaff: {
		en: "Add staff",
		am: "ሰራተኛ ጨምር"
	},
	pin: {
		en: "PIN",
		am: "ፒን"
	},
	staffLimit: {
		en: "Staff limit reached for this plan.",
		am: "ለዚህ እቅድ የሰራተኛ ገደብ ደርሷል።"
	},
	advancedReports: {
		en: "Advanced reports",
		am: "የላቀ ሪፖርት"
	},
	platform: {
		en: "Platform",
		am: "መድረክ"
	},
	pendingTitle: {
		en: "Waiting for approval",
		am: "ማጽደቅ በመጠባበቅ"
	},
	pendingBody: {
		en: "Your restaurant is under review. You will get access once it is approved.",
		am: "ሬስቶራንትዎ በግምገማ ላይ ነው። ሲጸድቅ መዳረሻ ያገኛሉ።"
	},
	suspendedTitle: {
		en: "Account suspended",
		am: "መለያ ታግዷል"
	},
	sandboxPay: {
		en: "Sandbox pay",
		am: "የሙከራ ክፍያ"
	},
	payWith: {
		en: "Pay with",
		am: "ይክፈሉ በ"
	},
	backToFloor: {
		en: "Back to floor",
		am: "ወደ አዳራሽ ተመለስ"
	},
	ownerConsole: {
		en: "Owner",
		am: "ባለቤት"
	},
	landingLead: {
		en: "Point of sale for Ethiopian dining rooms — tickets, tables, and kitchen, in English and Amharic.",
		am: "ለኢትዮጵያ ሬስቶራንቶች የሽያጭ ስርዓት — ትዕዛዝ፣ ጠረጴዛ እና ኩሽና፣ በአማርኛ እና በእንግሊዘኛ።"
	},
	daysTrial: {
		en: "45-day free trial",
		am: "የ45 ቀን ነፃ ሙከራ"
	},
	continueGoogle: {
		en: "Continue with Google",
		am: "በጉግል ቀጥል"
	},
	continueX: {
		en: "Continue with X",
		am: "በኤክስ ቀጥል"
	},
	orEmail: {
		en: "or with email",
		am: "ወይም በኢሜይል"
	},
	staffPinHint: {
		en: "Floor staff sign in with a 4-digit PIN after the owner opens a terminal.",
		am: "ባለቤቱ ተርሚናል ከከፈተ በኋላ ሰራተኞች በ4 አሃዝ ፒን ይገባሉ።"
	},
	onboardingTitle: {
		en: "Name your restaurant",
		am: "ሬስቶራንትዎን ይሰይሙ"
	},
	startTrial: {
		en: "Start 45-day trial",
		am: "የ45 ቀን ሙከራ ጀምር"
	},
	unlimited: {
		en: "Unlimited",
		am: "ያልተገደበ"
	},
	included: {
		en: "Included",
		am: "ተካትቷል"
	},
	notIncluded: {
		en: "Not included",
		am: "አልተካተተም"
	},
	month: {
		en: "/ month",
		am: "/ ወር"
	},
	approve: {
		en: "Approve",
		am: "አጽድቅ"
	},
	suspend: {
		en: "Suspend",
		am: "አግድ"
	},
	reject: {
		en: "Reject",
		am: "ውድቅ"
	},
	restaurants: {
		en: "Restaurants",
		am: "ሬስቶራንቶች"
	},
	planFeatures: {
		en: "Plan features",
		am: "የእቅድ ባህሪዎች"
	},
	daysLeft: {
		en: "days left",
		am: "ቀናት ቀርተዋል"
	},
	expireTrial: {
		en: "Expire trial",
		am: "ሙከራ ጨርስ"
	},
	paymentSuccess: {
		en: "Subscription active. Features unlocked.",
		am: "ምዝገባው ንቁ ነው። ባህሪዎች ተከፍተዋል።"
	},
	pinFor: {
		en: "Staff PIN",
		am: "የሰራተኛ ፒን"
	}
};
function t(lang, key) {
	return dict[key][lang];
}
function roleLabel(lang, role) {
	return t(lang, {
		admin: "roleAdmin",
		manager: "roleManager",
		cashier: "roleCashier",
		waiter: "roleWaiter",
		kitchen: "roleKitchen"
	}[role]);
}
function statusLabel(lang, status) {
	return t(lang, {
		new: "statusNew",
		preparing: "statusPreparing",
		ready: "statusReady",
		completed: "statusCompleted"
	}[status]);
}
function tableStatusLabel(lang, status) {
	return t(lang, {
		available: "available",
		occupied: "occupied",
		reserved: "reserved"
	}[status]);
}
function paymentLabel(lang, method) {
	return t(lang, method);
}
function localizedName(lang, item) {
	return lang === "am" ? item.nameAm : item.name;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DdtrxyM9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-12 items-center justify-center rounded-xl bg-fg text-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-lg font-semibold tracking-tight",
					children: "sP"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "simplePOS"
			})]
		})
	});
}
function HydrationGate({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const theme = usePOSStore((s) => s.theme);
	const language = usePOSStore((s) => s.language);
	(0, import_react.useEffect)(() => {
		const persist = usePOSStore.persist;
		if (!persist) {
			setReady(true);
			return;
		}
		const unsub = persist.onFinishHydration(() => setReady(true));
		persist.rehydrate();
		if (persist.hasHydrated()) setReady(true);
		const fallback = window.setTimeout(() => setReady(true), 80);
		return () => {
			unsub?.();
			window.clearTimeout(fallback);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const root = document.documentElement;
		root.classList.toggle("dark", theme === "dark");
		root.classList.toggle("light", theme === "light");
		root.lang = language === "am" ? "am" : "en";
	}, [
		ready,
		theme,
		language
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getBootstrap = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d06f35d7ccfc6bbc1796182b4b4567c7df6ed504ba779ad703619d8555311a43"));
var verifyEmail = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("4c3cf656b45ea22a722dd78ca4c5c42eaf999bb3c1c18187df0ac506fdfcf1f0"));
var markEmailUnverified = createServerFn({ method: "POST" }).validator(object({ displayName: string().trim().min(2).max(80).optional() })).middleware([authMiddleware]).handler(createSsrRpc("e5fb5567a68ae0b71e7fde8e8344e71d29802471e01edbcbe59f6482c72511f8"));
var createRestaurant = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2).max(80),
	language: _enum(["en", "am"]).default("en"),
	ownerName: string().trim().min(2).max(80).optional()
})).middleware([authMiddleware]).handler(createSsrRpc("a9db28c574137613505463582be471112c7014f84b1bd177acc99bbecc0e0c9a"));
var getCatalog = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ae614d38815bcd25a393d3146b9081b90f11cf7e6c1d021d71f848a692b1a989"));
createServerFn({ method: "POST" }).validator(object({ pin: string().length(4) })).middleware([authMiddleware]).handler(createSsrRpc("36bdc0cb13224803adb1c0a57ef707a2459ae94f67bdb3e75a52ad15159c73bb"));
createServerFn({ method: "POST" }).validator(object({ productId: string() })).middleware([authMiddleware]).handler(createSsrRpc("424b8d59ca7128d0e9cce3657721a7558ab35fb3709c6d0a096833d1d1628dcf"));
var addStaff = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2),
	nameAm: string().trim().default(""),
	pin: string().regex(/^\d{4}$/),
	role: _enum([
		"admin",
		"manager",
		"cashier",
		"waiter",
		"kitchen"
	])
})).middleware([authMiddleware]).handler(createSsrRpc("2cbd72bdf49425c6939550e36c44f9d9c5850fe0fdee7a9850616a053abb0f1d"));
createServerFn({ method: "POST" }).validator(object({
	label: string().trim().min(1),
	seats: number().int().min(1).max(20)
})).middleware([authMiddleware]).handler(createSsrRpc("4e0870033f36801be886410e368e894013f79ae2ffb9124ed50cace95233f77b"));
createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2).optional(),
	language: _enum(["en", "am"]).optional(),
	receiptFooter: string().max(200).optional(),
	currency: string().trim().min(3).max(8).optional()
})).middleware([authMiddleware]).handler(createSsrRpc("9f0d30570840a1efb7873da5baff17a81b9f3945c6ecec8a7a68f6eeda19d30f"));
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var TenantContext = (0, import_react.createContext)({
	bootstrap: null,
	loading: true,
	refresh: async () => null
});
function TenantProvider({ children }) {
	const { user, isPending } = useCurrentUserState();
	const [bootstrap, setBootstrap] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const refresh = (0, import_react.useCallback)(async () => {
		if (!user) {
			setBootstrap(null);
			setLoading(false);
			return null;
		}
		try {
			const data = await getBootstrap();
			setBootstrap(data);
			if (data.restaurant) try {
				const catalog = await getCatalog();
				usePOSStore.getState().hydrateCatalog(catalog);
			} catch {}
			return data;
		} catch {
			setBootstrap(null);
			return null;
		} finally {
			setLoading(false);
		}
	}, [user]);
	(0, import_react.useEffect)(() => {
		if (isPending) return;
		setLoading(true);
		refresh();
	}, [isPending, refresh]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TenantContext.Provider, {
		value: {
			bootstrap,
			loading: isPending || loading,
			refresh
		},
		children
	});
}
function useTenant() {
	return (0, import_react.useContext)(TenantContext);
}
var styles_default = "/assets/styles-DzxL4hvZ.css";
var APP_NAME = "simplePOS";
var Route$16 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0c0e"
			},
			{
				name: "description",
				content: "Restaurant point of sale for Ethiopian dining rooms — tickets, tables, and kitchen display."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	const [queryClient] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		retry: 1,
		refetchOnWindowFocus: false
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
					client: queryClient,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TenantProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HydrationGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
						position: "top-center",
						toastOptions: { className: "bg-surface text-fg border-border" }
					})] }) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$14 = () => import("./routes-DP4maRBN.mjs");
var Route$15 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("../_app-BK9UzzB7.mjs");
var Route$14 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./login-BxYZnLAE.mjs");
var Route$13 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
function AuthPage({ children }) {
	const language = usePOSStore((s) => s.language);
	const setLanguage = usePOSStore((s) => s.setLanguage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-8 items-center justify-center rounded-lg bg-fg text-bg text-xs font-semibold",
					children: "sP"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-semibold",
					children: t(language, "appName")
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-xs font-medium text-muted",
				onClick: () => setLanguage(language === "en" ? "am" : "en"),
				children: language === "en" ? "አማርኛ" : "English"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 pb-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]",
				children
			})
		})]
	});
}
var $$splitComponentImporter$11 = () => import("./onboarding-DLlJw-lY.mjs");
var Route$12 = createFileRoute("/onboarding")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./pending-BLxx4spK.mjs");
var Route$11 = createFileRoute("/pending")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./pin-Ce-rBrZv.mjs");
var Route$10 = createFileRoute("/pin")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./plans-BJ1FCHEv.mjs");
var Route$9 = createFileRoute("/plans")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./platform-DvkQ1Tfh.mjs");
var Route$8 = createFileRoute("/platform")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./register-BMfk7W0P.mjs");
var Route$7 = createFileRoute("/register")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var PENDING_KEY = "simplepos.pending-restaurant";
function readPendingRestaurant() {
	try {
		const raw = sessionStorage.getItem(PENDING_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
var $$splitComponentImporter$5 = () => import("./verify-AxSKaumC.mjs");
var Route$6 = createFileRoute("/verify")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin-BXXu--7k.mjs");
var Route$5 = createFileRoute("/_app/admin")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./kds-CZxmEyk7.mjs");
var Route$4 = createFileRoute("/_app/kds")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./pos-DWDraiKN.mjs");
var Route$3 = createFileRoute("/_app/pos")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./tables-BscmKCpY.mjs");
var Route$2 = createFileRoute("/_app/tables")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./checkout._planId-CRVCAfZX.mjs");
var Route$1 = createFileRoute("/checkout/$planId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var IndexRoute = Route$15.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$16
});
var AppRoute = Route$14.update({
	id: "/_app",
	getParentRoute: () => Route$16
});
var LoginRoute = Route$13.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$16
});
var OnboardingRoute = Route$12.update({
	id: "/onboarding",
	path: "/onboarding",
	getParentRoute: () => Route$16
});
var PendingRoute = Route$11.update({
	id: "/pending",
	path: "/pending",
	getParentRoute: () => Route$16
});
var PinRoute = Route$10.update({
	id: "/pin",
	path: "/pin",
	getParentRoute: () => Route$16
});
var PlansRoute = Route$9.update({
	id: "/plans",
	path: "/plans",
	getParentRoute: () => Route$16
});
var PlatformRoute = Route$8.update({
	id: "/platform",
	path: "/platform",
	getParentRoute: () => Route$16
});
var RegisterRoute = Route$7.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$16
});
var VerifyRoute = Route$6.update({
	id: "/verify",
	path: "/verify",
	getParentRoute: () => Route$16
});
var AppAdminRoute = Route$5.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AppRoute
});
var AppKdsRoute = Route$4.update({
	id: "/kds",
	path: "/kds",
	getParentRoute: () => AppRoute
});
var AppPosRoute = Route$3.update({
	id: "/pos",
	path: "/pos",
	getParentRoute: () => AppRoute
});
var AppTablesRoute = Route$2.update({
	id: "/tables",
	path: "/tables",
	getParentRoute: () => AppRoute
});
var CheckoutPlanIdRoute = Route$1.update({
	id: "/checkout/$planId",
	path: "/checkout/$planId",
	getParentRoute: () => Route$16
});
var ApiAuthSplatRoute = Route.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$16
});
var AppRouteChildren = {
	AppAdminRoute,
	AppKdsRoute,
	AppPosRoute,
	AppTablesRoute
};
var rootRouteChildren = {
	IndexRoute,
	AppRoute: AppRoute._addFileChildren(AppRouteChildren),
	LoginRoute,
	OnboardingRoute,
	PendingRoute,
	PinRoute,
	PlansRoute,
	PlatformRoute,
	RegisterRoute,
	VerifyRoute,
	CheckoutPlanIdRoute,
	ApiAuthSplatRoute
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { statusLabel as _, useTenant as a, usePOSStore as b, addStaff as c, markEmailUnverified as d, verifyEmail as f, roleLabel as g, paymentLabel as h, AuthPage as i, getCatalog as l, localizedName as m, Route$1 as n, useCurrentUser as o, createSsrRpc as p, readPendingRestaurant as r, useCurrentUserState as s, router_exports as t, createRestaurant as u, t as v, tableStatusLabel as y };
