import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, l as getSql } from "./utils-zqpJ-D4Z.mjs";
import { Dt as boolean, Ft as string, Mt as object, jt as number, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { c as trialDaysLeft, r as getOrCreateProfile, t as createServerRpc } from "./tenant-v1xgc2D-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/platform-NEpyaV1R.js
async function requireSuperAdmin(userId) {
	const sql = await getSql();
	const profile = await getOrCreateProfile(sql, userId);
	if (profile.platform_role !== "super_admin") throw new Error("FORBIDDEN");
	return {
		sql,
		profile
	};
}
var platformOverview_createServerFn_handler = createServerRpc({
	id: "fc02af097278039224d2acd42942ab2e0e77cc65f2685e692534e5dbc2a1f72b",
	name: "platformOverview",
	filename: "src/lib/api/platform.ts"
}, (opts) => platformOverview.__executeServer(opts));
var platformOverview = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(platformOverview_createServerFn_handler, async ({ context }) => {
	const { sql } = await requireSuperAdmin(context.userId);
	const restaurants = await sql`
      select id, name, slug, status, plan_id, owner_user_id, trial_ends_at, created_at
      from restaurants order by created_at desc
    `;
	const [{ n: owners }] = await sql`select count(*)::int as n from profiles`;
	const [{ n: active }] = await sql`select count(*)::int as n from restaurants where status = 'active'`;
	const [{ n: pending }] = await sql`select count(*)::int as n from restaurants where status = 'pending'`;
	const plans = await sql`
      select id, name, slug, price_etb from plans order by sort_order
    `;
	const features = await sql`
      select pf.plan_id, pf.feature_id, f.key, f.name, f.kind, pf.enabled, pf.limit_value
      from plan_features pf join features f on f.id = pf.feature_id
    `;
	return {
		stats: {
			restaurants: restaurants.length,
			owners,
			active,
			pending
		},
		restaurants: restaurants.map((r) => ({
			id: r.id,
			name: r.name,
			slug: r.slug,
			status: r.status,
			planId: r.plan_id,
			ownerUserId: r.owner_user_id,
			trialDaysLeft: trialDaysLeft(String(r.trial_ends_at)),
			createdAt: String(r.created_at)
		})),
		plans: plans.map((p) => ({
			id: p.id,
			name: p.name,
			slug: p.slug,
			priceEtb: Number(p.price_etb),
			features: features.filter((f) => f.plan_id === p.id).map((f) => ({
				featureId: f.feature_id,
				key: f.key,
				name: f.name,
				kind: f.kind,
				enabled: f.enabled,
				limit: f.limit_value == null ? null : Number(f.limit_value)
			}))
		}))
	};
});
var setRestaurantStatus_createServerFn_handler = createServerRpc({
	id: "64cd54b9e1a24c26fcbaa2cc2432a56f41bbe4e583fa4d113272ee2191b68148",
	name: "setRestaurantStatus",
	filename: "src/lib/api/platform.ts"
}, (opts) => setRestaurantStatus.__executeServer(opts));
var setRestaurantStatus = createServerFn({ method: "POST" }).validator(object({
	restaurantId: string(),
	status: _enum([
		"pending",
		"active",
		"suspended",
		"rejected"
	])
})).middleware([authMiddleware]).handler(setRestaurantStatus_createServerFn_handler, async ({ context, data }) => {
	const { sql } = await requireSuperAdmin(context.userId);
	await sql`update restaurants set status = ${data.status} where id = ${data.restaurantId}`;
	return { ok: true };
});
var expireRestaurantTrial_createServerFn_handler = createServerRpc({
	id: "73ca786e3b40d968121a3339099d9a060bcb76605047b2ea34f6cc683d05cc20",
	name: "expireRestaurantTrial",
	filename: "src/lib/api/platform.ts"
}, (opts) => expireRestaurantTrial.__executeServer(opts));
var expireRestaurantTrial = createServerFn({ method: "POST" }).validator(object({ restaurantId: string() })).middleware([authMiddleware]).handler(expireRestaurantTrial_createServerFn_handler, async ({ context, data }) => {
	const { sql } = await requireSuperAdmin(context.userId);
	await sql`
      update restaurants set trial_ends_at = ${(/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString()} where id = ${data.restaurantId}
    `;
	return { ok: true };
});
var setPlanFeature_createServerFn_handler = createServerRpc({
	id: "e07cacd3b1d59d456059c3811de803d065cbda09515063a4df9a4fab42e03eb5",
	name: "setPlanFeature",
	filename: "src/lib/api/platform.ts"
}, (opts) => setPlanFeature.__executeServer(opts));
var setPlanFeature = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	featureId: string(),
	enabled: boolean(),
	limit: number().int().nullable().optional()
})).middleware([authMiddleware]).handler(setPlanFeature_createServerFn_handler, async ({ context, data }) => {
	const { sql } = await requireSuperAdmin(context.userId);
	await sql`
      update plan_features
      set enabled = ${data.enabled},
          limit_value = coalesce(${data.limit ?? null}, limit_value)
      where plan_id = ${data.planId} and feature_id = ${data.featureId}
    `;
	return { ok: true };
});
var setPlanPrice_createServerFn_handler = createServerRpc({
	id: "592fb04ed26fc36f7b6e557e33641428c42ef48123cda34550cc0f40e782f28b",
	name: "setPlanPrice",
	filename: "src/lib/api/platform.ts"
}, (opts) => setPlanPrice.__executeServer(opts));
var setPlanPrice = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	priceEtb: number().int().min(0)
})).middleware([authMiddleware]).handler(setPlanPrice_createServerFn_handler, async ({ context, data }) => {
	const { sql } = await requireSuperAdmin(context.userId);
	await sql`update plans set price_etb = ${data.priceEtb} where id = ${data.planId}`;
	return { ok: true };
});
//#endregion
export { expireRestaurantTrial_createServerFn_handler, platformOverview_createServerFn_handler, setPlanFeature_createServerFn_handler, setPlanPrice_createServerFn_handler, setRestaurantStatus_createServerFn_handler };
