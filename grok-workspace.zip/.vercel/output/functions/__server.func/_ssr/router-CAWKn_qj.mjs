import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { T as require_jsx_runtime, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, p as HeadContent, v as lazyRouteComponent, w as useRouter, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CAWKn_qj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var VAT_RATE = .15;
function lineTotal(item) {
	return item.price * item.qty;
}
function cartTotals(items) {
	const subtotal = items.reduce((sum, item) => sum + lineTotal(item), 0);
	const vat = Math.round(subtotal * VAT_RATE);
	return {
		subtotal,
		vat,
		total: subtotal + vat,
		count: items.reduce((sum, item) => sum + item.qty, 0)
	};
}
var ADMIN_ROLES = ["admin", "manager"];
var STAFF = [
	{
		id: "s_admin",
		name: "Hana Bekele",
		nameAm: "ሃና በቀለ",
		pin: "1234",
		role: "admin"
	},
	{
		id: "s_manager",
		name: "Yonas Tadesse",
		nameAm: "ዮናስ ታደሰ",
		pin: "2222",
		role: "manager"
	},
	{
		id: "s_cashier",
		name: "Marta Alemu",
		nameAm: "ማርታ ዓለሙ",
		pin: "1111",
		role: "cashier"
	},
	{
		id: "s_waiter",
		name: "Abel Tesfaye",
		nameAm: "አቤል ተስፋዬ",
		pin: "0000",
		role: "waiter"
	}
];
var CATEGORIES = [
	{
		id: "cat_breakfast",
		name: "Breakfast",
		nameAm: "ቁርስ"
	},
	{
		id: "cat_mains",
		name: "Mains",
		nameAm: "ዋና ምግብ"
	},
	{
		id: "cat_fasting",
		name: "Fasting",
		nameAm: "የጾም"
	},
	{
		id: "cat_sides",
		name: "Sides",
		nameAm: "ተጨማሪ"
	},
	{
		id: "cat_drinks",
		name: "Drinks",
		nameAm: "መጠጦች"
	}
];
var PRODUCTS = [
	{
		id: "p1",
		categoryId: "cat_breakfast",
		name: "Chechebsa",
		nameAm: "ቸቸብሳ",
		price: 110,
		available: true
	},
	{
		id: "p2",
		categoryId: "cat_breakfast",
		name: "Firfir",
		nameAm: "ፍርፍር",
		price: 120,
		available: true
	},
	{
		id: "p3",
		categoryId: "cat_breakfast",
		name: "Genfo",
		nameAm: "ገንፎ",
		price: 95,
		available: true
	},
	{
		id: "p4",
		categoryId: "cat_breakfast",
		name: "Kinche",
		nameAm: "ቂንጬ",
		price: 90,
		available: true
	},
	{
		id: "p5",
		categoryId: "cat_mains",
		name: "Doro Wot",
		nameAm: "ዶሮ ወጥ",
		price: 320,
		available: true
	},
	{
		id: "p6",
		categoryId: "cat_mains",
		name: "Kitfo",
		nameAm: "ክትፎ",
		price: 340,
		available: true
	},
	{
		id: "p7",
		categoryId: "cat_mains",
		name: "Special Kitfo",
		nameAm: "ስፔሻል ክትፎ",
		price: 390,
		available: true
	},
	{
		id: "p8",
		categoryId: "cat_mains",
		name: "Beef Tibs",
		nameAm: "የበሬ ጥብስ",
		price: 280,
		available: true
	},
	{
		id: "p9",
		categoryId: "cat_mains",
		name: "Lamb Tibs",
		nameAm: "የበግ ጥብስ",
		price: 350,
		available: true
	},
	{
		id: "p10",
		categoryId: "cat_mains",
		name: "Awaze Tibs",
		nameAm: "አዋዜ ጥብስ",
		price: 290,
		available: true
	},
	{
		id: "p11",
		categoryId: "cat_mains",
		name: "Key Wot",
		nameAm: "ቀይ ወጥ",
		price: 240,
		available: true
	},
	{
		id: "p12",
		categoryId: "cat_mains",
		name: "Dulet",
		nameAm: "ዱለት",
		price: 220,
		available: true
	},
	{
		id: "p13",
		categoryId: "cat_mains",
		name: "Meat Combo",
		nameAm: "የፍስክ በያይነቱ",
		price: 360,
		available: true
	},
	{
		id: "p14",
		categoryId: "cat_fasting",
		name: "Shiro",
		nameAm: "ሽሮ",
		price: 130,
		available: true
	},
	{
		id: "p15",
		categoryId: "cat_fasting",
		name: "Misir Wot",
		nameAm: "ምስር ወጥ",
		price: 120,
		available: true
	},
	{
		id: "p16",
		categoryId: "cat_fasting",
		name: "Gomen",
		nameAm: "ጎመን",
		price: 110,
		available: true
	},
	{
		id: "p17",
		categoryId: "cat_fasting",
		name: "Fasting Combo",
		nameAm: "የጾም በያይነቱ",
		price: 220,
		available: true
	},
	{
		id: "p18",
		categoryId: "cat_fasting",
		name: "Atkilt Wot",
		nameAm: "አትክልት ወጥ",
		price: 125,
		available: true
	},
	{
		id: "p19",
		categoryId: "cat_sides",
		name: "Injera Basket",
		nameAm: "እንጀራ",
		price: 40,
		available: true
	},
	{
		id: "p20",
		categoryId: "cat_sides",
		name: "Ayib",
		nameAm: "አይብ",
		price: 50,
		available: true
	},
	{
		id: "p21",
		categoryId: "cat_sides",
		name: "Salad",
		nameAm: "ሰላጣ",
		price: 80,
		available: true
	},
	{
		id: "p22",
		categoryId: "cat_sides",
		name: "French Fries",
		nameAm: "ቺፕስ",
		price: 70,
		available: true
	},
	{
		id: "p23",
		categoryId: "cat_drinks",
		name: "Buna",
		nameAm: "ቡና",
		price: 50,
		available: true
	},
	{
		id: "p24",
		categoryId: "cat_drinks",
		name: "Macchiato",
		nameAm: "ማኪያቶ",
		price: 45,
		available: true
	},
	{
		id: "p25",
		categoryId: "cat_drinks",
		name: "Shai",
		nameAm: "ሻይ",
		price: 30,
		available: true
	},
	{
		id: "p26",
		categoryId: "cat_drinks",
		name: "Fresh Juice",
		nameAm: "ፍሬ ጭማቂ",
		price: 75,
		available: true
	},
	{
		id: "p27",
		categoryId: "cat_drinks",
		name: "Soft Drink",
		nameAm: "ለስላሳ",
		price: 40,
		available: true
	},
	{
		id: "p28",
		categoryId: "cat_drinks",
		name: "Water",
		nameAm: "ውሃ",
		price: 25,
		available: true
	},
	{
		id: "p29",
		categoryId: "cat_drinks",
		name: "Tej",
		nameAm: "ጠጅ",
		price: 90,
		available: true
	},
	{
		id: "p30",
		categoryId: "cat_drinks",
		name: "Draft Beer",
		nameAm: "ቢራ",
		price: 80,
		available: true
	}
];
var TABLES = [
	{
		id: "t1",
		label: "T1",
		seats: 2,
		status: "available"
	},
	{
		id: "t2",
		label: "T2",
		seats: 2,
		status: "available"
	},
	{
		id: "t3",
		label: "T3",
		seats: 4,
		status: "occupied",
		orderId: "o_live_1"
	},
	{
		id: "t4",
		label: "T4",
		seats: 4,
		status: "available"
	},
	{
		id: "t5",
		label: "T5",
		seats: 4,
		status: "available"
	},
	{
		id: "t6",
		label: "T6",
		seats: 6,
		status: "available"
	},
	{
		id: "t7",
		label: "T7",
		seats: 4,
		status: "occupied",
		orderId: "o_live_2"
	},
	{
		id: "t8",
		label: "T8",
		seats: 2,
		status: "available"
	},
	{
		id: "t9",
		label: "T9",
		seats: 8,
		status: "available"
	},
	{
		id: "t10",
		label: "T10",
		seats: 4,
		status: "available"
	},
	{
		id: "t11",
		label: "T11",
		seats: 4,
		status: "reserved"
	},
	{
		id: "t12",
		label: "T12",
		seats: 6,
		status: "available"
	}
];
function hoursAgo(hours) {
	return Date.now() - hours * 60 * 60 * 1e3;
}
function daysAgo(days, hour = 14) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() - days);
	d.setHours(hour, 12, 0, 0);
	return d.getTime();
}
function seedOrders() {
	const now = Date.now();
	return [
		{
			id: "o_live_1",
			number: 104,
			tableId: "t3",
			tableLabel: "T3",
			staffId: "s_waiter",
			staffName: "Abel Tesfaye",
			type: "dine-in",
			status: "preparing",
			paid: false,
			createdAt: now - 72e4,
			updatedAt: now - 48e4,
			items: [
				{
					id: "li1",
					productId: "p5",
					name: "Doro Wot",
					nameAm: "ዶሮ ወጥ",
					price: 320,
					qty: 1
				},
				{
					id: "li2",
					productId: "p19",
					name: "Injera Basket",
					nameAm: "እንጀራ",
					price: 40,
					qty: 2
				},
				{
					id: "li3",
					productId: "p23",
					name: "Buna",
					nameAm: "ቡና",
					price: 50,
					qty: 2
				}
			]
		},
		{
			id: "o_live_2",
			number: 105,
			tableId: "t7",
			tableLabel: "T7",
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "dine-in",
			status: "new",
			paid: false,
			createdAt: now - 24e4,
			updatedAt: now - 24e4,
			items: [
				{
					id: "li4",
					productId: "p6",
					name: "Kitfo",
					nameAm: "ክትፎ",
					price: 340,
					qty: 2
				},
				{
					id: "li5",
					productId: "p17",
					name: "Fasting Combo",
					nameAm: "የጾም በያይነቱ",
					price: 220,
					qty: 1
				},
				{
					id: "li6",
					productId: "p26",
					name: "Fresh Juice",
					nameAm: "ፍሬ ጭማቂ",
					price: 75,
					qty: 2
				}
			]
		},
		{
			id: "o_live_3",
			number: 106,
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "takeaway",
			status: "ready",
			paid: true,
			paymentMethod: "telebirr",
			createdAt: now - 132e4,
			updatedAt: now - 18e4,
			items: [{
				id: "li7",
				productId: "p8",
				name: "Beef Tibs",
				nameAm: "የበሬ ጥብስ",
				price: 280,
				qty: 1
			}, {
				id: "li8",
				productId: "p19",
				name: "Injera Basket",
				nameAm: "እንጀራ",
				price: 40,
				qty: 1
			}]
		},
		{
			id: "o_done_1",
			number: 101,
			tableId: "t1",
			tableLabel: "T1",
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "cash",
			tendered: 600,
			createdAt: hoursAgo(3),
			updatedAt: hoursAgo(2.4),
			items: [{
				id: "li9",
				productId: "p14",
				name: "Shiro",
				nameAm: "ሽሮ",
				price: 130,
				qty: 2
			}, {
				id: "li10",
				productId: "p24",
				name: "Macchiato",
				nameAm: "ማኪያቶ",
				price: 45,
				qty: 2
			}]
		},
		{
			id: "o_done_2",
			number: 102,
			staffId: "s_manager",
			staffName: "Yonas Tadesse",
			type: "takeaway",
			status: "completed",
			paid: true,
			paymentMethod: "card",
			createdAt: hoursAgo(5),
			updatedAt: hoursAgo(4.5),
			items: [{
				id: "li11",
				productId: "p13",
				name: "Meat Combo",
				nameAm: "የፍስክ በያይነቱ",
				price: 360,
				qty: 1
			}, {
				id: "li12",
				productId: "p30",
				name: "Draft Beer",
				nameAm: "ቢራ",
				price: 80,
				qty: 2
			}]
		},
		{
			id: "o_done_3",
			number: 103,
			tableId: "t6",
			tableLabel: "T6",
			staffId: "s_waiter",
			staffName: "Abel Tesfaye",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "telebirr",
			createdAt: hoursAgo(6.5),
			updatedAt: hoursAgo(5.8),
			items: [
				{
					id: "li13",
					productId: "p5",
					name: "Doro Wot",
					nameAm: "ዶሮ ወጥ",
					price: 320,
					qty: 2
				},
				{
					id: "li14",
					productId: "p9",
					name: "Lamb Tibs",
					nameAm: "የበግ ጥብስ",
					price: 350,
					qty: 1
				},
				{
					id: "li15",
					productId: "p29",
					name: "Tej",
					nameAm: "ጠጅ",
					price: 90,
					qty: 3
				}
			]
		},
		{
			id: "o_d1",
			number: 88,
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "cash",
			createdAt: daysAgo(1, 13),
			updatedAt: daysAgo(1, 14),
			items: [{
				id: "li16",
				productId: "p7",
				name: "Special Kitfo",
				nameAm: "ስፔሻል ክትፎ",
				price: 390,
				qty: 2
			}, {
				id: "li17",
				productId: "p26",
				name: "Fresh Juice",
				nameAm: "ፍሬ ጭማቂ",
				price: 75,
				qty: 2
			}]
		},
		{
			id: "o_d2",
			number: 76,
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "takeaway",
			status: "completed",
			paid: true,
			paymentMethod: "card",
			createdAt: daysAgo(2, 19),
			updatedAt: daysAgo(2, 19),
			items: [{
				id: "li18",
				productId: "p17",
				name: "Fasting Combo",
				nameAm: "የጾም በያይነቱ",
				price: 220,
				qty: 3
			}]
		},
		{
			id: "o_d3",
			number: 64,
			staffId: "s_manager",
			staffName: "Yonas Tadesse",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "telebirr",
			createdAt: daysAgo(3, 12),
			updatedAt: daysAgo(3, 13),
			items: [{
				id: "li19",
				productId: "p8",
				name: "Beef Tibs",
				nameAm: "የበሬ ጥብስ",
				price: 280,
				qty: 4
			}, {
				id: "li20",
				productId: "p19",
				name: "Injera Basket",
				nameAm: "እንጀራ",
				price: 40,
				qty: 4
			}]
		},
		{
			id: "o_d4",
			number: 51,
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "cash",
			createdAt: daysAgo(4, 18),
			updatedAt: daysAgo(4, 19),
			items: [{
				id: "li21",
				productId: "p11",
				name: "Key Wot",
				nameAm: "ቀይ ወጥ",
				price: 240,
				qty: 2
			}, {
				id: "li22",
				productId: "p23",
				name: "Buna",
				nameAm: "ቡና",
				price: 50,
				qty: 4
			}]
		},
		{
			id: "o_d5",
			number: 40,
			staffId: "s_waiter",
			staffName: "Abel Tesfaye",
			type: "takeaway",
			status: "completed",
			paid: true,
			paymentMethod: "telebirr",
			createdAt: daysAgo(5, 11),
			updatedAt: daysAgo(5, 11),
			items: [{
				id: "li23",
				productId: "p1",
				name: "Chechebsa",
				nameAm: "ቸቸብሳ",
				price: 110,
				qty: 3
			}, {
				id: "li24",
				productId: "p24",
				name: "Macchiato",
				nameAm: "ማኪያቶ",
				price: 45,
				qty: 3
			}]
		},
		{
			id: "o_d6",
			number: 33,
			staffId: "s_cashier",
			staffName: "Marta Alemu",
			type: "dine-in",
			status: "completed",
			paid: true,
			paymentMethod: "card",
			createdAt: daysAgo(6, 20),
			updatedAt: daysAgo(6, 21),
			items: [{
				id: "li25",
				productId: "p13",
				name: "Meat Combo",
				nameAm: "የፍስክ በያይነቱ",
				price: 360,
				qty: 2
			}, {
				id: "li26",
				productId: "p29",
				name: "Tej",
				nameAm: "ጠጅ",
				price: 90,
				qty: 4
			}]
		}
	];
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return `${prefix}_${crypto.randomUUID().slice(0, 8)}`;
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}
var noopStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function getStorage() {
	if (typeof window === "undefined") return noopStorage;
	return window.localStorage;
}
function freshState() {
	return {
		seedVersion: 1,
		language: "en",
		theme: "dark",
		session: null,
		products: PRODUCTS.map((p) => ({ ...p })),
		tables: TABLES.map((t) => ({ ...t })),
		orders: seedOrders(),
		nextOrderNumber: 107,
		cart: { items: [] }
	};
}
function upsertLine(items, product) {
	if (items.find((i) => i.productId === product.id)) return items.map((i) => i.productId === product.id ? {
		...i,
		qty: i.qty + 1
	} : i);
	return [...items, {
		id: uid("li"),
		productId: product.id,
		name: product.name,
		nameAm: product.nameAm,
		price: product.price,
		qty: 1
	}];
}
var usePOSStore = create()(persist((set, get) => ({
	...freshState(),
	setLanguage: (language) => set({ language }),
	setTheme: (theme) => set({ theme }),
	login: (pin) => {
		const staff = STAFF.find((s) => s.pin === pin) ?? null;
		if (staff) set({ session: staff });
		return staff;
	},
	logout: () => set({
		session: null,
		cart: { items: [] }
	}),
	addToCart: (product) => {
		if (!product.available) return;
		set((s) => ({ cart: {
			...s.cart,
			items: upsertLine(s.cart.items, product)
		} }));
	},
	setQty: (lineId, qty) => {
		set((s) => ({ cart: {
			...s.cart,
			items: qty <= 0 ? s.cart.items.filter((i) => i.id !== lineId) : s.cart.items.map((i) => i.id === lineId ? {
				...i,
				qty
			} : i)
		} }));
	},
	clearCart: () => set({ cart: { items: [] } }),
	assignTable: (tableId) => {
		set((s) => ({ cart: {
			...s.cart,
			tableId
		} }));
	},
	loadOrderIntoCart: (orderId) => {
		const order = get().orders.find((o) => o.id === orderId);
		if (!order || order.status === "completed") return;
		set({ cart: {
			tableId: order.tableId,
			items: order.items.map((i) => ({
				...i,
				id: uid("li")
			}))
		} });
	},
	sendToKitchen: () => {
		const { cart, session, tables, orders, nextOrderNumber } = get();
		if (!session || cart.items.length === 0) return null;
		const table = tables.find((t) => t.id === cart.tableId);
		if (!table) return null;
		const existing = table.orderId ? orders.find((o) => o.id === table.orderId) : void 0;
		const now = Date.now();
		if (existing && existing.status !== "completed") {
			const merged = {
				...existing,
				items: cart.items.map((i) => ({ ...i })),
				updatedAt: now,
				status: existing.status === "ready" ? "preparing" : existing.status
			};
			set({ orders: orders.map((o) => o.id === existing.id ? merged : o) });
			return merged;
		}
		const order = {
			id: uid("o"),
			number: nextOrderNumber,
			tableId: table.id,
			tableLabel: table.label,
			staffId: session.id,
			staffName: session.name,
			items: cart.items.map((i) => ({ ...i })),
			status: "new",
			paid: false,
			createdAt: now,
			updatedAt: now,
			type: "dine-in"
		};
		set({
			orders: [order, ...orders],
			nextOrderNumber: nextOrderNumber + 1,
			tables: tables.map((t) => t.id === table.id ? {
				...t,
				status: "occupied",
				orderId: order.id
			} : t)
		});
		return order;
	},
	checkout: (method, tendered) => {
		const { cart, session, tables, orders, nextOrderNumber } = get();
		if (!session || cart.items.length === 0) return null;
		const { total } = cartTotals(cart.items);
		if (method === "cash" && tendered !== void 0 && tendered < total) return null;
		const table = tables.find((t) => t.id === cart.tableId);
		const now = Date.now();
		const existing = table?.orderId ? orders.find((o) => o.id === table.orderId && o.status !== "completed") : void 0;
		if (existing) {
			const updated = {
				...existing,
				items: cart.items.map((i) => ({ ...i })),
				paid: true,
				paymentMethod: method,
				tendered,
				updatedAt: now
			};
			set({
				orders: orders.map((o) => o.id === existing.id ? updated : o),
				cart: { items: [] }
			});
			return updated;
		}
		const order = {
			id: uid("o"),
			number: nextOrderNumber,
			tableId: table?.id,
			tableLabel: table?.label,
			staffId: session.id,
			staffName: session.name,
			items: cart.items.map((i) => ({ ...i })),
			status: "new",
			paid: true,
			paymentMethod: method,
			tendered,
			createdAt: now,
			updatedAt: now,
			type: table ? "dine-in" : "takeaway"
		};
		set({
			orders: [order, ...orders],
			nextOrderNumber: nextOrderNumber + 1,
			tables: table ? tables.map((t) => t.id === table.id ? {
				...t,
				status: "occupied",
				orderId: order.id
			} : t) : tables,
			cart: { items: [] }
		});
		return order;
	},
	advanceOrder: (orderId) => {
		const next = {
			new: "preparing",
			preparing: "ready",
			ready: "completed",
			completed: "completed"
		};
		set((s) => ({ orders: s.orders.map((o) => {
			if (o.id !== orderId) return o;
			return {
				...o,
				status: next[o.status],
				updatedAt: Date.now()
			};
		}) }));
	},
	completeOrder: (orderId) => {
		set((s) => ({
			orders: s.orders.map((o) => o.id === orderId ? {
				...o,
				status: "completed",
				updatedAt: Date.now()
			} : o),
			tables: s.tables.map((t) => t.orderId === orderId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t)
		}));
	},
	closeTable: (tableId) => {
		const { tables, orders, cart } = get();
		const table = tables.find((t) => t.id === tableId);
		if (!table?.orderId) {
			set({ tables: tables.map((t) => t.id === tableId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t) });
			return true;
		}
		const order = orders.find((o) => o.id === table.orderId);
		if (order && !order.paid) return false;
		set({
			orders: order ? orders.map((o) => o.id === order.id ? {
				...o,
				status: "completed",
				updatedAt: Date.now()
			} : o) : orders,
			tables: tables.map((t) => t.id === tableId ? {
				...t,
				status: "available",
				orderId: void 0
			} : t),
			cart: cart.tableId === tableId ? { items: [] } : cart
		});
		return true;
	},
	openTable: (tableId) => {
		const table = get().tables.find((t) => t.id === tableId);
		if (!table || table.status === "reserved") return;
		if (table.orderId) {
			get().loadOrderIntoCart(table.orderId);
			return;
		}
		set({ cart: {
			tableId,
			items: []
		} });
	},
	toggleProduct: (productId) => {
		set((s) => ({ products: s.products.map((p) => p.id === productId ? {
			...p,
			available: !p.available
		} : p) }));
	},
	resetDemo: () => {
		const { language, theme, session } = get();
		set({
			...freshState(),
			language,
			theme,
			session
		});
	}
}), {
	name: "simplepos-v1",
	storage: createJSONStorage(getStorage),
	skipHydration: true,
	partialize: (s) => ({
		seedVersion: s.seedVersion,
		language: s.language,
		theme: s.theme,
		session: s.session,
		products: s.products,
		tables: s.tables,
		orders: s.orders,
		nextOrderNumber: s.nextOrderNumber,
		cart: s.cart
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		if (p.seedVersion !== 1) return {
			...current,
			language: p.language ?? current.language,
			theme: p.theme ?? current.theme
		};
		return {
			...current,
			...p
		};
	}
}));
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-12 items-center justify-center rounded-xl bg-fg text-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-lg font-semibold tracking-tight",
					children: "sP"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "simplePOS"
			})]
		})
	});
}
function HydrationGate({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const theme = usePOSStore((s) => s.theme);
	const language = usePOSStore((s) => s.language);
	(0, import_react.useEffect)(() => {
		const persist = usePOSStore.persist;
		if (!persist) {
			setReady(true);
			return;
		}
		const unsub = persist.onFinishHydration(() => setReady(true));
		persist.rehydrate();
		if (persist.hasHydrated()) setReady(true);
		const fallback = window.setTimeout(() => setReady(true), 80);
		return () => {
			unsub?.();
			window.clearTimeout(fallback);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const root = document.documentElement;
		root.classList.toggle("dark", theme === "dark");
		root.classList.toggle("light", theme === "light");
		root.lang = language === "am" ? "am" : "en";
	}, [
		ready,
		theme,
		language
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var styles_default = "/assets/styles-Ck4XyW5j.css";
var APP_NAME = "simplePOS";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0c0e"
			},
			{
				name: "description",
				content: "Restaurant point of sale for Ethiopian dining rooms — tickets, tables, and kitchen display."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HydrationGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "top-center",
					toastOptions: { className: "bg-surface text-fg border-border" }
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$5 = () => import("./routes-N92aI8pj.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("../_app-DDCxkA3D.mjs");
var Route$4 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin-2YMryzJN.mjs");
var Route$3 = createFileRoute("/_app/admin")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./kds-BrCNlhbD.mjs");
var Route$2 = createFileRoute("/_app/kds")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./pos-DrKnKMyw.mjs");
var Route$1 = createFileRoute("/_app/pos")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./tables-CTP9EhfM.mjs");
var Route = createFileRoute("/_app/tables")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$6
});
var AppRoute = Route$4.update({
	id: "/_app",
	getParentRoute: () => Route$6
});
var AppRouteChildren = {
	AppAdminRoute: Route$3.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => AppRoute
	}),
	AppKdsRoute: Route$2.update({
		id: "/kds",
		path: "/kds",
		getParentRoute: () => AppRoute
	}),
	AppPosRoute: Route$1.update({
		id: "/pos",
		path: "/pos",
		getParentRoute: () => AppRoute
	}),
	AppTablesRoute: Route.update({
		id: "/tables",
		path: "/tables",
		getParentRoute: () => AppRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AppRoute: AppRoute._addFileChildren(AppRouteChildren)
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { STAFF as a, CATEGORIES as i, usePOSStore as n, ADMIN_ROLES as o, cn as r, cartTotals as s, router_exports as t };
