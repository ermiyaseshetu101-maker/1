import { S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTenant, b as usePOSStore, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DP4maRBN.js
var import_jsx_runtime = require_jsx_runtime();
function signedInDestination(args) {
	if (!args.emailVerified) return "/verify";
	if (!args.hasRestaurant) return "/onboarding";
	if (args.status === "pending" || args.status === "suspended" || args.status === "rejected") return "/pending";
	if (args.billingLocked) return "/plans";
	if (!args.hasStaffSession) return "/pin";
	if (args.role === "waiter") return "/tables";
	if (args.role === "kitchen") return "/kds";
	if (args.role === "admin" || args.role === "manager") return "/admin";
	return "/pos";
}
function Home() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const session = usePOSStore((s) => s.session);
	const language = usePOSStore((s) => s.language);
	const setLanguage = usePOSStore((s) => s.setLanguage);
	const theme = usePOSStore((s) => s.theme);
	const setTheme = usePOSStore((s) => s.setTheme);
	if (isPending || user && loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (user && bootstrap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: signedInDestination({
		emailVerified: bootstrap.profile.emailVerified,
		hasRestaurant: Boolean(bootstrap.restaurant),
		status: bootstrap.restaurant?.status,
		billingLocked: bootstrap.entitlements?.billingLocked,
		hasStaffSession: Boolean(session),
		role: session?.role
	}) });
	if (user && !bootstrap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex max-w-5xl items-center gap-3 px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-9 items-center justify-center rounded-lg bg-fg text-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold",
							children: "sP"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "flex-1 text-sm font-semibold",
						children: t(language, "appName")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs font-medium text-muted",
						onClick: () => setLanguage(language === "en" ? "am" : "en"),
						children: language === "en" ? "አማርኛ" : "English"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs font-medium text-muted",
						onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
						children: t(language, theme === "dark" ? "light" : "dark")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							children: t(language, "ownerLogin")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-4 py-16 md:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted uppercase",
						children: t(language, "daysTrial")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-xl text-4xl font-semibold tracking-tight md:text-5xl",
						children: t(language, "appName")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-lg text-base text-muted",
						children: t(language, "landingLead")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/register",
								children: t(language, "ownerRegister")
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								children: t(language, "ownerLogin")
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-md text-sm text-muted",
						children: t(language, "staffPinHint")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto grid max-w-5xl gap-3 px-4 pb-20 sm:grid-cols-3",
				children: [
					{
						title: "Starter",
						price: "ETB 1,500",
						body: "Front of house, kitchen display, discounts."
					},
					{
						title: "Professional",
						price: "ETB 3,500",
						body: "Reports, customers, receipt branding."
					},
					{
						title: "Business",
						price: "ETB 7,500",
						body: "Unlimited staff, tables, inventory."
					}
				].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-muted",
							children: card.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xl font-semibold tracking-tight",
							children: card.price
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: card.body
						})
					]
				}, card.title))
			})
		]
	});
}
//#endregion
export { Home as component, signedInDestination };
