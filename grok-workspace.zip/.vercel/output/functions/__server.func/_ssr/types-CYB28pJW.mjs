//#region node_modules/.nitro/vite/services/ssr/assets/types-CYB28pJW.js
var VAT_RATE = .15;
function lineTotal(item) {
	return item.price * item.qty;
}
function cartTotals(items, discount = 0) {
	const subtotal = items.reduce((sum, item) => sum + lineTotal(item), 0);
	const cut = Math.min(Math.max(0, discount), subtotal);
	const after = subtotal - cut;
	const vat = Math.round(after * VAT_RATE);
	return {
		subtotal,
		discount: cut,
		vat,
		total: after + vat,
		count: items.reduce((sum, item) => sum + item.qty, 0)
	};
}
var ALL_ROLES = [
	"admin",
	"manager",
	"cashier",
	"waiter",
	"kitchen"
];
var ADMIN_ROLES = ["admin", "manager"];
function hasFeature(ent, key) {
	if (!ent || ent.billingLocked) return false;
	if (key.startsWith("max_")) return true;
	return Boolean(ent.toggles[key]);
}
function limitOf(ent, key) {
	if (!ent) return 0;
	return ent.limits[key] ?? 0;
}
//#endregion
export { limitOf as a, hasFeature as i, ALL_ROLES as n, cartTotals as r, ADMIN_ROLES as t };
