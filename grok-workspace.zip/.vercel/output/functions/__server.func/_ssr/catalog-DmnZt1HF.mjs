import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, d as uid, l as getSql } from "./utils-zqpJ-D4Z.mjs";
import { a as limitOf } from "./types-CYB28pJW.mjs";
import { Ft as string, Mt as object, jt as number, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { a as requireRestaurant, t as createServerRpc } from "./tenant-v1xgc2D-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DmnZt1HF.js
var getCatalog_createServerFn_handler = createServerRpc({
	id: "ae614d38815bcd25a393d3146b9081b90f11cf7e6c1d021d71f848a692b1a989",
	name: "getCatalog",
	filename: "src/lib/api/catalog.ts"
}, (opts) => getCatalog.__executeServer(opts));
var getCatalog = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getCatalog_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
	const categories = await sql`
      select id, name, name_am from categories where restaurant_id = ${restaurant.id} order by sort_order, name
    `;
	const products = await sql`
      select id, category_id, name, name_am, price, available
      from products where restaurant_id = ${restaurant.id} order by name
    `;
	const tables = await sql`
      select id, label, seats, status, order_id from dining_tables
      where restaurant_id = ${restaurant.id} order by label
    `;
	const staff = await sql`
      select id, name, name_am, pin, role, active from staff
      where restaurant_id = ${restaurant.id} order by name
    `;
	return {
		restaurant,
		entitlements,
		categories: categories.map((c) => ({
			id: c.id,
			name: c.name,
			nameAm: c.name_am
		})),
		products: products.map((p) => ({
			id: p.id,
			categoryId: p.category_id,
			name: p.name,
			nameAm: p.name_am,
			price: Number(p.price),
			available: p.available
		})),
		tables: tables.map((t) => ({
			id: t.id,
			label: t.label,
			seats: Number(t.seats),
			status: t.status,
			orderId: t.order_id ?? void 0
		})),
		staff: staff.map((s) => ({
			id: s.id,
			name: s.name,
			nameAm: s.name_am,
			pin: s.pin,
			role: s.role,
			active: s.active
		}))
	};
});
var staffPinLogin_createServerFn_handler = createServerRpc({
	id: "36bdc0cb13224803adb1c0a57ef707a2459ae94f67bdb3e75a52ad15159c73bb",
	name: "staffPinLogin",
	filename: "src/lib/api/catalog.ts"
}, (opts) => staffPinLogin.__executeServer(opts));
var staffPinLogin = createServerFn({ method: "POST" }).validator(object({ pin: string().length(4) })).middleware([authMiddleware]).handler(staffPinLogin_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant } = await requireRestaurant(sql, context.userId);
	const s = (await sql`
      select id, name, name_am, pin, role from staff
      where restaurant_id = ${restaurant.id} and pin = ${data.pin} and active = true
    `)[0];
	if (!s) return null;
	return {
		id: s.id,
		name: s.name,
		nameAm: s.name_am,
		pin: s.pin,
		role: s.role
	};
});
var toggleProduct_createServerFn_handler = createServerRpc({
	id: "424b8d59ca7128d0e9cce3657721a7558ab35fb3709c6d0a096833d1d1628dcf",
	name: "toggleProduct",
	filename: "src/lib/api/catalog.ts"
}, (opts) => toggleProduct.__executeServer(opts));
var toggleProduct = createServerFn({ method: "POST" }).validator(object({ productId: string() })).middleware([authMiddleware]).handler(toggleProduct_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant } = await requireRestaurant(sql, context.userId);
	await sql`
      update products set available = not available
      where id = ${data.productId} and restaurant_id = ${restaurant.id}
    `;
	return { ok: true };
});
var addStaff_createServerFn_handler = createServerRpc({
	id: "2cbd72bdf49425c6939550e36c44f9d9c5850fe0fdee7a9850616a053abb0f1d",
	name: "addStaff",
	filename: "src/lib/api/catalog.ts"
}, (opts) => addStaff.__executeServer(opts));
var addStaff = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2),
	nameAm: string().trim().default(""),
	pin: string().regex(/^\d{4}$/),
	role: _enum([
		"admin",
		"manager",
		"cashier",
		"waiter",
		"kitchen"
	])
})).middleware([authMiddleware]).handler(addStaff_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
	const [{ n }] = await sql`
      select count(*)::int as n from staff where restaurant_id = ${restaurant.id} and active = true
    `;
	const cap = limitOf(entitlements, "max_staff");
	if (cap !== -1 && n >= cap) throw new Error("STAFF_LIMIT");
	if ((await sql`select id from staff where restaurant_id = ${restaurant.id} and pin = ${data.pin}`)[0]) throw new Error("PIN_TAKEN");
	await sql`
      insert into staff (id, restaurant_id, name, name_am, pin, role, active)
      values (${uid("s")}, ${restaurant.id}, ${data.name}, ${data.nameAm || data.name}, ${data.pin}, ${data.role}, true)
    `;
	return { ok: true };
});
var addTable_createServerFn_handler = createServerRpc({
	id: "4e0870033f36801be886410e368e894013f79ae2ffb9124ed50cace95233f77b",
	name: "addTable",
	filename: "src/lib/api/catalog.ts"
}, (opts) => addTable.__executeServer(opts));
var addTable = createServerFn({ method: "POST" }).validator(object({
	label: string().trim().min(1),
	seats: number().int().min(1).max(20)
})).middleware([authMiddleware]).handler(addTable_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant, entitlements } = await requireRestaurant(sql, context.userId);
	const [{ n }] = await sql`
      select count(*)::int as n from dining_tables where restaurant_id = ${restaurant.id}
    `;
	const cap = limitOf(entitlements, "max_tables");
	if (cap !== -1 && n >= cap) throw new Error("TABLE_LIMIT");
	await sql`
      insert into dining_tables (id, restaurant_id, label, seats, status)
      values (${uid("t")}, ${restaurant.id}, ${data.label}, ${data.seats}, 'available')
    `;
	return { ok: true };
});
var updateSettings_createServerFn_handler = createServerRpc({
	id: "9f0d30570840a1efb7873da5baff17a81b9f3945c6ecec8a7a68f6eeda19d30f",
	name: "updateSettings",
	filename: "src/lib/api/catalog.ts"
}, (opts) => updateSettings.__executeServer(opts));
var updateSettings = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(2).optional(),
	language: _enum(["en", "am"]).optional(),
	receiptFooter: string().max(200).optional(),
	currency: string().trim().min(3).max(8).optional()
})).middleware([authMiddleware]).handler(updateSettings_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const { restaurant } = await requireRestaurant(sql, context.userId);
	await sql`
      update restaurants
      set name = coalesce(${data.name ?? null}, name),
          language = coalesce(${data.language ?? null}, language),
          receipt_footer = coalesce(${data.receiptFooter ?? null}, receipt_footer),
          currency = coalesce(${data.currency ?? null}, currency)
      where id = ${restaurant.id} and owner_user_id = ${context.userId}
    `;
	return { ok: true };
});
//#endregion
export { addStaff_createServerFn_handler, addTable_createServerFn_handler, getCatalog_createServerFn_handler, staffPinLogin_createServerFn_handler, toggleProduct_createServerFn_handler, updateSettings_createServerFn_handler };
