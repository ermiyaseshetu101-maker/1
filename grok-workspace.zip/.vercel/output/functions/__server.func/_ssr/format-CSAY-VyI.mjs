//#region node_modules/.nitro/vite/services/ssr/assets/format-CSAY-VyI.js
function formatETB(amount, lang) {
	const n = new Intl.NumberFormat("en-US", {
		minimumFractionDigits: 0,
		maximumFractionDigits: 0
	}).format(Math.round(amount));
	return lang === "am" ? `${n} ብር` : `Br ${n}`;
}
function formatClock(ts, lang) {
	return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).format(new Date(ts));
}
function formatDate(ts, lang) {
	return new Intl.DateTimeFormat(lang === "am" ? "am-ET" : "en-GB", {
		weekday: "short",
		month: "short",
		day: "numeric"
	}).format(new Date(ts));
}
function elapsedMinutes(from, now) {
	return Math.max(0, Math.floor((now - from) / 6e4));
}
function startOfDay(ts = Date.now()) {
	const d = new Date(ts);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
//#endregion
export { startOfDay as a, formatETB as i, formatClock as n, formatDate as r, elapsedMinutes as t };
