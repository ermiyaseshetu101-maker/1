import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware } from "./utils-zqpJ-D4Z.mjs";
import { Dt as boolean, Ft as string, Mt as object, jt as number, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useTenant, b as usePOSStore, p as createSsrRpc, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Badge } from "./badge-BAjpSyJ1.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as formatETB } from "./format-CSAY-VyI.mjs";
import { i as RedirectToSignIn, n as OwnerShell, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/platform-DvkQ1Tfh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var platformOverview = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("fc02af097278039224d2acd42942ab2e0e77cc65f2685e692534e5dbc2a1f72b"));
var setRestaurantStatus = createServerFn({ method: "POST" }).validator(object({
	restaurantId: string(),
	status: _enum([
		"pending",
		"active",
		"suspended",
		"rejected"
	])
})).middleware([authMiddleware]).handler(createSsrRpc("64cd54b9e1a24c26fcbaa2cc2432a56f41bbe4e583fa4d113272ee2191b68148"));
var expireRestaurantTrial = createServerFn({ method: "POST" }).validator(object({ restaurantId: string() })).middleware([authMiddleware]).handler(createSsrRpc("73ca786e3b40d968121a3339099d9a060bcb76605047b2ea34f6cc683d05cc20"));
var setPlanFeature = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	featureId: string(),
	enabled: boolean(),
	limit: number().int().nullable().optional()
})).middleware([authMiddleware]).handler(createSsrRpc("e07cacd3b1d59d456059c3811de803d065cbda09515063a4df9a4fab42e03eb5"));
var setPlanPrice = createServerFn({ method: "POST" }).validator(object({
	planId: string(),
	priceEtb: number().int().min(0)
})).middleware([authMiddleware]).handler(createSsrRpc("592fb04ed26fc36f7b6e557e33641428c42ef48123cda34550cc0f40e782f28b"));
function PlatformPage() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const language = usePOSStore((s) => s.language);
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	async function load() {
		try {
			setData(await platformOverview());
			setError(null);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Forbidden");
		}
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		load();
	}, [user]);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (bootstrap && bootstrap.profile.platformRole !== "super_admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OwnerShell, {
		title: t(language, "platform"),
		subtitle: "simplePOS",
		children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-danger",
			children: error
		}) : null, data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 md:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: t(language, "restaurants"),
							value: String(data.stats.restaurants)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Owners",
							value: String(data.stats.owners)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Active",
							value: String(data.stats.active)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Pending",
							value: String(data.stats.pending)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: t(language, "restaurants")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: data.restaurants.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-6 text-sm text-muted",
							children: "No restaurants yet."
						}) : data.restaurants.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-col gap-3 py-4 sm:flex-row sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: r.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: [
											r.slug,
											" · ",
											r.planId.replace("plan_", ""),
											" · ",
											r.trialDaysLeft,
											" ",
											t(language, "daysLeft")
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: r.status === "active" ? "success" : r.status === "pending" ? "warning" : "danger",
									children: r.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => void setRestaurantStatus({ data: {
												restaurantId: r.id,
												status: "active"
											} }).then(load),
											children: t(language, "approve")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => void setRestaurantStatus({ data: {
												restaurantId: r.id,
												status: "suspended"
											} }).then(load),
											children: t(language, "suspend")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: () => void setRestaurantStatus({ data: {
												restaurantId: r.id,
												status: "rejected"
											} }).then(load),
											children: t(language, "reject")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: () => void expireRestaurantTrial({ data: { restaurantId: r.id } }).then(() => {
												toast.message("Trial ended for this restaurant");
												load();
											}),
											children: t(language, "expireTrial")
										})
									]
								})
							]
						}, r.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: t(language, "planFeatures")
					}), data.plans.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex flex-wrap items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: plan.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "ml-auto flex items-center gap-2 text-sm",
									children: ["ETB", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 0,
										defaultValue: plan.priceEtb,
										className: "h-9 w-24 rounded-lg bg-elevated px-2 text-sm tabular-nums outline-none",
										onBlur: (e) => {
											const value = Number(e.target.value);
											if (Number.isFinite(value) && value !== plan.priceEtb) setPlanPrice({ data: {
												planId: plan.id,
												priceEtb: value
											} }).then(load);
										}
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: formatETB(plan.priceEtb, language)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-2 sm:grid-cols-2",
							children: plan.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2 rounded-xl bg-elevated px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: f.enabled,
										onChange: (e) => void setPlanFeature({ data: {
											planId: plan.id,
											featureId: f.featureId,
											enabled: e.target.checked,
											limit: f.limit
										} }).then(load)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 text-sm",
										children: f.name
									}),
									f.kind === "limit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: "h-8 w-16 rounded-md bg-surface px-1 text-xs tabular-nums outline-none",
										defaultValue: f.limit ?? 0,
										onBlur: (e) => {
											const value = Number(e.target.value);
											if (!Number.isFinite(value) || value === f.limit) return;
											setPlanFeature({ data: {
												planId: plan.id,
												featureId: f.featureId,
												enabled: f.enabled,
												limit: value
											} }).then(load);
										}
									}) : null
								]
							}, f.featureId))
						})]
					}, plan.id))]
				})
			]
		}) : null]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-2xl font-semibold tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { PlatformPage as component };
