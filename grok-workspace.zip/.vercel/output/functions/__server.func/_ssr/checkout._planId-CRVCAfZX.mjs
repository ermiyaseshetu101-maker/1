import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useNavigate, S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as cn } from "./utils-zqpJ-D4Z.mjs";
import { a as useTenant, b as usePOSStore, n as Route$1, s as useCurrentUserState, v as t } from "./router-DdtrxyM9.mjs";
import { t as Button } from "./button-Oe3UAxjY.mjs";
import { i as formatETB } from "./format-CSAY-VyI.mjs";
import { i as RedirectToSignIn, n as OwnerShell, r as PageSkeleton } from "./owner-shell-Dn_Mr6rf.mjs";
import { n as listPlans, r as startCheckout, t as confirmSandboxPayment } from "./billing-DSMgAFJJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout._planId-CRVCAfZX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PROVIDERS = [
	{
		id: "chapa",
		label: "Chapa",
		hint: "Cards and Ethiopian banks"
	},
	{
		id: "telebirr",
		label: "Telebirr",
		hint: "Mobile money"
	},
	{
		id: "stripe",
		label: "Stripe",
		hint: "International cards"
	},
	{
		id: "card",
		label: "Card",
		hint: "Direct card processor"
	}
];
function CheckoutPage() {
	const { planId } = Route$1.useParams();
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading, refresh } = useTenant();
	const language = usePOSStore((s) => s.language);
	const navigate = useNavigate();
	const [plan, setPlan] = (0, import_react.useState)(null);
	const [provider, setProvider] = (0, import_react.useState)("chapa");
	const [paymentId, setPaymentId] = (0, import_react.useState)(null);
	const [hint, setHint] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		listPlans().then((plans) => setPlan(plans.find((p) => p.id === planId) ?? null));
	}, [user, planId]);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!bootstrap?.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
	async function beginPay() {
		setBusy(true);
		setError(null);
		try {
			const res = await startCheckout({ data: {
				planId,
				provider
			} });
			setPaymentId(res.paymentId);
			setHint(res.checkoutHint);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Checkout failed");
		} finally {
			setBusy(false);
		}
	}
	async function confirm() {
		if (!paymentId) return;
		setBusy(true);
		setError(null);
		try {
			await confirmSandboxPayment({ data: { paymentId } });
			await refresh();
			navigate({ to: "/pin" });
		} catch (e) {
			setError(e instanceof Error ? e.message : "Payment failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerShell, {
		title: t(language, "checkout"),
		subtitle: plan?.name,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg rounded-3xl bg-surface p-6 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: plan?.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-3xl font-semibold tabular-nums",
					children: [plan ? formatETB(plan.priceEtb, language) : "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-normal text-muted",
						children: t(language, "month")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 mb-2 text-xs font-medium tracking-wide text-muted uppercase",
					children: t(language, "payWith")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setProvider(p.id);
							setPaymentId(null);
							setHint(null);
						},
						className: cn("rounded-2xl px-3 py-3 text-left shadow-[var(--shadow-border)]", provider === p.id ? "bg-fg text-bg" : "bg-elevated text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: p.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("text-xs", provider === p.id ? "opacity-80" : "text-muted"),
							children: p.hint
						})]
					}, p.id))
				}),
				hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: hint
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: [!paymentId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: busy || !plan,
						onClick: () => void beginPay(),
						children: [
							t(language, "payWith"),
							" ",
							PROVIDERS.find((p) => p.id === provider)?.label
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						onClick: () => void confirm(),
						children: t(language, "sandboxPay")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/plans",
							children: t(language, "cancel")
						})
					})]
				})
			]
		})
	});
}
//#endregion
export { CheckoutPage as component };
