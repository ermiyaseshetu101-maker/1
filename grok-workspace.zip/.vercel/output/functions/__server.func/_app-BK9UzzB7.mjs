import { o as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as Navigate, _ as Outlet, m as useRouterState, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { o as cn } from "./_ssr/utils-zqpJ-D4Z.mjs";
import { i as hasFeature, t as ADMIN_ROLES } from "./_ssr/types-CYB28pJW.mjs";
import { a as Sun, f as LogOut, g as ChefHat, p as LayoutGrid, s as ShoppingBag, u as Moon, v as ChartColumn } from "./_libs/lucide-react.mjs";
import { a as useTenant, b as usePOSStore, g as roleLabel, m as localizedName, s as useCurrentUserState, v as t } from "./_ssr/router-DdtrxyM9.mjs";
import { t as Badge } from "./_ssr/badge-BAjpSyJ1.mjs";
import { t as Button } from "./_ssr/button-Oe3UAxjY.mjs";
import { n as formatClock } from "./_ssr/format-CSAY-VyI.mjs";
import { i as RedirectToSignIn, r as PageSkeleton } from "./_ssr/owner-shell-Dn_Mr6rf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-BK9UzzB7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		to: "/pos",
		icon: ShoppingBag,
		key: "navPos",
		roles: [
			"admin",
			"manager",
			"cashier",
			"waiter"
		]
	},
	{
		to: "/tables",
		icon: LayoutGrid,
		key: "navTables",
		roles: [
			"admin",
			"manager",
			"cashier",
			"waiter"
		]
	},
	{
		to: "/kds",
		icon: ChefHat,
		key: "navKds",
		roles: [
			"admin",
			"manager",
			"cashier",
			"waiter",
			"kitchen"
		],
		feature: "kds"
	},
	{
		to: "/admin",
		icon: ChartColumn,
		key: "navAdmin",
		roles: ADMIN_ROLES
	}
];
function useTick(ms = 3e4) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), ms);
		return () => window.clearInterval(id);
	}, [ms]);
	return now;
}
function AppShell({ children }) {
	const session = usePOSStore((s) => s.session);
	const language = usePOSStore((s) => s.language);
	const theme = usePOSStore((s) => s.theme);
	const orders = usePOSStore((s) => s.orders);
	const setLanguage = usePOSStore((s) => s.setLanguage);
	const setTheme = usePOSStore((s) => s.setTheme);
	const logout = usePOSStore((s) => s.logout);
	const { bootstrap } = useTenant();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const now = useTick();
	const ent = bootstrap?.entitlements;
	const days = ent?.trialDaysLeft ?? 0;
	const showTrial = ent?.subscriptionStatus === "trialing" && days > 0 && days <= 14;
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	const kitchenCount = orders.filter((o) => o.status === "new" || o.status === "preparing").length;
	const nav = NAV.filter((item) => {
		if (!item.roles.includes(session.role)) return false;
		if (item.feature === "kds" && !hasFeature(ent, "kds")) return false;
		return true;
	});
	const i18nOn = hasFeature(ent, "i18n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-[5.5rem] shrink-0 flex-col border-r border-border bg-surface md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-16 items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-10 items-center justify-center rounded-lg bg-fg text-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold",
							children: "sP"
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-1 flex-col gap-1 px-2 py-2",
					children: nav.map((item) => {
						const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("relative flex min-h-11 flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-xs font-medium transition-colors duration-150", active ? "bg-fg text-bg" : "text-muted hover:bg-elevated hover:text-fg"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
								t(language, item.key),
								item.to === "/kds" && kitchenCount > 0 && !active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1.5 size-2 rounded-full bg-warning" }) : null
							]
						}, item.to);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					showTrial ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/plans",
						className: "block bg-warning/20 px-4 py-2 text-center text-xs font-medium text-fg",
						children: [
							days,
							" ",
							t(language, "trialBanner"),
							" — ",
							t(language, "choosePlan")
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex h-14 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 md:h-16 md:px-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-semibold tracking-tight",
									children: bootstrap?.restaurant?.name ?? t(language, "appName")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted",
									children: [
										localizedName(language, session),
										" · ",
										roleLabel(language, session.role)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden tabular-nums text-sm text-muted sm:block",
								children: formatClock(now, language)
							}),
							i18nOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "size-10",
								onClick: () => setLanguage(language === "en" ? "am" : "en"),
								"aria-label": t(language, "language"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold",
									children: language === "en" ? "አማ" : "EN"
								})
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "size-10",
								onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
								"aria-label": t(language, "theme"),
								children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "size-10",
								onClick: logout,
								"aria-label": t(language, "logout"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex min-h-0 flex-1 flex-col overflow-hidden pb-20 md:pb-0",
						children
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] md:hidden",
				children: nav.map((item) => {
					const active = pathname === item.to;
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("relative flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium", active ? "text-fg" : "text-muted"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
							t(language, item.key),
							item.to === "/kds" && kitchenCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "warning",
								className: "absolute top-1 right-1/4 px-1.5 py-0 text-xs",
								children: kitchenCount
							}) : null
						]
					}, item.to);
				})
			})
		]
	});
}
function AuthenticatedLayout() {
	const { user, isPending } = useCurrentUserState();
	const { bootstrap, loading } = useTenant();
	const session = usePOSStore((s) => s.session);
	if (isPending || loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!bootstrap?.profile.emailVerified) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/verify" });
	if (!bootstrap.restaurant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
	if (bootstrap.restaurant.status === "pending" || bootstrap.restaurant.status === "suspended" || bootstrap.restaurant.status === "rejected") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pending" });
	if (bootstrap.entitlements?.billingLocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/plans" });
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/pin" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AuthenticatedLayout as component };
